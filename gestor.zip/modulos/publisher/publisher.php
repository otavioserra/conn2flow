<?php

global $_GESTOR;

$_GESTOR['modulo-id']							=	'publisher';
$_GESTOR['modulo#'.$_GESTOR['modulo-id']] = json_decode(file_get_contents(__DIR__ . '/publisher.json'), true);

// ===== Funções Auxiliares

function publisher_normalize_array($array) {
    if (is_array($array)) {
        ksort($array); // Ordena chaves
        foreach ($array as $key => $value) {
            $array[$key] = publisher_normalize_array($value); // Recursivo para subarrays
        }
    }
    return $array;
}

// ===== Funções Principais

function publisher_adicionar(){
	global $_GESTOR;
	
	$modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];
	
	// ===== Gravar registro no Banco
	
	if(isset($_GESTOR['adicionar-banco'])){
		$usuario = gestor_usuario();
		
		// ===== Validação de campos obrigatórios
		
		interface_validacao_campos_obrigatorios(Array(
			'campos' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
				),
				Array(
					'regra' => 'selecao-obrigatorio',
					'campo' => 'template_id',
					'label' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
				)
			)
		));
		
		// ===== Definição do identificador
		
		$campos = null;
		$campo_sem_aspas_simples = false;
		
		$id = banco_identificador(Array(
			'id' => banco_escape_field($_REQUEST["name"]),
			'tabela' => Array(
				'nome' => $modulo['tabela']['nome'],
				'campo' => $modulo['tabela']['id'],
				'id_nome' => $modulo['tabela']['id_numerico'],
				'where' => "language='".$_GESTOR['linguagem-codigo']."'",
			),
		));

        // ===== Campos gerais
		
		$campo_nome = "id_usuarios"; $campo_valor = $usuario['id_usuarios']; 			$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = "name"; $post_nome = $campo_nome;      							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		$campo_nome = "id"; $campo_valor = $id; 										$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = "path_prefix"; $post_nome = $campo_nome; 							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		$campo_nome = "template_id"; $post_nome = $campo_nome; 							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		
		// ===== Pré-processar fields_schema para converter variáveis de frontend [[...]] para backend @[[...]]@
		
		$open = $_GESTOR['variavel-global']['open'];
		$close = $_GESTOR['variavel-global']['close'];
		$openText = $_GESTOR['variavel-global']['openText'];
		$closeText = $_GESTOR['variavel-global']['closeText'];
		
		$fields_schema_str = $_REQUEST['fields_schema'] ?? '[]';
		
		// Substituição global simples na string JSON antes de salvar
		// Substitui [[publisher#...]] por @[[publisher#...]]@
		// A regex busca por openText + (conteudo) + closeText e substitui por open + conteudo + close
		
		$fields_schema_str = preg_replace("/".preg_quote($openText)."(.+?)".preg_quote($closeText)."/", strtolower($open."$1".$close), $fields_schema_str);
		
		$campo_nome = "fields_schema"; $campo_valor = $fields_schema_str;				if($_REQUEST['fields_schema'])	$campos[] = Array($campo_nome,banco_escape_field($campo_valor));
		
		// ===== Campos comuns
		
		$campo_nome = 'language '; $campo_valor = $_GESTOR['linguagem-codigo']; 		$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['status']; $campo_valor = 'A'; 					$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['versao']; $campo_valor = '1'; 					$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['data_criacao']; $campo_valor = 'NOW()'; 		$campos[] = Array($campo_nome,$campo_valor,true);
		$campo_nome = $modulo['tabela']['data_modificacao']; $campo_valor = 'NOW()'; 	$campos[] = Array($campo_nome,$campo_valor,true);
	
		banco_insert_name
		(
			$campos,
			$modulo['tabela']['nome']
		);
		
		gestor_redirecionar($_GESTOR['modulo-id'].'/editar/?'.$modulo['tabela']['id'].'='.$id);
	}
	
	// ===== Templates para seleção

	$templates = banco_select_name
	(
		banco_campos_virgulas(Array(
			'nome',
			'id'
		))
		,
		'templates',
		"WHERE status='A'"
		.' AND language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"'
		." ORDER BY nome ASC"
	);

	$templates_linked_publisher = banco_select_name
	(
		banco_campos_virgulas(Array(
			't.nome',
			't.id',
			'p.name',
		))
		,
		'templates AS t, publisher AS p',
		"WHERE t.status='A' AND t.id=p.template_id"
		.' AND t.language="'.$_GESTOR['linguagem-codigo'].'" AND p.language="'.$_GESTOR['linguagem-codigo'].'" AND t.target="publisher" AND p.status!="D"'
		." ORDER BY t.nome ASC"
	);

	$countTemplates = 0;
	$countTemplatesLinked = 0;
	foreach($templates as $template){
		$disabled = '';
		$countTemplates++;
		foreach($templates_linked_publisher as $linked){
			if($template['id'] == $linked['t.id']){
				$template['nome'] = '<kbd class="ui basic label">' . $template['nome'] . '</kbd><kbd class="ui teal icon label"><i class="exchange alternate small icon"></i></kbd><kbd class="ui basic label">' . $linked['p.name'] . '</kbd>';
				$disabled = ' disabled';
				$countTemplatesLinked++;
				break;
			}
		}

		$template_id_options .= '<option value="'.$template['id'].'"'.$disabled.'>'.$template['nome'].'</option>';
	}

	if($countTemplatesLinked == 0){
		$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	} else if($countTemplates == $countTemplatesLinked){
		$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	} else {
		$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	}

	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_placeholder_option#',gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')));
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_id_options#',$template_id_options);

	// ===== Inclusão Módulo JS
	
	gestor_pagina_javascript_incluir();

	// Incluir regra dinâmica para os campos Labels:

	$prompt[1] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-empty'));
	
	$prompt[2] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-min-length'));
	
	$prompt[3] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-max-length'));

	$formLabelRules = [
		'rules' => [
			Array(
				'type' => 'notEmpty',
				'prompt' => $prompt[1],
			),
			Array(
				'type' => 'minLength[3]',
				'prompt' => $prompt[2],
			),
			Array(
				'type' => 'maxLength[100]',
				'prompt' => $prompt[3],
			),
		]
	];

	gestor_js_variavel_incluir('formLabelRules',$formLabelRules);
	
	// ===== Interface adicionar finalizar opções
	
	$_GESTOR['interface']['adicionar']['finalizar'] = Array(
		'formulario' => Array(
			'validacao' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
					'identificador' => 'name',
				),
				Array(
					'regra' => 'selecao-obrigatorio',
					'campo' => 'template_id',
					'label' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
					'identificador' => 'template_id',
				),
			)
		)
	);
}

function publisher_editar(){
	global $_GESTOR;
	
	$modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];
	
	// ===== Identificador do registro
	
	$id = $_GESTOR['modulo-registro-id'];
	
	// ===== Definição dos campos do banco de dados para editar.
	
	$camposBanco = Array(
		'id',
        'id_publisher',
		'name',
		'path_prefix',
		'template_id',
		'fields_schema',
		'status'
	);
	
	$camposBancoPadrao = Array(
		$modulo['tabela']['status'],
		$modulo['tabela']['versao'],
		$modulo['tabela']['data_criacao'],
		$modulo['tabela']['data_modificacao'],
	);
	
	$camposBancoEditar = array_merge($camposBanco,$camposBancoPadrao);
	$camposBancoAntes = $camposBanco;
	
	// ===== Gravar Atualizações no Banco
	
	if(isset($_GESTOR['atualizar-banco'])){
		// ===== Recuperar o estado dos dados do banco de dados antes de editar.
		
		if(!banco_select_campos_antes_iniciar(
			banco_campos_virgulas($camposBancoAntes)
			,
			$modulo['tabela']['nome'],
			"WHERE ".$modulo['tabela']['id']."='".$id."'"
			." AND ".$modulo['tabela']['status']."!='D'"
			." AND language='".$_GESTOR['linguagem-codigo']."'"
		)){
			interface_alerta(Array(
				'redirect' => true,
				'msg' => gestor_variaveis(Array('modulo' => 'interface','id' => 'alert-database-field-before-error'))
			));
			
			gestor_redirecionar_raiz();
		}
		
		// ===== Validação de campos obrigatórios
		
		interface_validacao_campos_obrigatorios(Array(
			'campos' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
				)
			)
		));
		
		// ===== Valores padrões da tabela e regras para o campo nome
		
		$editar = Array(
			'tabela' => $modulo['tabela']['nome'],
			'extra' => "WHERE ".$modulo['tabela']['id']."='".$id."' AND ".$modulo['tabela']['status']."!='D' AND language='".$_GESTOR['linguagem-codigo']."'",
		);
		
		$campo_nome = "name"; $request_name = $campo_nome; $alteracoes_name = $campo_nome; if(banco_select_campos_antes($campo_nome) != (isset($_REQUEST[$request_name]) ? $_REQUEST[$request_name] : NULL)){$editar['dados'][] = $campo_nome."='" . banco_escape_field($_REQUEST[$request_name]) . "'"; if(!isset($_REQUEST['_gestor-nao-alterar-id'])){$alterar_id = true;} $alteracoes[] = Array('campo' => 'form-'.$alteracoes_name.'-label', 'valor_antes' => banco_select_campos_antes($campo_nome),'valor_depois' => banco_escape_field($_REQUEST[$request_name]));}
		
		// ===== Se mudar o nome, mudar o identificador do registro
		
		if(isset($alterar_id)){
			$layouts = banco_select_name
			(
				banco_campos_virgulas(Array(
					$modulo['tabela']['id_numerico'],
				))
				,
				$modulo['tabela']['nome'],
				"WHERE ".$modulo['tabela']['id']."='".$id."'"
			);
			
			if($layouts){
				$id_novo = banco_identificador(Array(
					'id' => banco_escape_field($_REQUEST["name"]),
					'tabela' => Array(
						'nome' => $modulo['tabela']['nome'],
						'campo' => $modulo['tabela']['id'],
						'id_nome' => $modulo['tabela']['id_numerico'],
						'id_valor' => $layouts[0][$modulo['tabela']['id_numerico']],
						'where' => "language='".$_GESTOR['linguagem-codigo']."'",
					),
				));
				
				$alteracoes_name = 'id'; $alteracoes[] = Array('campo' => 'field-id', 'valor_antes' => $id,'valor_depois' => $id_novo);
				$campo_nome = $modulo['tabela']['id']; $editar['dados'][] = $campo_nome."='" . $id_novo . "'";
				$_GESTOR['modulo-registro-id'] = $id_novo;
			}
		}
		
		// ===== Atualização dos demais campos.

		$campo_nome = "path_prefix"; $request_name = $campo_nome; $alteracoes_name = $campo_nome; if(banco_select_campos_antes($campo_nome) != (isset($_REQUEST[$request_name]) ? $_REQUEST[$request_name] : NULL)){$editar['dados'][] = $campo_nome."='" . banco_escape_field($_REQUEST[$request_name]) . "'"; $alteracoes[] = Array('campo' => 'form-'.$alteracoes_name.'-label', 'valor_antes' => banco_select_campos_antes($campo_nome),'valor_depois' => banco_escape_field($_REQUEST[$request_name]));if(banco_select_campos_antes($campo_nome)){ $backups[] = Array('campo' => $campo_nome,'valor' => addslashes(banco_select_campos_antes($campo_nome)));}}
		$campo_nome = "template_id"; $request_name = $campo_nome; $alteracoes_name = $campo_nome; if(banco_select_campos_antes($campo_nome) != (isset($_REQUEST[$request_name]) ? $_REQUEST[$request_name] : NULL)){$editar['dados'][] = $campo_nome."='" . banco_escape_field($_REQUEST[$request_name]) . "'"; $alteracoes[] = Array('campo' => 'form-'.$alteracoes_name.'-label');if(banco_select_campos_antes($campo_nome)){ $backups[] = Array('campo' => $campo_nome,'valor' => addslashes(banco_select_campos_antes($campo_nome)));}}
		
		$campo_nome = "fields_schema"; $request_name = $campo_nome; $alteracoes_name = $campo_nome;
		if(isset($_REQUEST[$request_name])){
			// ===== Processar fields_schema para converter variáveis de frontend [[...]] para backend @[[...]]@

			$open = $_GESTOR['variavel-global']['open'];
			$close = $_GESTOR['variavel-global']['close'];
			$openText = $_GESTOR['variavel-global']['openText'];
			$closeText = $_GESTOR['variavel-global']['closeText'];
			
			$request_formatado = preg_replace("/".preg_quote($openText)."(.+?)".preg_quote($closeText)."/", strtolower($open."$1".$close), ($_REQUEST[$request_name] ? $_REQUEST[$request_name] : ''));

			// ===== Normalizar e comparar o schema de campos personalizados
			
			$valor_request = publisher_normalize_array(json_decode($request_formatado, true));
			$valor_banco = publisher_normalize_array(json_decode(banco_select_campos_antes($campo_nome), true));
			
			if ($valor_banco !== $valor_request) {
				// Lógica de atualização
				$editar['dados'][] = $campo_nome . "='" . banco_escape_field($request_formatado) . "'";
				$alteracoes[] = Array('campo' => 'form-' . $alteracoes_name . '-label');
			}
		}

		// ===== Se houve alterações, modificar no banco de dados junto com campos padrões de atualização
		
		if(isset($editar['dados'])){
			$campo_nome = 'user_modified'; $editar['dados'][] = $campo_nome." = 1";
			$campo_nome = $modulo['tabela']['versao']; $editar['dados'][] = $campo_nome." = ".$campo_nome." + 1";
			$campo_nome = $modulo['tabela']['data_modificacao']; $editar['dados'][] = $campo_nome."=NOW()";
			
			$editar['sql'] = banco_campos_virgulas($editar['dados']);
			
			if($editar['sql']){
				banco_update
				(
					$editar['sql'],
					$editar['tabela'],
					$editar['extra']
				);
			}
			$editar = false;
			
			// ===== Incluir no backup os campos.
			
			if(isset($backups)){
				foreach($backups as $backup){
					interface_backup_campo_incluir(Array(
						'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
						'versao' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['versao'])),
						'campo' => $backup['campo'],
						'valor' => $backup['valor'],
					));
				}
			}
			
			// ===== Incluir no histórico as alterações.
			
			interface_historico_incluir(Array(
				'id' => $id,
				'tabela' => Array(
					'nome' => $modulo['tabela']['nome'],
					'id_numerico' => $modulo['tabela']['id_numerico'],
					'versao' => $modulo['tabela']['versao'],
				),
				'alteracoes' => $alteracoes,
			));
		}
		
		// ===== Reler URL.
		
		gestor_redirecionar($_GESTOR['modulo-id'].'/editar/?'.$modulo['tabela']['id'].'='.(isset($id_novo) ? $id_novo : $id));
	}

    // ===== Selecionar dados do banco de dados
	
	$retorno_bd = banco_select_editar
	(
		banco_campos_virgulas($camposBancoEditar)
		,
		$modulo['tabela']['nome'],
		"WHERE ".$modulo['tabela']['id']."='".$id."'"
		." AND ".$modulo['tabela']['status']."!='D'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
	);
	
	if($_GESTOR['banco-resultado']){
		$name = (isset($retorno_bd['name']) ? $retorno_bd['name'] : '');
		$path_prefix = (isset($retorno_bd['path_prefix']) ? $retorno_bd['path_prefix'] : '');
		$template_id = (isset($retorno_bd['template_id']) ? $retorno_bd['template_id'] : '');
		$fields_schema = (isset($retorno_bd['fields_schema']) ? $retorno_bd['fields_schema'] : '');
		
		// ===== Processar fields_schema para converter variáveis de backend @[[...]]@ para frontend [[...]]
		
		$open = $_GESTOR['variavel-global']['open'];
		$close = $_GESTOR['variavel-global']['close'];
		$openText = $_GESTOR['variavel-global']['openText'];
		$closeText = $_GESTOR['variavel-global']['closeText'];
		
		$fields_schema = preg_replace("/".preg_quote($open)."(.+?)".preg_quote($close)."/", strtolower($openText."$1".$closeText), $fields_schema);
		
		// ===== Alterar demais variáveis.
		
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#name#',$name);
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#id#',$id);
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#path_prefix#',$path_prefix);
        
        // Injetar o schema existente para o JS carregar
        $fields_schema_decoded = json_decode($fields_schema, true) ?: ['fields' => [], 'template_map' => []];
        $schema_json = json_encode($fields_schema_decoded);
        $_GESTOR['pagina'] .= '<script>var publisher_initial_schema = '.$schema_json.';</script>';

		// ===== Templates para seleção

		$templates = banco_select_name
		(
			banco_campos_virgulas(Array(
				'nome',
				'id'
			))
			,
			'templates',
			"WHERE status='A'"
			.' AND language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"'
			." ORDER BY nome ASC"
		);

		$templates_linked_publisher = banco_select_name
		(
			banco_campos_virgulas(Array(
				't.nome',
				't.id',
				'p.name',
			))
			,
			'templates AS t, publisher AS p',
			"WHERE t.status='A' AND t.id=p.template_id"
			.' AND t.language="'.$_GESTOR['linguagem-codigo'].'" AND p.language="'.$_GESTOR['linguagem-codigo'].'" AND t.target="publisher" AND p.status!="D"'
			." ORDER BY t.nome ASC"
		);

		$countTemplates = 0;
		$countTemplatesLinked = 0;
		if($templates)
		foreach($templates as $template){
			$disabled = '';
			$selected = '';
			$countTemplates++;

			if($template['id'] != $template_id)
			if($templates_linked_publisher)
			foreach($templates_linked_publisher as $linked){
				if($template['id'] == $linked['t.id']){
					$template['nome'] = '<kbd class="ui basic label">' . $template['nome'] . '</kbd><kbd class="ui teal icon label"><i class="exchange alternate small icon"></i></kbd><kbd class="ui basic label">' . $linked['p.name'] . '</kbd>';
					$disabled = ' disabled';
					$countTemplatesLinked++;
					break;
				}
			}

			if($template['id'] == $template_id){
				$selected = ' selected';
			}

			$template_id_options .= '<option value="'.$template['id'].'"'.$disabled.$selected.'>'.$template['nome'].'</option>';
		}

		if($countTemplatesLinked == 0){
			$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		} else if($countTemplates == $countTemplatesLinked){
			$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		} else {
			$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		}

		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_placeholder_option#',gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')));
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_id_options#',$template_id_options);
		
		// Incluir regra dinâmica para os campos Labels:

		$prompt[1] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-empty'));
		
		$prompt[2] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-min-length'));
		
		$prompt[3] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-max-length'));

		$formLabelRules = [
			'rules' => [
				Array(
					'type' => 'notEmpty',
					'prompt' => $prompt[1],
				),
				Array(
					'type' => 'minLength[3]',
					'prompt' => $prompt[2],
				),
				Array(
					'type' => 'maxLength[100]',
					'prompt' => $prompt[3],
				),
			]
		];

		gestor_js_variavel_incluir('formLabelRules',$formLabelRules);

		// ===== Popular os metaDados
		
		$status_atual = (isset($retorno_bd[$modulo['tabela']['status']]) ? $retorno_bd[$modulo['tabela']['status']] : '');
		
		if(isset($retorno_bd[$modulo['tabela']['data_criacao']])){ $metaDados[] = Array('titulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-date-start')),'dado' => interface_formatar_dado(Array('dado' => $retorno_bd[$modulo['tabela']['data_criacao']], 'formato' => 'dataHora'))); }
		if(isset($retorno_bd[$modulo['tabela']['data_modificacao']])){ $metaDados[] = Array('titulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-date-modification')),'dado' => interface_formatar_dado(Array('dado' => $retorno_bd[$modulo['tabela']['data_modificacao']], 'formato' => 'dataHora'))); }
		if(isset($retorno_bd[$modulo['tabela']['versao']])){ $metaDados[] = Array('titulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-version')),'dado' => $retorno_bd[$modulo['tabela']['versao']]); }
		if(isset($retorno_bd[$modulo['tabela']['status']])){ $metaDados[] = Array('titulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-status')),'dado' => ($retorno_bd[$modulo['tabela']['status']] == 'A' ? '<div class="ui center aligned green message"><b>'.gestor_variaveis(Array('modulo' => 'interface','id' => 'field-status-active')).'</b></div>' : '').($retorno_bd[$modulo['tabela']['status']] == 'I' ? '<div class="ui center aligned brown message"><b>'.gestor_variaveis(Array('modulo' => 'interface','id' => 'field-status-inactive')).'</b></div>' : '')); }
	} else {
		gestor_redirecionar_raiz();
	}
	
	// ===== Inclusão Módulo JS
	
	gestor_pagina_javascript_incluir();
	
	// ===== Interface editar finalizar opções
	
	$_GESTOR['interface']['editar']['finalizar'] = Array(
		'id' => $id,
		'metaDados' => $metaDados,
		'banco' => Array(
			'nome' => $modulo['tabela']['nome'],
			'id' => $modulo['tabela']['id'],
			'status' => $modulo['tabela']['status'],
		),
		'botoes' => Array(
			'adicionar' => Array(
				'url' => $_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/adicionar/',
				'rotulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-insert')),
				'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-insert')),
				'icon' => 'plus circle',
				'cor' => 'blue',
			),
			'clonar' => Array(
				'url' => $_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/clonar/?'.$modulo['tabela']['id'].'='.$id,
				'rotulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-clone')),
				'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-clone')),
				'icon' => 'clone',
				'cor' => 'teal',
			),
			'status' => Array(
				'url' => $_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/?opcao=status&'.$modulo['tabela']['status'].'='.($status_atual == 'A' ? 'I' : 'A' ).'&'.$modulo['tabela']['id'].'='.$id.'&redirect='.urlencode($_GESTOR['modulo-id'].'/editar/?'.$modulo['tabela']['id'].'='.$id),
				'rotulo' => ($status_atual == 'A' ? gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-desactive')) : gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-active')) ),
				'tooltip' => ($status_atual == 'A' ? gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-desactive')) : gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-active'))),
				'icon' => ($status_atual == 'A' ? 'eye' : 'eye slash' ),
				'cor' => ($status_atual == 'A' ? 'green' : 'brown' ),
			),
			'excluir' => Array(
				'url' => $_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/?opcao=excluir&'.$modulo['tabela']['id'].'='.$id,
				'rotulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-delete')),
				'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-delete')),
				'icon' => 'trash alternate',
				'cor' => 'red',
			),
		),
		'formulario' => Array(
			'validacao' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
					'identificador' => 'name',
				),
				Array(
					'regra' => 'selecao-obrigatorio',
					'campo' => 'template_id',
					'label' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
					'identificador' => 'template_id',
				),
			),
			'campos' => Array(
				Array(
					'tipo' => 'select',
					'id' => 'template_id',
					'nome' => 'template_id',
					'procurar' => true,
					'limpar' => true,
					'selectClass' => 'templateDropdown',
					'placeholder' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
					'tabela' => Array(
						'nome' => 'templates',
						'campo' => 'nome',
						'id_numerico' => 'id',
						'id_selecionado' => $template_id,
						'where' => 'language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"',
					),
				)
			)
		)
	);
}

function publisher_clonar(){
	global $_GESTOR;
	
	$modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];
	
	// ===== Identificador do registro a ser clonado.
	
	$id = $_GESTOR['modulo-registro-id'];
	
	// ===== Definição dos campos do banco de dados para clonar.
	
	$camposBanco = Array(
		'id',
        'id_publisher',
		'name',
		'path_prefix',
		'template_id',
		'fields_schema',
		'status'
	);
	
	$camposBancoPadrao = Array(
		$modulo['tabela']['status'],
		$modulo['tabela']['versao'],
		$modulo['tabela']['data_criacao'],
		$modulo['tabela']['data_modificacao'],
	);
	
	$camposBancoClonar = array_merge($camposBanco,$camposBancoPadrao);
	
	// ===== Gravar registro no Banco
	
	if(isset($_GESTOR['adicionar-banco'])){
		$usuario = gestor_usuario();
		
		// ===== Validação de campos obrigatórios
		
		interface_validacao_campos_obrigatorios(Array(
			'campos' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
				),
				Array(
					'regra' => 'selecao-obrigatorio',
					'campo' => 'template_id',
					'label' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
				)
			)
		));
		
		// ===== Definição do identificador
		
		$campos = null;
		$campo_sem_aspas_simples = false;
		
		$id = banco_identificador(Array(
			'id' => banco_escape_field($_REQUEST["name"]),
			'tabela' => Array(
				'nome' => $modulo['tabela']['nome'],
				'campo' => $modulo['tabela']['id'],
				'id_nome' => $modulo['tabela']['id_numerico'],
				'where' => "language='".$_GESTOR['linguagem-codigo']."'",
			),
		));

        // ===== Campos gerais
		
		$campo_nome = "id_usuarios"; $campo_valor = $usuario['id_usuarios']; 			$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = "name"; $post_nome = $campo_nome;      							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		$campo_nome = "id"; $campo_valor = $id; 										$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = "path_prefix"; $post_nome = $campo_nome; 							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		$campo_nome = "template_id"; $post_nome = $campo_nome; 							if($_REQUEST[$post_nome])		$campos[] = Array($campo_nome,banco_escape_field($_REQUEST[$post_nome]));
		
		// ===== Pré-processar fields_schema para converter variáveis de frontend [[...]] para backend @[[...]]@
		
		$open = $_GESTOR['variavel-global']['open'];
		$close = $_GESTOR['variavel-global']['close'];
		$openText = $_GESTOR['variavel-global']['openText'];
		$closeText = $_GESTOR['variavel-global']['closeText'];
		
		$fields_schema_str = $_REQUEST['fields_schema'] ?? '[]';
		
		// Substituição global simples na string JSON antes de salvar
		// Substitui [[publisher#...]] por @[[publisher#...]]@
		// A regex busca por openText + (conteudo) + closeText e substitui por open + conteudo + close
		
		$fields_schema_str = preg_replace("/".preg_quote($openText)."(.+?)".preg_quote($closeText)."/", strtolower($open."$1".$close), $fields_schema_str);
		
		$campo_nome = "fields_schema"; $campo_valor = $fields_schema_str;				if($_REQUEST['fields_schema'])	$campos[] = Array($campo_nome,banco_escape_field($campo_valor));
		
		// ===== Campos comuns
		
		$campo_nome = 'language '; $campo_valor = $_GESTOR['linguagem-codigo']; 		$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['status']; $campo_valor = 'A'; 					$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['versao']; $campo_valor = '1'; 					$campos[] = Array($campo_nome,$campo_valor,$campo_sem_aspas_simples);
		$campo_nome = $modulo['tabela']['data_criacao']; $campo_valor = 'NOW()'; 		$campos[] = Array($campo_nome,$campo_valor,true);
		$campo_nome = $modulo['tabela']['data_modificacao']; $campo_valor = 'NOW()'; 	$campos[] = Array($campo_nome,$campo_valor,true);
	
		banco_insert_name
		(
			$campos,
			$modulo['tabela']['nome']
		);
		
		gestor_redirecionar($_GESTOR['modulo-id'].'/editar/?'.$modulo['tabela']['id'].'='.$id);
	}

	// ===== Selecionar dados do banco de dados
	
	$retorno_bd = banco_select_editar
	(
		banco_campos_virgulas($camposBancoClonar)
		,
		$modulo['tabela']['nome'],
		"WHERE ".$modulo['tabela']['id']."='".$id."'"
		." AND ".$modulo['tabela']['status']."!='D'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
	);
	
	if($_GESTOR['banco-resultado']){
		$path_prefix = (isset($retorno_bd['path_prefix']) ? $retorno_bd['path_prefix'] : '');
		$template_id = (isset($retorno_bd['template_id']) ? $retorno_bd['template_id'] : '');
		$fields_schema = (isset($retorno_bd['fields_schema']) ? $retorno_bd['fields_schema'] : '');
		
		// ===== Processar fields_schema para converter variáveis de backend @[[...]]@ para frontend [[...]]
		
		$open = $_GESTOR['variavel-global']['open'];
		$close = $_GESTOR['variavel-global']['close'];
		$openText = $_GESTOR['variavel-global']['openText'];
		$closeText = $_GESTOR['variavel-global']['closeText'];
		
		$fields_schema = preg_replace("/".preg_quote($open)."(.+?)".preg_quote($close)."/", strtolower($openText."$1".$closeText), $fields_schema);
		
		// ===== Alterar demais variáveis.
		
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#path_prefix#',$path_prefix);
        
        // Injetar o schema existente para o JS carregar
        $fields_schema_decoded = json_decode($fields_schema, true) ?: ['fields' => [], 'template_map' => []];
        $schema_json = json_encode($fields_schema_decoded);
        $_GESTOR['pagina'] .= '<script>var publisher_initial_schema = '.$schema_json.';</script>';

		// ===== Templates para seleção

		$templates = banco_select_name
		(
			banco_campos_virgulas(Array(
				'nome',
				'id'
			))
			,
			'templates',
			"WHERE status='A'"
			.' AND language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"'
			." ORDER BY nome ASC"
		);

		$templates_linked_publisher = banco_select_name
		(
			banco_campos_virgulas(Array(
				't.nome',
				't.id',
				'p.name',
			))
			,
			'templates AS t, publisher AS p',
			"WHERE t.status='A' AND t.id=p.template_id"
			.' AND t.language="'.$_GESTOR['linguagem-codigo'].'" AND p.language="'.$_GESTOR['linguagem-codigo'].'" AND t.target="publisher" AND p.status!="D"'
			." ORDER BY t.nome ASC"
		);

		$countTemplates = 0;
		$countTemplatesLinked = 0;
		if($templates)
		foreach($templates as $template){
			$disabled = '';
			$countTemplates++;
			if($templates_linked_publisher)
			foreach($templates_linked_publisher as $linked){
				if($template['id'] == $linked['t.id']){
					$template['nome'] = '<kbd class="ui basic label">' . $template['nome'] . '</kbd><kbd class="ui teal icon label"><i class="exchange alternate small icon"></i></kbd><kbd class="ui basic label">' . $linked['p.name'] . '</kbd>';
					$disabled = ' disabled';
					$countTemplatesLinked++;
					break;
				}
			}

			$template_id_options .= '<option value="'.$template['id'].'"'.$disabled.'>'.$template['nome'].'</option>';
		}

		if($countTemplatesLinked == 0){
			$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		} else if($countTemplates == $countTemplatesLinked){
			$cel_nome = 'templates-alguns-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		} else {
			$cel_nome = 'templates-todos-linkados-msg'; $_GESTOR['pagina'] = modelo_tag_del($_GESTOR['pagina'],'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		}

		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_placeholder_option#',gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')));
		$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],'#template_id_options#',$template_id_options);
		
		// Incluir regra dinâmica para os campos Labels:

		$prompt[1] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-empty'));
		
		$prompt[2] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-min-length'));
		
		$prompt[3] = gestor_variaveis(Array('modulo' => 'interface','id' => 'validation-max-length'));

		$formLabelRules = [
			'rules' => [
				Array(
					'type' => 'notEmpty',
					'prompt' => $prompt[1],
				),
				Array(
					'type' => 'minLength[3]',
					'prompt' => $prompt[2],
				),
				Array(
					'type' => 'maxLength[100]',
					'prompt' => $prompt[3],
				),
			]
		];

		gestor_js_variavel_incluir('formLabelRules',$formLabelRules);
	} else {
		gestor_redirecionar_raiz();
	}
	
	// ===== Inclusão Módulo JS
	
	gestor_pagina_javascript_incluir();
	
	// ===== Interface clonar finalizar opções
	
	$_GESTOR['interface']['clonar']['finalizar'] = Array(
		'formulario' => Array(
			'validacao' => Array(
				Array(
					'regra' => 'texto-obrigatorio',
					'campo' => 'name',
					'label' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'form-name-label')),
					'identificador' => 'name',
				),
				Array(
					'regra' => 'selecao-obrigatorio',
					'campo' => 'template_id',
					'label' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
					'identificador' => 'template_id',
				),
			),
			'campos' => Array(
				Array(
					'tipo' => 'select',
					'id' => 'template_id',
					'nome' => 'template_id',
					'procurar' => true,
					'limpar' => true,
					'selectClass' => 'templateDropdown',
					'placeholder' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
					'tabela' => Array(
						'nome' => 'templates',
						'campo' => 'nome',
						'id_numerico' => 'id',
						'id_selecionado' => $template_id,
						'where' => 'language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"',
					),
				)
			)
		)
	);
}

function publisher_interfaces_padroes(){
	global $_GESTOR;
	
	$modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];

    switch($_GESTOR['opcao']){
		case 'listar':
			$_GESTOR['interface'][$_GESTOR['opcao']]['finalizar'] = Array(
				'banco' => Array(
					'nome' => $modulo['tabela']['nome'],
					'campos' => Array(
						'name',
						'template_id',
						$modulo['tabela']['data_modificacao'],
					),
					'id' => $modulo['tabela']['id'],
					'status' => $modulo['tabela']['status'],
					'where' => "language='".$_GESTOR['linguagem-codigo']."'",
				),
				'tabela' => Array(
					'colunas' => Array(
						Array(
							'id' => 'name',
							'nome' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-name')),
							'ordenar' => 'asc',
						),
						Array(
							'id' => 'template_id',
							'nome' => gestor_variaveis(Array('modulo' => 'admin-templates','id' => 'form-name-placeholder')),
							'formatar' => Array(
								'id' => 'outraTabela',
								'valor_senao_existe' => '<span class="ui info text">N/A</span>',
								'tabela' => Array(
									'nome' => 'templates',
									'campo_trocar' => 'nome',
									'campo_referencia' => 'id',
									'where' => 'language="'.$_GESTOR['linguagem-codigo'].'" AND target="publisher"',
								),
							)
						),
						Array(
							'id' => $modulo['tabela']['data_modificacao'],
							'nome' => gestor_variaveis(Array('modulo' => 'interface','id' => 'field-date-modification')),
							'formatar' => 'dataHora',
							'nao_procurar' => true,
						),
					),
				),
				'opcoes' => Array(
					'editar' => Array(
						'url' => 'editar/',
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-edit')),
						'icon' => 'edit',
						'cor' => 'basic blue',
					),
					'clonar' => Array(
						'url' => 'clonar/',
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-clone')),
						'icon' => 'clone',
						'cor' => 'basic teal',
					),
					'ativar' => Array(
						'opcao' => 'status',
						'status_atual' => 'I',
						'status_mudar' => 'A',
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-active')),
						'icon' => 'eye slash',
						'cor' => 'basic brown',
					),
					'desativar' => Array(
						'opcao' => 'status',
						'status_atual' => 'A',
						'status_mudar' => 'I',
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-desactive')),
						'icon' => 'eye',
						'cor' => 'basic green',
					),
					'excluir' => Array(
						'opcao' => 'excluir',
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-delete')),
						'icon' => 'trash alternate',
						'cor' => 'basic red',
					),
				),
				'botoes' => Array(
					'adicionar' => Array(
						'url' => 'adicionar/',
						'rotulo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'label-button-insert')),
						'tooltip' => gestor_variaveis(Array('modulo' => 'interface','id' => 'tooltip-button-insert')),
						'icon' => 'plus circle',
						'cor' => 'blue',
					),
				),
			);
		break;
	}
}

// ==== Ajax

function publisher_ajax_template_load(){
	global $_GESTOR;
	
	// ===== Carregar o template selecionado
	
	$template_id = $_REQUEST['params']['template_id'];
	$fields_schema_json = $_REQUEST['params']['fields_schema'] ?? '[]';
	$fields_schema = json_decode($fields_schema_json, true) ?: [];
	
	// ===== Buscar template no banco de dados
	
	$template = banco_select(Array(
		'unico' => true,
		'tabela' => 'templates',
		'campos' => Array(
			'nome',
			'html'
		),
		'extra' => 
			"WHERE id='".banco_escape_field($template_id)."' AND target='publisher' AND language='".$_GESTOR['linguagem-codigo']."' AND status='A'"
	));
	
	if(!$template){
		$_GESTOR['ajax-json'] = Array(
			'status' => 'Erro',
			'message' => 'Template não encontrado.'
		);
		return;
	}
	
	$modelo = [
		'name' => $template['nome'],
		'id' => $template_id
	];
	
	// ===== Extrair campos do HTML
	
	$fields = [];
	if($template['html']){
		preg_match_all('/@\[\[publisher#([^#\]]+)#([^\]]+)\]\]@/', $template['html'], $matches);
		if(isset($matches[1]) && isset($matches[2])){
			$uniqueFields = [];
			foreach($matches[1] as $index => $type){
				$id = $matches[2][$index];
				if(empty($type) || empty($id)) continue;
				$key = $type . '#' . $id;
				if(!isset($uniqueFields[$key])){
					$uniqueFields[$key] = ['id' => $id, 'type' => $type];
				}
			}
			$fields = array_values($uniqueFields);
		}
	}
	
	// ===== Campos do publisher (usar fields_schema se existir, senão vazio para adicionar)
	$fields_schema_decoded = json_decode($fields_schema_json, true) ?: ['fields' => [], 'template_map' => []];
	if (count($fields_schema_decoded['fields']) > 0) {
		$publisherFields = array_map(function($f) {
			return [
				'id' => $f['id'],
				'name' => $f['label'],
				'description' => $f['description'] ?? '',
				'type' => $f['type'],
				'template_field_id' => $f['template_field_id'] ?? null
			];
		}, $fields_schema_decoded['fields']);
	} else {
		$publisherFields = [];
	}
	
	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'modelo' => $modelo,
		'campos' => $fields,
		'publisherFields' => $publisherFields
	);
}

// ==== Start

function publisher_start(){
    global $_GESTOR;
	
	gestor_incluir_bibliotecas();
	
	if($_GESTOR['ajax']){
		interface_ajax_iniciar();
		
		switch($_GESTOR['ajax-opcao']){
			case 'template-load': publisher_ajax_template_load(); break;
		}
		
		interface_ajax_finalizar();
	} else {
		publisher_interfaces_padroes();
		
		interface_iniciar();
		
		switch($_GESTOR['opcao']){
			case 'adicionar': publisher_adicionar(); break;
		    case 'editar': publisher_editar(); break;
		    case 'clonar': publisher_clonar(); break;
		}
		
		interface_finalizar();
	}
}

publisher_start();

?>
