<?php

global $_GESTOR;

$_GESTOR['modulo-id'] = 'admin-environment';
$_GESTOR['modulo#'.$_GESTOR['modulo-id']] = json_decode(file_get_contents(__DIR__ . '/admin-environment.json'), true);

// ===== Interfaces Auxiliares

function admin_environment_env_read(){
    global $_GESTOR;
    
    // Usar as variáveis já carregadas pelo config.php via $_ENV
    // Isso evita conflito com a classe Dotenv que já foi usada no config.php
    $envData = [
        'SITE_NAME' => $_ENV['SITE_NAME'] ?? 'Conn2Flow',
        'USUARIO_RECAPTCHA_ACTIVE' => $_ENV['USUARIO_RECAPTCHA_ACTIVE'] ?? 'false',
        'USUARIO_RECAPTCHA_SITE' => $_ENV['USUARIO_RECAPTCHA_SITE'] ?? '',
        'USUARIO_RECAPTCHA_SERVER' => $_ENV['USUARIO_RECAPTCHA_SERVER'] ?? '',
        'USUARIO_RECAPTCHA_V2_ACTIVE' => $_ENV['USUARIO_RECAPTCHA_V2_ACTIVE'] ?? 'false',
        'USUARIO_RECAPTCHA_V2_SITE' => $_ENV['USUARIO_RECAPTCHA_V2_SITE'] ?? '',
        'USUARIO_RECAPTCHA_V2_SERVER' => $_ENV['USUARIO_RECAPTCHA_V2_SERVER'] ?? '',
        'EMAIL_ACTIVE' => $_ENV['EMAIL_ACTIVE'] ?? 'false',
        'EMAIL_HOST' => $_ENV['EMAIL_HOST'] ?? '',
        'EMAIL_USER' => $_ENV['EMAIL_USER'] ?? '',
        'EMAIL_PASS' => $_ENV['EMAIL_PASS'] ?? '',
        'EMAIL_SECURE' => $_ENV['EMAIL_SECURE'] ?? 'false',
        'EMAIL_PORT' => $_ENV['EMAIL_PORT'] ?? '587',
        'EMAIL_FROM' => $_ENV['EMAIL_FROM'] ?? '',
        'EMAIL_FROM_NAME' => $_ENV['EMAIL_FROM_NAME'] ?? '',
        'EMAIL_REPLY_TO' => $_ENV['EMAIL_REPLY_TO'] ?? '',
        'EMAIL_REPLY_TO_NAME' => $_ENV['EMAIL_REPLY_TO_NAME'] ?? '',
        'LANGUAGE_DEFAULT' => $_ENV['LANGUAGE_DEFAULT'] ?? '',
        'LANGUAGE_WIDGET_ACTIVE' => $_ENV['LANGUAGE_WIDGET_ACTIVE'] ?? 'false',
        'LANGUAGE_AUTO_DETECT' => $_ENV['LANGUAGE_AUTO_DETECT'] ?? 'false',
        'PAYPAL_DEFAULT' => $_ENV['PAYPAL_DEFAULT'] ?? 'padrao',
        'PAYPAL_CLIENT_ID' => $_ENV['PAYPAL_CLIENT_ID'] ?? '',
        'PAYPAL_SECRET' => $_ENV['PAYPAL_SECRET'] ?? '',
        'PAYPAL_MODE' => $_ENV['PAYPAL_MODE'] ?? 'sandbox',
        'PAYPAL_WEBHOOK_ID' => $_ENV['PAYPAL_WEBHOOK_ID'] ?? '',
        // ===== Autenticação, Login Social, 2FA e JWT (req-030 / BATCH-030)
        'AUTH_METHOD_PASSWORD_ACTIVE' => $_ENV['AUTH_METHOD_PASSWORD_ACTIVE'] ?? 'true',
        'AUTH_METHOD_GOOGLE_ACTIVE' => $_ENV['AUTH_METHOD_GOOGLE_ACTIVE'] ?? 'false',
        'OAUTH_GOOGLE_CLIENT_ID' => $_ENV['OAUTH_GOOGLE_CLIENT_ID'] ?? '',
        'OAUTH_GOOGLE_CLIENT_SECRET' => $_ENV['OAUTH_GOOGLE_CLIENT_SECRET'] ?? '',
        'AUTH_METHOD_META_ACTIVE' => $_ENV['AUTH_METHOD_META_ACTIVE'] ?? 'false',
        'OAUTH_META_APP_ID' => $_ENV['OAUTH_META_APP_ID'] ?? '',
        'OAUTH_META_APP_SECRET' => $_ENV['OAUTH_META_APP_SECRET'] ?? '',
        'AUTH_METHOD_EMAIL_ACTIVE' => $_ENV['AUTH_METHOD_EMAIL_ACTIVE'] ?? 'false',
        'AUTH_2FA_REQUIRED' => $_ENV['AUTH_2FA_REQUIRED'] ?? 'false',
        'AUTH_2FA_METHOD_APP' => $_ENV['AUTH_2FA_METHOD_APP'] ?? 'true',
        'AUTH_2FA_METHOD_EMAIL' => $_ENV['AUTH_2FA_METHOD_EMAIL'] ?? 'true',
        'AUTH_JWT_ROTATION_DAYS' => $_ENV['AUTH_JWT_ROTATION_DAYS'] ?? '30',
        'AUTH_JWT_GRACE_HOURS' => $_ENV['AUTH_JWT_GRACE_HOURS'] ?? '24',
        'AUTH_API_ALLOWED_PROFILES' => $_ENV['AUTH_API_ALLOWED_PROFILES'] ?? '1',
        'AUTH_API_METHOD_PASSWORD_ACTIVE' => $_ENV['AUTH_API_METHOD_PASSWORD_ACTIVE'] ?? 'true',
        'AUTH_API_METHOD_EMAIL_ACTIVE' => $_ENV['AUTH_API_METHOD_EMAIL_ACTIVE'] ?? 'false',
        'AUTH_API_2FA_REQUIRED' => $_ENV['AUTH_API_2FA_REQUIRED'] ?? 'false',
        'AUTH_API_2FA_METHOD_APP' => $_ENV['AUTH_API_2FA_METHOD_APP'] ?? 'true',
        'AUTH_API_2FA_METHOD_EMAIL' => $_ENV['AUTH_API_2FA_METHOD_EMAIL'] ?? 'true',
    ];

    return $envData;
}

function admin_environment_env_write($data){
    global $_GESTOR;
    
    // Caminho do arquivo .env
    $envPath = $_GESTOR['AUTH_PATH_SERVER'] . '.env';
    
    if(file_exists($envPath)){
        // Ler conteúdo atual
        $content = file_get_contents($envPath);
        $lines = explode("\n", $content);
        
        // Atualizar linhas específicas
        foreach($lines as $key => $line){
            $line = trim($line);
            
            // Pular comentários e linhas vazias
            if(empty($line) || strpos($line, '#') === 0){
                continue;
            }
            
            // Procurar pela variável
            foreach($data as $varName => $varValue){
                if(strpos($line, $varName . '=') === 0){
                    // Verificar se o valor precisa de aspas (contém espaços ou caracteres especiais)
                    $formattedValue = admin_environment_env_format_value($varValue);
                    $lines[$key] = $varName . '=' . $formattedValue;
                    unset($data[$varName]);
                    break;
                }
            }
        }
        
        // Adicionar novas variáveis se não existirem
        if(!empty($data)){
            $lines[] = '';
            $lines[] = '# ===== Novas configurações adicionadas pelo Admin Environment';
            foreach($data as $varName => $varValue){
                $formattedValue = admin_environment_env_format_value($varValue);
                $lines[] = $varName . '=' . $formattedValue;
            }
        }
        
        // Salvar arquivo
        $newContent = implode("\n", $lines);
        file_put_contents($envPath, $newContent);
        
        return true;
    }
    
    return false;
}

function admin_environment_test_recaptcha($token, $serverKey){
    global $_GESTOR;

    // Verificar o token com a API do Google reCAPTCHA v3
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret' => $serverKey,
        'response' => $token
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $arrResponse = json_decode($response, true);
    
    // Verificar se a resposta foi bem-sucedida
    if ($arrResponse['success'] && isset($arrResponse['score'])) {
        $score = $arrResponse['score'];
        $action = $arrResponse['action'] ?? '';
        
        // Para teste, consideramos sucesso se score >= 0.5
        if ($score >= 0.5) {
            return [
                'success' => true,
                'score' => $score,
                'action' => $action,
                'message' => str_replace('{score}', $score, gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-test-success')))
            ];
        } else {
            return [
                'success' => false,
                'score' => $score,
                'action' => $action,
                'message' => str_replace('{score}', $score, gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-test-low-score')))
            ];
        }
    }

    // Se não foi sucesso, verificar códigos de erro
    $errorCodes = $arrResponse['error-codes'] ?? [];
    $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-generic'));
    
    if (in_array('missing-input-secret', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-missing-secret'));
    } elseif (in_array('invalid-input-secret', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-invalid-secret'));
    } elseif (in_array('missing-input-response', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-missing-response'));
    } elseif (in_array('invalid-input-response', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-invalid-response'));
    } elseif (in_array('timeout-or-duplicate', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-timeout-duplicate'));
    }
    
    return [
        'success' => false,
        'error_codes' => $errorCodes,
        'message' => $errorMessage
    ];
}

function admin_environment_test_recaptcha_v2($token, $serverKey){
    global $_GESTOR;

    // Verificar o token com a API do Google reCAPTCHA v2
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret' => $serverKey,
        'response' => $token
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $arrResponse = json_decode($response, true);
    
    // Verificar se a resposta foi bem-sucedida (V2 não possui score)
    if ($arrResponse['success']) {
        return [
            'success' => true,
            'hostname' => $arrResponse['hostname'] ?? '',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-v2-test-success'))
        ];
    }

    // Se não foi sucesso, verificar códigos de erro
    $errorCodes = $arrResponse['error-codes'] ?? [];
    $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-generic'));
    
    if (in_array('missing-input-secret', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-missing-secret'));
    } elseif (in_array('invalid-input-secret', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-invalid-secret'));
    } elseif (in_array('missing-input-response', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-missing-response'));
    } elseif (in_array('invalid-input-response', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-invalid-response'));
    } elseif (in_array('timeout-or-duplicate', $errorCodes)) {
        $errorMessage = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-timeout-duplicate'));
    }
    
    return [
        'success' => false,
        'error_codes' => $errorCodes,
        'message' => $errorMessage
    ];
}

function admin_environment_test_email($config){
    global $_GESTOR;
    
    // Enviar email de teste
    gestor_incluir_biblioteca('comunicacao');

    $default = [
        'destinatarios' => [
            [
                'email' => $config['EMAIL_FROM'],
                'nome' => $config['EMAIL_FROM_NAME']
            ]
        ],
        'mensagem' => [
            'assunto' => 'Teste de Email - Admin Environment - nº ' . date('YmdHis'),
            'html' => '<h1>Teste de Configuração de Email</h1><p>Este é um email de teste enviado pelo módulo Admin Environment.</p><p>Data/Hora: ' . date('d/m/Y H:i:s') . '</p>'
        ]
    ];

    $default = array_merge($default, $config);

    return comunicacao_email($default);
}

function admin_environment_env_format_value($value){
    // Se o valor contém espaços, aspas simples, aspas duplas ou outros caracteres especiais, envolve em aspas duplas
    if (preg_match('/[\s\'"\\\\]/', $value)) {
        // Escapar aspas duplas dentro do valor
        $value = str_replace('"', '\\"', $value);
        return '"' . $value . '"';
    }
    
    // Para valores booleanos e numéricos simples, manter sem aspas
    if ($value === 'true' || $value === 'false' || is_numeric($value)) {
        return $value;
    }
    
    // Para outros valores simples, manter sem aspas
    return $value;
}

// ===== Interfaces Principais

function admin_environment_raiz(){
    global $_GESTOR;

    $modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];

    // ===== Ler configurações atuais do .env
    
    $envData = admin_environment_env_read();

    // ===== Preparar dados para o template
    
    $dados = [
        'site_name' => $envData['SITE_NAME'] ?? 'Conn2Flow',
        'usuario_recaptcha_active' => $envData['USUARIO_RECAPTCHA_ACTIVE'] ?? 'false',
        'usuario_recaptcha_site' => $envData['USUARIO_RECAPTCHA_SITE'] ?? '',
        'usuario_recaptcha_server' => $envData['USUARIO_RECAPTCHA_SERVER'] ?? '',
        'usuario_recaptcha_v2_active' => $envData['USUARIO_RECAPTCHA_V2_ACTIVE'] ?? 'false',
        'usuario_recaptcha_v2_site' => $envData['USUARIO_RECAPTCHA_V2_SITE'] ?? '',
        'usuario_recaptcha_v2_server' => $envData['USUARIO_RECAPTCHA_V2_SERVER'] ?? '',
        'email_active' => $envData['EMAIL_ACTIVE'] ?? 'false',
        'email_host' => $envData['EMAIL_HOST'] ?? '',
        'email_user' => $envData['EMAIL_USER'] ?? '',
        'email_pass' => $envData['EMAIL_PASS'] ?? '',
        'email_secure' => $envData['EMAIL_SECURE'] ?? 'false',
        'email_port' => $envData['EMAIL_PORT'] ?? '587',
        'email_from' => $envData['EMAIL_FROM'] ?? '',
        'email_from_name' => $envData['EMAIL_FROM_NAME'] ?? '',
        'email_reply_to' => $envData['EMAIL_REPLY_TO'] ?? '',
        'email_reply_to_name' => $envData['EMAIL_REPLY_TO_NAME'] ?? '',
        'language_default' => $envData['LANGUAGE_DEFAULT'] ?? 'pt-br',
        'language_widget_active' => $envData['LANGUAGE_WIDGET_ACTIVE'] ?? 'false',
        'language_auto_detect' => $envData['LANGUAGE_AUTO_DETECT'] ?? 'false',
        'paypal_default' => $envData['PAYPAL_DEFAULT'] ?? 'padrao',
        'paypal_client_id' => $envData['PAYPAL_CLIENT_ID'] ?? '',
        'paypal_secret' => $envData['PAYPAL_SECRET'] ?? '',
        'paypal_mode' => $envData['PAYPAL_MODE'] ?? 'sandbox',
        'paypal_webhook_id' => $envData['PAYPAL_WEBHOOK_ID'] ?? '',
        'auth_method_password_active' => $envData['AUTH_METHOD_PASSWORD_ACTIVE'] ?? 'true',
        'auth_method_google_active' => $envData['AUTH_METHOD_GOOGLE_ACTIVE'] ?? 'false',
        'oauth_google_client_id' => $envData['OAUTH_GOOGLE_CLIENT_ID'] ?? '',
        'oauth_google_client_secret' => $envData['OAUTH_GOOGLE_CLIENT_SECRET'] ?? '',
        'auth_method_meta_active' => $envData['AUTH_METHOD_META_ACTIVE'] ?? 'false',
        'oauth_meta_app_id' => $envData['OAUTH_META_APP_ID'] ?? '',
        'oauth_meta_app_secret' => $envData['OAUTH_META_APP_SECRET'] ?? '',
        'auth_method_email_active' => $envData['AUTH_METHOD_EMAIL_ACTIVE'] ?? 'false',
        'auth_2fa_required' => $envData['AUTH_2FA_REQUIRED'] ?? 'false',
        'auth_2fa_method_app' => $envData['AUTH_2FA_METHOD_APP'] ?? 'true',
        'auth_2fa_method_email' => $envData['AUTH_2FA_METHOD_EMAIL'] ?? 'true',
        'auth_jwt_rotation_days' => $envData['AUTH_JWT_ROTATION_DAYS'] ?? '30',
        'auth_jwt_grace_hours' => $envData['AUTH_JWT_GRACE_HOURS'] ?? '24',
        'auth_api_allowed_profiles' => $envData['AUTH_API_ALLOWED_PROFILES'] ?? '1',
        'auth_api_method_password_active' => $envData['AUTH_API_METHOD_PASSWORD_ACTIVE'] ?? 'true',
        'auth_api_method_email_active' => $envData['AUTH_API_METHOD_EMAIL_ACTIVE'] ?? 'false',
        'auth_api_2fa_required' => $envData['AUTH_API_2FA_REQUIRED'] ?? 'false',
        'auth_api_2fa_method_app' => $envData['AUTH_API_2FA_METHOD_APP'] ?? 'true',
        'auth_api_2fa_method_email' => $envData['AUTH_API_2FA_METHOD_EMAIL'] ?? 'true',
    ];

    // ===== URIs de callback OAuth calculadas (somente leitura)

    gestor_incluir_biblioteca('oauth');
    $dados['oauth_google_redirect_uri'] = function_exists('oauth_redirect_uri') ? oauth_redirect_uri('google') : '';
    $dados['oauth_meta_redirect_uri'] = function_exists('oauth_redirect_uri') ? oauth_redirect_uri('meta') : '';

    // ===== Perfis autorizados para emissÃ£o de chaves de API

    $perfisPermitidos = array_filter(array_map('trim', explode(',', (string)$dados['auth_api_allowed_profiles'])));
    $perfis = banco_select(Array(
        'tabela' => 'usuarios_perfis',
        'campos' => Array('id_usuarios_perfis', 'id', 'nome'),
        'extra' => "WHERE status!='D' AND language='".banco_escape_field($_GESTOR['linguagem-codigo'])."' ORDER BY nome ASC",
    ));

    $apiProfilesHtml = '';
    if($perfis){
        foreach($perfis as $perfil){
            $perfilId = (string)$perfil['id_usuarios_perfis'];
            $perfilNome = isset($perfil['nome']) && $perfil['nome'] !== '' ? $perfil['nome'] : $perfil['id'];
            $checked = in_array($perfilId, $perfisPermitidos, true) ? ' checked' : '';
            $apiProfilesHtml .= '<div class="field"><div class="ui checkbox">'
                . '<input type="checkbox" class="auth-api-profile" name="auth_api_allowed_profiles[]" value="'.htmlspecialchars($perfilId, ENT_QUOTES).'"'.$checked.'>'
                . '<label>'.htmlspecialchars($perfilNome).' <small class="ui grey text">#'.htmlspecialchars($perfilId).'</small></label>'
                . '</div></div>';
        }
    } else {
        $apiProfilesHtml = '<div class="ui warning message">Nenhum perfil ativo encontrado.</div>';
    }
    $dados['auth-api-profiles'] = $apiProfilesHtml;

    // ===== Gerar opções de idioma

    $languages = $_GESTOR['languages'] ?? [];
    
    $languageOptions = '';
    foreach ($languages as $lang) {
        $label = gestor_variaveis(Array('id' => 'language-label-' . $lang));
        $selected = ($dados['language_default'] == $lang) ? ' selected' : '';
        $languageOptions .= '<option value="' . $lang . '"' . $selected . '>' . $label . '</option>';
    }
    $dados['language-options'] = $languageOptions;

    // ===== Inclusão do CodeMirror

	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/codemirror.min.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/theme/tomorrow-night-bright.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/dialog/dialog.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/display/fullscreen.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/matchesonscrollbar.css" />');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/codemirror.min.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/selection/active-line.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/dialog/dialog.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/searchcursor.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/search.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/scroll/annotatescrollbar.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/matchesonscrollbar.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/jump-to-line.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/edit/matchbrackets.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/display/fullscreen.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/mode/xml/xml.js"></script>');

    // ===== Inclusão Módulo JS
	
	gestor_pagina_javascript_incluir();
    
    // ===== Passar dados para o template
    
    // Site
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#site-name#', $dados['site_name']);

    // Usuário / reCAPTCHA
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-active#', $dados['usuario_recaptcha_active']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-active-checked#', $dados['usuario_recaptcha_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-site#', $dados['usuario_recaptcha_site']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-server#', $dados['usuario_recaptcha_server']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-v2-active-checked#', $dados['usuario_recaptcha_v2_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-v2-site#', $dados['usuario_recaptcha_v2_site']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#usuario-recaptcha-v2-server#', $dados['usuario_recaptcha_v2_server']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#recaptcha-v2-section-class#', $dados['usuario_recaptcha_active'] === 'true' ? '' : 'hidden');

    // Email
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-active#', $dados['email_active']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-active-checked#', $dados['email_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-host#', $dados['email_host']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-user#', $dados['email_user']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-pass#', $dados['email_pass']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-secure#', $dados['email_secure']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-secure-checked#', $dados['email_secure'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-port#', $dados['email_port']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-from#', $dados['email_from']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-from-name#', $dados['email_from_name']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-reply-to#', $dados['email_reply_to']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#email-reply-to-name#', $dados['email_reply_to_name']);

    // Linguagem
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#language-widget-active-checked#', $dados['language_widget_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#language-auto-detect-checked#', $dados['language_auto_detect'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#language-options#', $dados['language-options']);

    // PayPal
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-default-padrao-selected#', $dados['paypal_default'] === 'padrao' ? 'selected' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-default-gateway-selected#', $dados['paypal_default'] === 'gateway' ? 'selected' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-mode-sandbox-selected#', $dados['paypal_mode'] === 'sandbox' ? 'selected' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-mode-live-selected#', $dados['paypal_mode'] === 'live' ? 'selected' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-client-id#', $dados['paypal_client_id']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-secret#', $dados['paypal_secret']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#paypal-webhook-id#', $dados['paypal_webhook_id']);

    // Autenticação / Login Social / 2FA / JWT (req-030)
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-method-password-active-checked#', $dados['auth_method_password_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-method-google-active-checked#', $dados['auth_method_google_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-google-section-class#', $dados['auth_method_google_active'] === 'true' ? '' : 'hidden');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-google-client-id#', $dados['oauth_google_client_id']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-google-client-secret#', $dados['oauth_google_client_secret']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-google-redirect-uri#', $dados['oauth_google_redirect_uri']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-method-meta-active-checked#', $dados['auth_method_meta_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-meta-section-class#', $dados['auth_method_meta_active'] === 'true' ? '' : 'hidden');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-meta-app-id#', $dados['oauth_meta_app_id']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-meta-app-secret#', $dados['oauth_meta_app_secret']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#oauth-meta-redirect-uri#', $dados['oauth_meta_redirect_uri']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-method-email-active-checked#', $dados['auth_method_email_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-2fa-required-checked#', $dados['auth_2fa_required'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-2fa-method-app-checked#', $dados['auth_2fa_method_app'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-2fa-method-email-checked#', $dados['auth_2fa_method_email'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-jwt-rotation-days#', $dados['auth_jwt_rotation_days']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-jwt-grace-hours#', $dados['auth_jwt_grace_hours']);

    // API
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-profiles#', $dados['auth-api-profiles']);
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-method-password-active-checked#', $dados['auth_api_method_password_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-method-email-active-checked#', $dados['auth_api_method_email_active'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-2fa-required-checked#', $dados['auth_api_2fa_required'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-2fa-method-app-checked#', $dados['auth_api_2fa_method_app'] === 'true' ? 'checked' : '');
    $_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'], '#auth-api-2fa-method-email-checked#', $dados['auth_api_2fa_method_email'] === 'true' ? 'checked' : '');
}

function admin_environment_interfaces_padroes(){
	global $_GESTOR;
	
	$modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];
	
	switch($_GESTOR['opcao']){
		case 'listar':
			
		break;
	}
}

// ==== Ajax

function admin_environment_ajax_opcao(){
    global $_GESTOR;

    $modulo = $_GESTOR['modulo#'.$_GESTOR['modulo-id']];

    // ===== Lógica

    $payload = [];

    // ===== Dados de Retorno

    if(true){
        $_GESTOR['ajax-json'] = Array(
            'payload' => $payload,
            'status' => 'Ok',
        );
    } else {
        $_GESTOR['ajax-json'] = Array(
            'error' => 'Error msg'
        );
    }
}

function admin_environment_ajax_salvar(){
    global $_GESTOR;
    
    $data = [];
    
    // Coletar dados do formulário — Site
    if(isset($_REQUEST['site_name'])) $data['SITE_NAME'] = $_REQUEST['site_name'];

    // Coletar dados do formulário — Usuário
    if(isset($_REQUEST['usuario_recaptcha_active'])) $data['USUARIO_RECAPTCHA_ACTIVE'] = $_REQUEST['usuario_recaptcha_active'];
    if(isset($_REQUEST['usuario_recaptcha_site'])) $data['USUARIO_RECAPTCHA_SITE'] = $_REQUEST['usuario_recaptcha_site'];
    if(isset($_REQUEST['usuario_recaptcha_server'])) $data['USUARIO_RECAPTCHA_SERVER'] = $_REQUEST['usuario_recaptcha_server'];
    if(isset($_REQUEST['usuario_recaptcha_v2_active'])) $data['USUARIO_RECAPTCHA_V2_ACTIVE'] = $_REQUEST['usuario_recaptcha_v2_active'];
    if(isset($_REQUEST['usuario_recaptcha_v2_site'])) $data['USUARIO_RECAPTCHA_V2_SITE'] = $_REQUEST['usuario_recaptcha_v2_site'];
    if(isset($_REQUEST['usuario_recaptcha_v2_server'])) $data['USUARIO_RECAPTCHA_V2_SERVER'] = $_REQUEST['usuario_recaptcha_v2_server'];

    // Coletar dados do formulário — Email
    if(isset($_REQUEST['email_active'])) $data['EMAIL_ACTIVE'] = $_REQUEST['email_active'];
    if(isset($_REQUEST['email_host'])) $data['EMAIL_HOST'] = $_REQUEST['email_host'];
    if(isset($_REQUEST['email_user'])) $data['EMAIL_USER'] = $_REQUEST['email_user'];
    if(isset($_REQUEST['email_pass'])) $data['EMAIL_PASS'] = $_REQUEST['email_pass'];
    if(isset($_REQUEST['email_secure'])) $data['EMAIL_SECURE'] = $_REQUEST['email_secure'];
    if(isset($_REQUEST['email_port'])) $data['EMAIL_PORT'] = $_REQUEST['email_port'];
    if(isset($_REQUEST['email_from'])) $data['EMAIL_FROM'] = $_REQUEST['email_from'];
    if(isset($_REQUEST['email_from_name'])) $data['EMAIL_FROM_NAME'] = $_REQUEST['email_from_name'];
    if(isset($_REQUEST['email_reply_to'])) $data['EMAIL_REPLY_TO'] = $_REQUEST['email_reply_to'];
    if(isset($_REQUEST['email_reply_to_name'])) $data['EMAIL_REPLY_TO_NAME'] = $_REQUEST['email_reply_to_name'];

    // Coletar dados do formulário — Linguagem
    if(isset($_REQUEST['language_default'])) $data['LANGUAGE_DEFAULT'] = $_REQUEST['language_default'];
    if(isset($_REQUEST['language_widget_active'])) $data['LANGUAGE_WIDGET_ACTIVE'] = $_REQUEST['language_widget_active'];
    if(isset($_REQUEST['language_auto_detect'])) $data['LANGUAGE_AUTO_DETECT'] = $_REQUEST['language_auto_detect'];

    // Coletar dados do formulário — PayPal
    if(isset($_REQUEST['paypal_default'])) $data['PAYPAL_DEFAULT'] = $_REQUEST['paypal_default'];
    if(isset($_REQUEST['paypal_client_id'])) $data['PAYPAL_CLIENT_ID'] = $_REQUEST['paypal_client_id'];
    if(isset($_REQUEST['paypal_secret'])) $data['PAYPAL_SECRET'] = $_REQUEST['paypal_secret'];
    if(isset($_REQUEST['paypal_mode'])) $data['PAYPAL_MODE'] = $_REQUEST['paypal_mode'];
    if(isset($_REQUEST['paypal_webhook_id'])) $data['PAYPAL_WEBHOOK_ID'] = $_REQUEST['paypal_webhook_id'];

    // Coletar dados do formulário — Autenticação / Login Social / 2FA / JWT (req-030)
    if(isset($_REQUEST['auth_method_password_active'])) $data['AUTH_METHOD_PASSWORD_ACTIVE'] = $_REQUEST['auth_method_password_active'];
    if(isset($_REQUEST['auth_method_google_active'])) $data['AUTH_METHOD_GOOGLE_ACTIVE'] = $_REQUEST['auth_method_google_active'];
    if(isset($_REQUEST['oauth_google_client_id'])) $data['OAUTH_GOOGLE_CLIENT_ID'] = $_REQUEST['oauth_google_client_id'];
    if(isset($_REQUEST['oauth_google_client_secret'])) $data['OAUTH_GOOGLE_CLIENT_SECRET'] = $_REQUEST['oauth_google_client_secret'];
    if(isset($_REQUEST['auth_method_meta_active'])) $data['AUTH_METHOD_META_ACTIVE'] = $_REQUEST['auth_method_meta_active'];
    if(isset($_REQUEST['oauth_meta_app_id'])) $data['OAUTH_META_APP_ID'] = $_REQUEST['oauth_meta_app_id'];
    if(isset($_REQUEST['oauth_meta_app_secret'])) $data['OAUTH_META_APP_SECRET'] = $_REQUEST['oauth_meta_app_secret'];
    if(isset($_REQUEST['auth_method_email_active'])) $data['AUTH_METHOD_EMAIL_ACTIVE'] = $_REQUEST['auth_method_email_active'];
    if(isset($_REQUEST['auth_2fa_required'])) $data['AUTH_2FA_REQUIRED'] = $_REQUEST['auth_2fa_required'];
    if(isset($_REQUEST['auth_2fa_method_app'])) $data['AUTH_2FA_METHOD_APP'] = $_REQUEST['auth_2fa_method_app'];
    if(isset($_REQUEST['auth_2fa_method_email'])) $data['AUTH_2FA_METHOD_EMAIL'] = $_REQUEST['auth_2fa_method_email'];
    if(isset($_REQUEST['auth_jwt_rotation_days'])) $data['AUTH_JWT_ROTATION_DAYS'] = $_REQUEST['auth_jwt_rotation_days'];
    if(isset($_REQUEST['auth_jwt_grace_hours'])) $data['AUTH_JWT_GRACE_HOURS'] = $_REQUEST['auth_jwt_grace_hours'];

    // Coletar dados do formulÃ¡rio â€” API (req-033)
    if(isset($_REQUEST['auth_api_allowed_profiles'])) $data['AUTH_API_ALLOWED_PROFILES'] = preg_replace('/[^0-9,]/', '', (string)$_REQUEST['auth_api_allowed_profiles']);
    if(isset($_REQUEST['auth_api_method_password_active'])) $data['AUTH_API_METHOD_PASSWORD_ACTIVE'] = $_REQUEST['auth_api_method_password_active'];
    if(isset($_REQUEST['auth_api_method_email_active'])) $data['AUTH_API_METHOD_EMAIL_ACTIVE'] = $_REQUEST['auth_api_method_email_active'];
    if(isset($_REQUEST['auth_api_2fa_required'])) $data['AUTH_API_2FA_REQUIRED'] = $_REQUEST['auth_api_2fa_required'];
    if(isset($_REQUEST['auth_api_2fa_method_app'])) $data['AUTH_API_2FA_METHOD_APP'] = $_REQUEST['auth_api_2fa_method_app'];
    if(isset($_REQUEST['auth_api_2fa_method_email'])) $data['AUTH_API_2FA_METHOD_EMAIL'] = $_REQUEST['auth_api_2fa_method_email'];

    // Salvar no .env
    $success = admin_environment_env_write($data);
    
    $_GESTOR['ajax-json'] = [
        'status' => $success ? 'success' : 'error',
        'message' => $success 
            ? gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'save-success'))
            : gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'save-error'))
    ];
}

function admin_environment_ajax_testar_recaptcha(){
    global $_GESTOR;
    
    $token = $_REQUEST['recaptcha_token'] ?? '';
    $serverKey = $_REQUEST['server_key'] ?? '';
    
    if (empty($token) || empty($serverKey)) {
        $_GESTOR['ajax-json'] = [
            'status' => 'error',
            'message' => 'Token ou Server Key do reCAPTCHA não fornecidos.'
        ];
        return;
    }
    
    $result = admin_environment_test_recaptcha($token, $serverKey);
    
    $_GESTOR['ajax-json'] = [
        'status' => $result['success'] ? 'success' : 'error',
        'message' => $result['message']
    ];
}

function admin_environment_ajax_testar_recaptcha_v2(){
    global $_GESTOR;
    
    $token = $_REQUEST['recaptcha_token'] ?? '';
    $serverKey = $_REQUEST['server_key'] ?? '';
    
    if (empty($token) || empty($serverKey)) {
        $_GESTOR['ajax-json'] = [
            'status' => 'error',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'recaptcha-error-missing-response'))
        ];
        return;
    }
    
    $result = admin_environment_test_recaptcha_v2($token, $serverKey);
    
    $_GESTOR['ajax-json'] = [
        'status' => $result['success'] ? 'success' : 'error',
        'message' => $result['message']
    ];
}

function admin_environment_ajax_testar_email(){
    global $_GESTOR;
    
    $config = [
        'EMAIL_TESTS' => true,
        'EMAIL_DEBUG' => $_REQUEST['email_debug'] ? ($_REQUEST['email_debug'] === 'true'? true : false) : false,
        'EMAIL_HOST' => $_REQUEST['email_host'] ?? '',
        'EMAIL_USER' => $_REQUEST['email_user'] ?? '',
        'EMAIL_PASS' => $_REQUEST['email_pass'] ?? '',
        'EMAIL_SECURE' => $_REQUEST['email_secure'] ? ($_REQUEST['email_secure'] === 'true'? true : false) : false,
        'EMAIL_PORT' => $_REQUEST['email_port'] ?? '587',
        'EMAIL_FROM' => $_REQUEST['email_from'] ?? '',
        'EMAIL_FROM_NAME' => $_REQUEST['email_from_name'] ?? '',
        'EMAIL_REPLY_TO' => $_REQUEST['email_reply_to'] ?? '',
        'EMAIL_REPLY_TO_NAME' => $_REQUEST['email_reply_to_name'] ?? ''
    ];

    if($config['EMAIL_DEBUG']) {
        ob_start();
    }
    
    $success = admin_environment_test_email($config);
    
    if($config['EMAIL_DEBUG']) {
        $debugMsgs = ob_get_clean();
        // Aplica os filtros
        $debugMsgs = html_entity_decode($debugMsgs);
        $debugMsgs = str_replace(['<br>', '<br/>', '<br />'], '', $debugMsgs);

        // Exibe o conteúdo filtrado
        echo "############### ".gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-head-title'))." ###############\n";
        echo $debugMsgs."\n\n############### ".gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-head-status'))." ###############\n";
        echo $success ? gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-success-msg'))."\n" : gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-error-msg'))."\n";
        echo $success ? gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-success-description'))."\n" : gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-error-description'))."\n";
        echo "############### ".gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-head-bottom'))." ###############";
        exit;
    } else {
        $_GESTOR['ajax-json'] = [
            'status' => $success ? 'success' : 'error',
            'message' => $success ? gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-success-description')) : gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => 'email-tests-error-description'))
        ];
    }
}

function admin_environment_ajax_testar_paypal(){
    global $_GESTOR;
    global $_CONFIG;
    
    $client_id = $_REQUEST['paypal_client_id'] ?? '';
    $secret = $_REQUEST['paypal_secret'] ?? '';
    $mode = $_REQUEST['paypal_mode'] ?? 'sandbox';
    
    if (empty($client_id) || empty($secret)) {
        $_GESTOR['ajax-json'] = [
            'status' => 'error',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'paypal-test-missing-fields'))
        ];
        return;
    }
    
    // Incluir biblioteca PayPal
    gestor_incluir_biblioteca('paypal');
    
    // Configurar $_CONFIG temporariamente com as credenciais do formulário
    $_CONFIG['paypal'] = Array(
        'default' => 'padrao',
        'mode' => $mode,
        'webhook_id' => $_REQUEST['paypal_webhook_id'] ?? '',
        $mode => Array(
            'client_id' => $client_id,
            'client_secret' => $secret,
        ),
    );
    
    // Forçar nova autenticação (ignorar cache)
    $token = paypal_autenticar(Array('force_refresh' => true));
    
    if ($token && !empty($token['access_token'])) {
        $_GESTOR['ajax-json'] = [
            'status' => 'success',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'paypal-test-success'))
        ];
    } else {
        $_GESTOR['ajax-json'] = [
            'status' => 'error',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'paypal-test-error'))
        ];
    }
}

function admin_environment_ajax_rotacionar_jwt(){
    global $_GESTOR;

    gestor_incluir_biblioteca('jwt');

    try {
        $nova = jwt_rotate_keys();

        $_GESTOR['ajax-json'] = [
            'status' => 'success',
            'key_id' => $nova['key_id'] ?? '',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'jwt-rotate-success')),
        ];
    } catch (Exception $e){
        $_GESTOR['ajax-json'] = [
            'status' => 'error',
            'message' => gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'], 'id' => 'jwt-rotate-error')),
        ];
    }
}

// ==== Start

function admin_environment_start(){
    global $_GESTOR;

    gestor_incluir_bibliotecas();

    if($_GESTOR['ajax']){
        interface_ajax_iniciar();

        switch($_GESTOR['ajax-opcao']){
            case 'opcao': admin_environment_ajax_opcao(); break;
            case 'salvar': admin_environment_ajax_salvar(); break;
            case 'testar-recaptcha': admin_environment_ajax_testar_recaptcha(); break;
            case 'testar-recaptcha-v2': admin_environment_ajax_testar_recaptcha_v2(); break;
            case 'testar-email': admin_environment_ajax_testar_email(); break;
            case 'testar-paypal': admin_environment_ajax_testar_paypal(); break;
            case 'rotacionar-jwt': admin_environment_ajax_rotacionar_jwt(); break;
        }

        interface_ajax_finalizar();
    } else {
        admin_environment_interfaces_padroes();

        interface_iniciar();

        switch($_GESTOR['opcao']){
            case 'raiz': admin_environment_raiz(); break;
        }

        interface_finalizar();
    }
}

admin_environment_start();

?>
