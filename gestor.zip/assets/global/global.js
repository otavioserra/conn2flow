(function () {
	'use strict';

	function csrfToken() {
		var meta = document.querySelector('meta[name="csrf-token"]');
		return meta ? meta.getAttribute('content') : '';
	}

	function metodoMutavel(method) {
		return ['POST', 'PUT', 'PATCH', 'DELETE'].indexOf(String(method || 'GET').toUpperCase()) !== -1;
	}

	function mesmaOrigem(input) {
		try {
			var alvo = typeof input === 'string' ? input : input.url;
			return new URL(alvo, window.location.href).origin === window.location.origin;
		} catch (error) {
			return false;
		}
	}

	// Todos os $.ajax do painel recebem o mesmo cabeçalho, inclusive módulos legados.
	if (window.jQuery) {
		window.jQuery.ajaxPrefilter(function (options, originalOptions, xhr) {
			var token = csrfToken();
			if (token && !options.crossDomain && metodoMutavel(options.type)) xhr.setRequestHeader('X-CSRF-Token', token);
		});
	}

	// Cobre os fluxos modernos que usam fetch diretamente.
	if (window.fetch) {
		var fetchOriginal = window.fetch.bind(window);
		window.fetch = function (input, init) {
			init = init || {};
			var token = csrfToken();
			if (token && mesmaOrigem(input) && metodoMutavel(init.method)) {
				var headers = new Headers(init.headers || {});
				headers.set('X-CSRF-Token', token);
				init.headers = headers;
			}
			return fetchOriginal(input, init);
		};
	}

	document.addEventListener('submit', function (event) {
		var form = event.target;
		var token = csrfToken();
		if (!token || !form || !mesmaOrigem(form.action || window.location.href) || String(form.method || 'GET').toUpperCase() === 'GET') return;
		var input = form.querySelector('input[name="_csrf_token"]');
		if (!input) {
			input = document.createElement('input');
			input.type = 'hidden';
			input.name = '_csrf_token';
			form.appendChild(input);
		}
		input.value = token;
	}, true);
})();

$(document).ready(function () {
	// ===== Menu Principal do gestor.

	if ($('.menuComputerCont').length > 0) {
		// ===== Configurações do Menu
		var menuConfig = {
			defaultWidth: 250,
			minWidth: 200,
			maxWidth: 450,
			mobileBreakpoint: 1024, // Inclui tablets no comportamento mobile (sidebar overlay)
			storageKeys: {
				width: 'gestor-menu-width',
				closed: 'gestor-menu-closed',
				scroll: 'menuComputerContScroll',
				scrollMobile: 'menuMobileContScroll'
			}
		};

		// ===== Funções Auxiliares do Menu
		function isMobile() {
			return window.innerWidth <= menuConfig.mobileBreakpoint;
		}

		function getMenuState() {
			return {
				width: parseInt(localStorage.getItem(menuConfig.storageKeys.width)) || menuConfig.defaultWidth,
				closed: localStorage.getItem(menuConfig.storageKeys.closed) === 'true'
			};
		}

		function saveMenuState(state) {
			if (state.width !== undefined) {
				localStorage.setItem(menuConfig.storageKeys.width, state.width);
			}
			if (state.closed !== undefined) {
				localStorage.setItem(menuConfig.storageKeys.closed, state.closed);
			}
		}

		function setMenuWidth(width) {
			width = Math.max(menuConfig.minWidth, Math.min(menuConfig.maxWidth, width));
			$('.menuComputerCont').css('width', width + 'px');
			if (!isMobile()) {
				$('.paginaCont').css('margin-left', width + 'px');
			}
			return width;
		}

		function openMenu() {
			if (isMobile()) {
				// Mobile: usar comportamento de sidebar overlay
				$('body').addClass('menu-mobile-open');
			} else {
				// Desktop: comportamento padrão
				$('body').removeClass('menu-closed');
				var state = getMenuState();
				$('.paginaCont').css('margin-left', state.width + 'px');
				saveMenuState({ closed: false });
			}
		}

		function closeMenu() {
			if (isMobile()) {
				// Mobile: fechar sidebar overlay
				$('body').removeClass('menu-mobile-open');
			} else {
				// Desktop: comportamento padrão
				$('body').addClass('menu-closed');
				$('.paginaCont').css('margin-left', '0');
				saveMenuState({ closed: true });
			}
		}

		function toggleMenu() {
			if (isMobile()) {
				if ($('body').hasClass('menu-mobile-open')) {
					closeMenu();
				} else {
					openMenu();
				}
			} else {
				if ($('body').hasClass('menu-closed')) {
					openMenu();
				} else {
					closeMenu();
				}
			}
		}

		// ===== Inicialização do Menu (SEM animação)

		// Adicionar classe para desabilitar transições durante a inicialização
		$('body').addClass('menu-no-transition');

		var menuState = getMenuState();

		// Aplicar largura salva ao menu
		$('.menuComputerCont').css('width', menuState.width + 'px');

		// Aplicar estado aberto/fechado SEM animação
		if (isMobile()) {
			// Em mobile, sempre começa fechado (sidebar overlay)
			$('.paginaCont').css('margin-left', '0');
		} else {
			// Desktop: aplicar estado salvo
			if (menuState.closed) {
				$('body').addClass('menu-closed');
				$('.paginaCont').css('margin-left', '0');
			} else {
				$('.paginaCont').css('margin-left', menuState.width + 'px');
			}
		}

		// Remover classe após um pequeno delay para reabilitar transições
		requestAnimationFrame(function () {
			requestAnimationFrame(function () {
				$('body').removeClass('menu-no-transition');
			});
		});

		// ===== Event Listeners dos Botões

		// Botão Fechar Menu
		$('#menu-close-btn').on('click', function () {
			closeMenu();
		});

		// Botão Toggle (abrir menu quando fechado)
		$('#menu-toggle-btn').on('click', function () {
			openMenu();
		});

		// Overlay mobile (fechar menu ao clicar)
		$('.menu-mobile-overlay').on('click', function () {
			closeMenu();
		});

		// Botão Dashboard 3D
		$('#menu-dashboard3d-btn').on('click', function () {
			// Navegar para o dashboard 3D
			var dashboard3dUrl = (typeof gestor !== 'undefined' && gestor.raiz)
				? gestor.raiz + 'dashboard-3d/'
				: '/dashboard-3d/';

			// Adicionar parâmetro para ativar modo 3D
			window.location.href = dashboard3dUrl;
		});

		// ===== Listener de Resize da Janela
		var resizeTimeout;
		$(window).on('resize', function () {
			clearTimeout(resizeTimeout);
			resizeTimeout = setTimeout(function () {
				var state = getMenuState();

				if (isMobile()) {
					// Em mobile, fechar menu e garantir margin-left 0
					$('body').removeClass('menu-closed');
					$('.paginaCont').css('margin-left', '0');
				} else {
					// Em desktop, restaurar estado salvo
					$('body').removeClass('menu-mobile-open');
					if (state.closed) {
						$('body').addClass('menu-closed');
						$('.paginaCont').css('margin-left', '0');
					} else {
						$('.paginaCont').css('margin-left', state.width + 'px');
					}
				}
			}, 100);
		});

		// ===== Lógica de Redimensionamento do Menu (apenas desktop)
		var isResizing = false;
		var startX = 0;
		var startWidth = 0;

		$('#menu-resize-handle').on('mousedown', function (e) {
			e.preventDefault();
			isResizing = true;
			startX = e.clientX;
			startWidth = $('.menuComputerCont').width();
			$('body').addClass('menu-resizing');

			// Desabilitar transições durante o resize
			$('.menuComputerCont').css('transition', 'none');
			$('.paginaCont').css('transition', 'none');
		});

		$(document).on('mousemove', function (e) {
			if (!isResizing) return;

			var diff = e.clientX - startX;
			var newWidth = startWidth + diff;
			var finalWidth = setMenuWidth(newWidth);

			// Salvar largura em tempo real para feedback visual
			saveMenuState({ width: finalWidth });
		});

		$(document).on('mouseup', function () {
			if (isResizing) {
				isResizing = false;
				$('body').removeClass('menu-resizing');

				// Reabilitar transições
				$('.menuComputerCont').css('transition', '');
				$('.paginaCont').css('transition', '');

				// Salvar estado final
				var finalWidth = $('.menuComputerCont').width();
				saveMenuState({ width: finalWidth });
			}
		});

		// ===== Suporte a Touch para dispositivos móveis
		$('#menu-resize-handle').on('touchstart', function (e) {
			e.preventDefault();
			isResizing = true;
			startX = e.originalEvent.touches[0].clientX;
			startWidth = $('.menuComputerCont').width();
			$('body').addClass('menu-resizing');

			$('.menuComputerCont').css('transition', 'none');
			$('.paginaCont').css('transition', 'none');
		});

		$(document).on('touchmove', function (e) {
			if (!isResizing) return;

			var diff = e.originalEvent.touches[0].clientX - startX;
			var newWidth = startWidth + diff;
			var finalWidth = setMenuWidth(newWidth);
			saveMenuState({ width: finalWidth });
		});

		$(document).on('touchend', function () {
			if (isResizing) {
				isResizing = false;
				$('body').removeClass('menu-resizing');

				$('.menuComputerCont').css('transition', '');
				$('.paginaCont').css('transition', '');

				var finalWidth = $('.menuComputerCont').width();
				saveMenuState({ width: finalWidth });
			}
		});

		// ===== Atalho de Teclado (Ctrl/Cmd + B para toggle menu)
		$(document).on('keydown', function (e) {
			if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
				e.preventDefault();
				toggleMenu();
			}
		});

		// ===== Double-click no handle para resetar largura padrão
		$('#menu-resize-handle').on('dblclick', function () {
			setMenuWidth(menuConfig.defaultWidth);
			saveMenuState({ width: menuConfig.defaultWidth });
		});

		// ===== Manter a posição do scroll dos dois menus de maneira persistente entre páginas.

		$('.menuComputerCont').on('scroll', function (e) {
			sessionStorage.setItem(menuConfig.storageKeys.scroll, $(this).scrollTop());
		});

		if (sessionStorage.getItem(menuConfig.storageKeys.scroll)) {
			$('.menuComputerCont').scrollTop(sessionStorage.getItem(menuConfig.storageKeys.scroll));
		}

		$('#conn2flow-menu-principal').on('scroll', function (e) {
			sessionStorage.setItem(menuConfig.storageKeys.scrollMobile, $(this).scrollTop());
		});

		if (sessionStorage.getItem(menuConfig.storageKeys.scrollMobile)) {
			$('#conn2flow-menu-principal').scrollTop(sessionStorage.getItem(menuConfig.storageKeys.scrollMobile));
		}
	}

	if ('languages' in gestor) {
		// ===== Funções Auxiliares de Cookie

		function setCookie(cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toUTCString();
			var sameSite = "SameSite=Lax";
			var secure = (location.protocol === 'https:') ? "; Secure" : "";
			document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;" + sameSite + secure;
		}

		function getCookie(cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) === 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}

		function areCookiesEnabled() {
			// Tentar definir um cookie de teste
			setCookie('testCookie', 'test', 1);
			// Tentar lê-lo
			var testValue = getCookie('testCookie');
			// Remover o cookie de teste
			document.cookie = 'testCookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
			// Retornar se conseguiu ler
			return testValue === 'test';
		}

		// ===== Widget de Seleção de Linguagem (Via Iframe)

		if (gestor.languages.widgetActive && Array.isArray(gestor.pageLanguages) && gestor.pageLanguages.length > 1 && (gestor.moduloId != 'dashboard' && gestor.moduloOpcao != 'dashboard-site-toolbar')) {
			// Criar Iframe para isolar o ambiente (Fomantic UI / jQuery)
			var iframeSrc = gestor.raiz + 'global/language-widget.html';
			var iframeId = 'gestor-language-iframe';

			var iframe = document.createElement('iframe');
			iframe.id = iframeId;
			iframe.src = iframeSrc;
			iframe.style.position = 'fixed';
			iframe.style.bottom = '20px';
			iframe.style.right = '20px';
			iframe.style.width = '0px'; // Começa invisível até carregar
			iframe.style.height = '0px';
			iframe.style.border = 'none';
			iframe.style.zIndex = '99999';
			iframe.style.overflow = 'hidden';
			iframe.allowTransparency = "true"; // Para navegadores antigos

			document.body.appendChild(iframe);

			// Escutar mensagens do Iframe
			window.addEventListener('message', function (event) {
				// Verificar origem se necessário (aqui é mesmo domínio/subdomínio geralmente)

				var data = event.data;

				if (data.type === 'resize') {
					$('#' + iframeId).css({
						'width': data.width + 'px',
						'height': data.height + 'px'
					});
				}

				if (data.type === 'changeLang') {
					var lang = data.lang;
					if (lang != gestor.language) {
						// Redirecionar (Lógica Centralizada)
						var rootUrl = gestor.raizSemLang;
						var pathname = window.location.pathname;
						var relativePath = pathname;

						if (pathname.indexOf(rootUrl) === 0) {
							relativePath = pathname.substring(rootUrl.length);
						}

						// Verificar se o caminho relativo começa com a linguagem atual
						if (relativePath.startsWith(gestor.language + '/')) {
							relativePath = relativePath.substring(gestor.language.length + 1);
						}

						// Montar nova URL
						var newUrl = rootUrl + lang + '/' + relativePath + window.location.search + window.location.hash;

						window.location.href = newUrl;
					}
				}
			});

			// Inicializar o Iframe quando carregar
			iframe.onload = function () {
				iframe.contentWindow.postMessage({
					type: 'init',
					config: gestor.languages,
					currentLang: gestor.language
				}, '*');
			};
		}

		// ===== Detecção Automática

		if (gestor.languages.autoDetect) {
			var cookieName = gestor.languageCookie;
			var cookieDays = 30;
			var savedLang = '';
			let cookieEnabled = false;

			// Pegar o cookie se existe
			savedLang = getCookie(cookieName);

			// Fallback para localStorage caso cookies não estejam disponíveis.
			if (!savedLang) {
				try {
					if (!areCookiesEnabled()) {
						savedLang = localStorage.getItem(cookieName);
					} else { cookieEnabled = true; }
				} catch (e) { }
			} else { cookieEnabled = true; }

			// Detectar linguagem do navegador
			var browserLang = navigator.language || navigator.userLanguage;
			browserLang = browserLang.toLowerCase();
			var targetLang = browserLang;

			// Se ainda não tem preferência salva (primeira visita ou navegador não suportado), tentar detectar. Ou se a preferência salva é diferente do navegador (mudança de linguagem do navegador).
			if (!savedLang || savedLang != targetLang) {
				// Linguagem padrão do sistema no servidor
				var systemLang = gestor.languageSystem;

				// Verificar se a linguagem do navegador é suportada
				var isBrowserSupported = false;
				var supportedBrowserLang = '';

				// Verificação se a linguagem do navegador está na lista de linguagens suportadas
				if (gestor.languages.codigos) {
					for (var i = 0; i < gestor.languages.codigos.length; i++) {
						if (gestor.languages.codigos[i].codigo == targetLang) {
							isBrowserSupported = true;
							supportedBrowserLang = targetLang;
							break;
						}
					}

					// Tentar matching parcial se não encontrou exato (ex: pt-BR -> pt)
					if (!isBrowserSupported) {
						var shortLang = targetLang.split('-')[0];
						for (var i = 0; i < gestor.languages.codigos.length; i++) {
							if (gestor.languages.codigos[i].codigo == shortLang) {
								isBrowserSupported = true;
								supportedBrowserLang = shortLang;
								break;
							}
						}
					}
				}

				// Se a linguagem do navegador é suportada, avaliar redirecionamento
				if (isBrowserSupported) {
					var rootUrl = gestor.raiz;
					var pathname = window.location.pathname;
					var relativePath = pathname;

					if (pathname.indexOf(rootUrl) === 0) {
						relativePath = pathname.substring(rootUrl.length);
					}

					// Verificação de segurança: se a URL já começa com a linguagem suportada, não redirecionar (usuário escolheu manualmente URL em outra linguagem).
					if (relativePath.startsWith(supportedBrowserLang + '/')) {
						return;
					}

					// Salvar cookie para enviar na próxima requisição para o servidor a linguagem do navegador.
					if (cookieEnabled) {
						setCookie(cookieName, supportedBrowserLang, cookieDays);
					} else {
						try { localStorage.setItem(cookieName, supportedBrowserLang); } catch (e) { }
					}

					// Reler página se diferente da linguagem do navegador salva para trocar a linguagem automaticamente.
					if (supportedBrowserLang != systemLang) {
						// Reload na nova linguagem
						window.location.reload();
					}
				} else {
					if (savedLang != systemLang) {
						// Linguagem do navegador não suportada, salvar a linguagem padrão do sistema.
						if (cookieEnabled) {
							setCookie(cookieName, systemLang, cookieDays);
						} else {
							try { localStorage.setItem(cookieName, systemLang); } catch (e) { }
						}

						// Reler página se diferente da linguagem do navegador salva para trocar a linguagem automaticamente.
						window.location.reload();
					}
				}
			}
		}
	}

});
