$(document).ready(function () {
    /**
     * HTML Editor - Controles do Editor Visual (janela pai) — req-034 (BATCH-034)
     *
     * Este arquivo concentra a lógica da JANELA PAI do Editor HTML Visual, separada do
     * já extenso `html-editor-interface.js`:
     *   - Botão "+" com painel de inclusão de elementos HTML e widgets do sistema.
     *   - Carga AJAX da lista de widgets ativos (rota `html-editor-widgets-list`).
     *   - Botões e atalhos de teclado de Desfazer/Refazer (Ctrl+Z / Ctrl+Y / Ctrl+Shift+Z).
     *   - Alças de redimensionamento do preview (resize handles) + indicador de largura.
     *   - Sincronização das larguras pré-definidas (desktop/tablet/mobile).
     *
     * A comunicação com o editor que roda DENTRO do iframe (`html-editor.js`) é feita por
     * `postMessage` usando o namespace de ações `c2f-he:*` definido abaixo.
     */

    // Só ativa quando o componente do HTML Editor existe nesta página.
    if (typeof gestor === 'undefined' || !gestor.html_editor) return;

    function t(portuguese, english) {
        var language = String(gestor.language || '').toLowerCase();
        return language.indexOf('en') === 0 ? english : portuguese;
    }

    // ===== Protocolo de mensagens pai <-> iframe (compartilhado com html-editor.js)
    var ACT = {
        UNDO: 'c2f-he:undo',
        REDO: 'c2f-he:redo',
        COPY: 'c2f-he:copy',
        PASTE: 'c2f-he:paste',
        INSERT_ELEMENT: 'c2f-he:insert-element',
        INSERT_WIDGET: 'c2f-he:insert-widget',
        CANCEL_INSERT: 'c2f-he:cancel-insert',
        HISTORY: 'c2f-he:history',
        WIDGET_RENDER: 'c2f-he:widget-render',
        WIDGET_RENDERED: 'c2f-he:widget-rendered',
        // req-106 (BATCH-106): liga/desliga a Sidebar Lateral de CSS e a Barra de Navegação de
        // Elementos dentro do iframe do preview.
        VIEW_OPTION: 'c2f-he:view-option'
    };

    // ===== Opções de exibição (req-106)
    //
    // O estado real vive no motor (dentro do iframe) e é persistido em
    // `localStorage['c2f-he-view-options']`. Como o iframe usa `srcdoc`, ele herda esta origem — o
    // mesmo storage — então a janela pai lê a MESMA chave para marcar os toggles ao abrir o painel.
    var VIEW_OPTIONS_KEY = 'c2f-he-view-options';

    var VIEW_OPTIONS = [
        { key: 'cssSidebar', label: 'Estilização de Elementos', labelEn: 'Element Styling' },
        { key: 'elementNavbar', label: 'Navegação de Elementos', labelEn: 'Element Navigation' }
    ];

    function lerOpcoesExibicao() {
        var base = { cssSidebar: false, elementNavbar: false };
        try {
            var raw = window.localStorage.getItem(VIEW_OPTIONS_KEY);
            if (!raw) return base;
            var dados = JSON.parse(raw);
            if (!dados || typeof dados !== 'object') return base;
            Object.keys(base).forEach(function (k) { base[k] = !!dados[k]; });
            return base;
        } catch (e) { return base; }
    }

    // ===== Elementos HTML disponíveis no painel de inclusão (req-034 §4)
    var ELEMENTOS_HTML = [
        { type: 'p', label: 'Parágrafo', labelEn: 'Paragraph', icon: 'paragraph' },
        { type: 'h1', label: 'Título H1', labelEn: 'Heading H1', icon: 'heading' },
        { type: 'h2', label: 'Título H2', labelEn: 'Heading H2', icon: 'heading' },
        { type: 'h3', label: 'Título H3', labelEn: 'Heading H3', icon: 'heading' },
        { type: 'img', label: 'Imagem', labelEn: 'Image', icon: 'image' },
        { type: 'a', label: 'Link', labelEn: 'Link', icon: 'linkify' },
        { type: 'button', label: 'Botão', labelEn: 'Button', icon: 'hand pointer' },
        { type: 'div', label: 'Bloco', labelEn: 'Block', icon: 'square outline' },
        { type: 'section', label: 'Seção', labelEn: 'Section', icon: 'object group outline' },
        // req-097 item 6: mídia/documento embutido (o motor envolve e abre o modal de embed).
        { type: 'object', label: 'Objeto / PDF', labelEn: 'Object / PDF', icon: 'file pdf outline' },
        { type: 'iframe', label: 'Iframe', labelEn: 'Iframe', icon: 'window maximize outline' },
        { type: 'embed', label: 'Embed', labelEn: 'Embed', icon: 'code' },
        { type: 'video', label: 'Vídeo', labelEn: 'Video', icon: 'video' },
        { type: 'audio', label: 'Áudio', labelEn: 'Audio', icon: 'volume up' }
    ];

    // req-066: as categorias de widget do sistema são carregadas dinamicamente da tabela
    // `widgets` (rota `html-editor-widget-types`) e os itens de cada categoria sob demanda
    // (lazy load via `html-editor-widgets-list`), substituindo a antiga lista hardcoded.
    var categoriasCache = null;  // [{ id, name, icon }] — carregado uma vez por sessão
    var widgetsCache = {};       // itens por categoria: { <module>: [ { id, nome }, ... ] }

    // ===== Comunicação com o iframe

    function iframeWindow() {
        var el = document.getElementById('iframe-preview');
        return el ? el.contentWindow : null;
    }

    function enviarParaIframe(action, payload) {
        var w = iframeWindow();
        if (!w) return;
        var msg = $.extend({ action: action }, payload || {});
        w.postMessage(JSON.stringify(msg), '*');
    }

    function modalVisualAberto() {
        var $modal = $('.previsualizar.modal');
        return $modal.length > 0 && $modal.hasClass('visible') && $modal.is(':visible');
    }

    // ===== Estilos (alças de resize, indicador e painel de inclusão)

    (function injetarEstilos() {
        if (document.getElementById('html-editor-visual-controls-styles')) return;
        var css = ''
            + '.iframe-resize-handle{position:absolute;top:0;width:10px;height:100%;cursor:ew-resize;'
            + 'background:rgba(59,130,246,0.12);z-index:5;transition:background .15s;}'
            + '.iframe-resize-handle:hover,.iframe-resize-handle.dragging{background:rgba(59,130,246,0.55);}'
            + '.iframe-resize-handle-left{left:-10px;border-radius:4px 0 0 4px;}'
            + '.iframe-resize-handle-right{right:-10px;border-radius:0 4px 4px 0;}'
            + '.iframe-resize-indicator{position:absolute;top:6px;left:50%;transform:translateX(-50%);'
            + 'background:rgba(17,24,39,0.85);color:#fff;font-size:12px;padding:2px 8px;border-radius:10px;'
            + 'z-index:6;pointer-events:none;font-family:monospace;}'
            + '.html-editor-add-panel{position:fixed;z-index:10000;min-width:260px;max-width:320px;'
            + 'max-height:70vh;overflow-y:auto;background:#fff;border:1px solid #d4d4d5;border-radius:6px;'
            + 'box-shadow:0 2px 12px rgba(0,0,0,0.2);padding:0.75rem;display:none;}'
            + '.html-editor-add-panel .he-add-title{font-weight:bold;color:#767676;text-transform:uppercase;'
            + 'font-size:11px;letter-spacing:.5px;margin:0.25rem 0 0.4rem;}'
            + '.html-editor-add-panel .he-add-item{display:flex;align-items:center;gap:0.5rem;padding:0.4rem 0.5rem;'
            + 'border-radius:4px;cursor:pointer;color:#333;}'
            + '.html-editor-add-panel .he-add-item:hover{background:#f3f4f6;}'
            + '.html-editor-add-panel .he-add-widget-group{margin-bottom:0.25rem;}'
            + '.html-editor-add-panel .he-add-widget-head{display:flex;align-items:center;gap:0.5rem;padding:0.4rem 0.5rem;'
            + 'cursor:pointer;font-weight:600;border-radius:4px;}'
            + '.html-editor-add-panel .he-add-widget-head:hover{background:#f3f4f6;}'
            + '.html-editor-add-panel .he-add-widget-list{padding-left:1.5rem;display:none;}'
            + '.html-editor-add-panel .he-add-widget-group.open .he-add-widget-list{display:block;}'
            + '.html-editor-add-panel .he-add-empty{color:#999;font-size:12px;padding:0.25rem 0.5rem;}'
            // req-106: painel de opções de exibição (mesma moldura do painel de inclusão).
            + '.html-editor-view-options-panel{position:fixed;z-index:10000;min-width:280px;max-width:340px;'
            + 'background:#fff;border:1px solid #d4d4d5;border-radius:6px;box-shadow:0 2px 12px rgba(0,0,0,0.2);'
            + 'padding:0.75rem;display:none;}'
            + '.html-editor-view-options-panel .he-view-title{font-weight:bold;color:#767676;'
            + 'text-transform:uppercase;font-size:11px;letter-spacing:.5px;margin:0.25rem 0 0.4rem;}'
            + '.html-editor-view-options-panel .he-view-item{display:flex;align-items:center;gap:0.5rem;'
            + 'padding:0.4rem 0.5rem;border-radius:4px;cursor:pointer;color:#333;}'
            + '.html-editor-view-options-panel .he-view-item:hover{background:#f3f4f6;}';
        var style = document.createElement('style');
        style.id = 'html-editor-visual-controls-styles';
        style.textContent = css;
        document.head.appendChild(style);
    })();

    // ===== Painel de inclusão ("+")

    var $painel = null;

    function construirPainel() {
        if ($painel) return $painel;

        var html = '<div class="html-editor-add-panel">';
        html += '<div class="he-add-title">' + t('Elementos HTML', 'HTML Elements') + '</div>';
        ELEMENTOS_HTML.forEach(function (el) {
            html += '<div class="he-add-item he-add-element" data-element="' + el.type + '">'
                + '<i class="' + el.icon + ' icon"></i><span>' + t(el.label, el.labelEn) + '</span></div>';
        });
        html += '<div class="ui divider"></div>';
        html += '<div class="he-add-title">' + t('Widgets do Sistema', 'System Widgets') + '</div>';
        // Container das categorias (preenchido dinamicamente via AJAX ao abrir o painel).
        html += '<div class="he-add-widget-groups"><div class="he-add-empty">' + t('Carregando...', 'Loading...') + '</div></div>';
        html += '</div>';

        $painel = $(html);
        $('body').append($painel);
        return $painel;
    }

    function posicionarPainel($botao) {
        var rect = $botao[0].getBoundingClientRect();
        var $p = construirPainel();
        $p.css({ top: (rect.bottom + 6) + 'px', left: rect.left + 'px' });
        // Ajuste para não sair da viewport à direita.
        var pw = $p.outerWidth();
        if (rect.left + pw > window.innerWidth - 10) {
            $p.css({ left: Math.max(10, window.innerWidth - pw - 10) + 'px' });
        }
    }

    function abrirPainel($botao) {
        construirPainel();
        posicionarPainel($botao);
        $painel.show();
        carregarCategorias();
    }

    function fecharPainel() {
        if ($painel) $painel.hide();
    }

    // Toggle do painel no clique do botão "+".
    $(document.body).on('click', '.html-editor-add-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if ($painel && $painel.is(':visible')) {
            fecharPainel();
        } else {
            abrirPainel($(this));
        }
    });

    // Fechar painel ao clicar fora.
    $(document).on('mousedown', function (e) {
        if (!$painel || !$painel.is(':visible')) return;
        if ($(e.target).closest('.html-editor-add-panel, .html-editor-add-btn').length === 0) {
            fecharPainel();
        }
    });

    // ===== Painel de opções de exibição (req-106)

    var $painelExibicao = null;

    function construirPainelExibicao() {
        if ($painelExibicao) return $painelExibicao;
        var html = '<div class="html-editor-view-options-panel">';
        html += '<div class="he-view-title">' + t('Opções de Exibição', 'Display Options') + '</div>';
        VIEW_OPTIONS.forEach(function (o) {
            html += '<label class="he-view-item"><input type="checkbox" data-view-option="' + o.key + '">'
                + '<span>' + t(o.label, o.labelEn) + '</span></label>';
        });
        html += '</div>';
        $painelExibicao = $(html);
        $('body').append($painelExibicao);
        return $painelExibicao;
    }

    function sincronizarPainelExibicao() {
        if (!$painelExibicao) return;
        var estado = lerOpcoesExibicao();
        $painelExibicao.find('[data-view-option]').each(function () {
            this.checked = !!estado[$(this).data('view-option')];
        });
    }

    function abrirPainelExibicao($botao) {
        construirPainelExibicao();
        var rect = $botao[0].getBoundingClientRect();
        var largura = $painelExibicao.outerWidth() || 300;
        var left = Math.min(rect.left, Math.max(10, window.innerWidth - largura - 10));
        $painelExibicao.css({ top: (rect.bottom + 6) + 'px', left: left + 'px' });
        sincronizarPainelExibicao();
        $painelExibicao.show();
    }

    function fecharPainelExibicao() {
        if ($painelExibicao) $painelExibicao.hide();
    }

    $(document.body).on('click', '.c2f-tb-view-options', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if ($painelExibicao && $painelExibicao.is(':visible')) fecharPainelExibicao();
        else abrirPainelExibicao($(this));
    });

    $(document.body).on('change', '.html-editor-view-options-panel [data-view-option]', function () {
        enviarParaIframe(ACT.VIEW_OPTION, { key: String($(this).data('view-option')), on: !!this.checked });
    });

    $(document).on('mousedown', function (e) {
        if (!$painelExibicao || !$painelExibicao.is(':visible')) return;
        if ($(e.target).closest('.html-editor-view-options-panel, .c2f-tb-view-options').length === 0) {
            fecharPainelExibicao();
        }
    });

    // Expandir/recolher grupos de widget, carregando os itens sob demanda ao abrir (req-066 §5).
    $(document.body).on('click', '.he-add-widget-head', function () {
        var $group = $(this).closest('.he-add-widget-group');
        var abrindo = !$group.hasClass('open');
        $group.toggleClass('open');
        if (abrindo) {
            var module = String($group.data('module'));
            if (!widgetsCache[module]) {
                carregarItensCategoria(module, $group);
            }
        }
    });

    // Selecionar elemento HTML do painel -> iniciar inserção no iframe.
    $(document.body).on('click', '.he-add-element', function () {
        var tipo = $(this).data('element');
        fecharPainel();
        enviarParaIframe(ACT.INSERT_ELEMENT, { elementType: String(tipo) });
    });

    // Selecionar widget do painel -> iniciar inserção no iframe.
    $(document.body).on('click', '.he-add-widget-item', function () {
        var $i = $(this);
        fecharPainel();
        enviarParaIframe(ACT.INSERT_WIDGET, {
            widgetModule: String($i.data('module')),
            widgetSlug: String($i.data('slug')),
            widgetName: String($i.data('name') || $i.data('slug'))
        });
    });

    // ===== Carga dinâmica de categorias e itens de widget (req-066 §5)

    // Sanitiza o nome do ícone vindo do banco antes de injetá-lo como classe CSS.
    function sanitizarIcone(icon) {
        return String(icon || 'cube').replace(/[^a-zA-Z0-9 _-]/g, '') || 'cube';
    }

    // Renderiza os itens (registros) de uma categoria na sua sublista.
    function renderizarItens(module, lista, $list) {
        $list.empty();
        if (!lista || !lista.length) {
            $list.append('<div class="he-add-empty">' + t('Nenhum registro ativo', 'No active records') + '</div>');
            return;
        }
        lista.forEach(function (w) {
            var $item = $('<div class="he-add-item he-add-widget-item">'
                + '<i class="cube icon"></i><span></span></div>');
            $item.attr('data-module', module);
            $item.attr('data-slug', w.id);
            $item.attr('data-name', w.nome || w.id);
            $item.find('span').text(w.nome || w.id);
            $list.append($item);
        });
    }

    // Renderiza os grupos de categoria (colapsados) sob a seção "Widgets do Sistema".
    function renderizarCategorias(categorias) {
        if (!$painel) return;
        var $cont = $painel.find('.he-add-widget-groups');
        $cont.empty();
        if (!categorias || !categorias.length) {
            $cont.append('<div class="he-add-empty">' + t('Nenhuma categoria ativa', 'No active categories') + '</div>');
            return;
        }
        categorias.forEach(function (cat) {
            var module = String(cat.id);
            var $group = $('<div class="he-add-widget-group">'
                + '<div class="he-add-widget-head"><i class="dropdown icon"></i>'
                + '<i class="' + sanitizarIcone(cat.icon) + ' icon"></i><span></span></div>'
                + '<div class="he-add-widget-list"><div class="he-add-empty">' + t('Carregando...', 'Loading...') + '</div></div>'
                + '</div>');
            $group.attr('data-module', module);
            $group.find('.he-add-widget-head > span').text(cat.name || module);
            // Reusa itens já carregados nesta sessão (mantém o estado ao fechar/reabrir o painel).
            if (widgetsCache[module]) {
                renderizarItens(module, widgetsCache[module], $group.find('.he-add-widget-list'));
            }
            $cont.append($group);
        });
    }

    // Carrega (uma vez) a lista de categorias ativas e as renderiza.
    function carregarCategorias() {
        if (categoriasCache) {
            renderizarCategorias(categoriasCache);
            return;
        }
        $.ajax({
            type: 'POST',
            url: gestor.raiz + gestor.moduloCaminho + '/',
            dataType: 'json',
            data: {
                opcao: gestor.moduloOpcao,
                ajax: 'sim',
                ajaxOpcao: 'html-editor-widget-types'
            },
            success: function (resp) {
                categoriasCache = (resp && resp.status === 'Ok' && Array.isArray(resp.data)) ? resp.data : [];
                renderizarCategorias(categoriasCache);
            },
            error: function () {
                renderizarCategorias([]);
            }
        });
    }

    // Carrega os itens de uma categoria sob demanda (cacheado por módulo).
    function carregarItensCategoria(module, $group) {
        var $list = $group.find('.he-add-widget-list');
        $.ajax({
            type: 'POST',
            url: gestor.raiz + gestor.moduloCaminho + '/',
            dataType: 'json',
            data: {
                opcao: gestor.moduloOpcao,
                ajax: 'sim',
                ajaxOpcao: 'html-editor-widgets-list',
                params: { module: module }
            },
            success: function (resp) {
                var lista = (resp && resp.status === 'Ok' && Array.isArray(resp.data)) ? resp.data : [];
                widgetsCache[module] = lista;
                renderizarItens(module, lista, $list);
            },
            error: function () {
                renderizarItens(module, [], $list);
            }
        });
    }

    // ===== Desfazer / Refazer

    $(document.body).on('click', '.html-editor-undo-btn', function () {
        if ($(this).is('[disabled]')) return;
        enviarParaIframe(ACT.UNDO);
    });

    $(document.body).on('click', '.html-editor-redo-btn', function () {
        if ($(this).is('[disabled]')) return;
        enviarParaIframe(ACT.REDO);
    });

    function atualizarBotoesHistorico(canUndo, canRedo) {
        var $u = $('.html-editor-undo-btn');
        var $r = $('.html-editor-redo-btn');
        if (canUndo) { $u.removeAttr('disabled'); } else { $u.attr('disabled', 'disabled'); }
        if (canRedo) { $r.removeAttr('disabled'); } else { $r.attr('disabled', 'disabled'); }
    }

    // Atalhos de teclado (apenas com o modal visual aberto e foco na janela pai).
    $(document).on('keydown', function (e) {
        if (!modalVisualAberto()) return;
        var key = (e.key || '').toLowerCase();
        if ((e.ctrlKey || e.metaKey) && key === 'z' && !e.shiftKey) {
            e.preventDefault();
            enviarParaIframe(ACT.UNDO);
        } else if ((e.ctrlKey || e.metaKey) && (key === 'y' || (key === 'z' && e.shiftKey))) {
            e.preventDefault();
            enviarParaIframe(ACT.REDO);
        } else if ((e.ctrlKey || e.metaKey) && key === 'c' && !ehDigitando(e.target) && selecaoTextoColapsada()) {
            // Copiar o elemento selecionado no iframe (preserva a cópia nativa de texto).
            e.preventDefault();
            enviarParaIframe(ACT.COPY);
        } else if ((e.ctrlKey || e.metaKey) && key === 'v' && !ehDigitando(e.target)) {
            e.preventDefault();
            enviarParaIframe(ACT.PASTE);
        } else if (key === 'escape') {
            // ESC cancela um modo de inserção em andamento.
            enviarParaIframe(ACT.CANCEL_INSERT);
            fecharPainel();
        }
    });

    function ehDigitando(t) {
        if (!t) return false;
        var tag = (t.tagName || '').toLowerCase();
        return tag === 'input' || tag === 'textarea' || t.isContentEditable;
    }

    function selecaoTextoColapsada() {
        var sel = window.getSelection ? window.getSelection() : null;
        return !sel || sel.isCollapsed || String(sel).length === 0;
    }

    // ===== Redimensionamento do preview (alças + larguras pré-definidas)

    function $frame() { return $('.previsualizar .iframe-preview-frame'); }
    function $indicador() { return $('.previsualizar .iframe-resize-indicator'); }

    function mostrarIndicador(px) {
        var $ind = $indicador();
        if (!$ind.length) return;
        $ind.text(Math.round(px) + 'px').show();
    }

    function ocultarIndicadorDepois() {
        var $ind = $indicador();
        clearTimeout($ind.data('hideTimer'));
        var t = setTimeout(function () { $ind.fadeOut(150); }, 1200);
        $ind.data('hideTimer', t);
    }

    function aplicarLargura(valor) {
        var $f = $frame();
        if (!$f.length) return;
        $f.css('max-width', '100%');
        if (valor === '100%' || valor === '100') {
            $f.css('width', '100%');
        } else {
            $f.css('width', valor);
        }
        mostrarIndicador($f.width());
        ocultarIndicadorDepois();
    }

    // Larguras pré-definidas (desktop=100% / tablet=768px / mobile=375px) via data-width.
    $(document.body).on('click', '.previsualizar .screenPagina', function () {
        var w = $(this).data('width') || '100%';
        $(this).addClass('active blue').siblings('.screenPagina').removeClass('active blue');
        aplicarLargura(String(w));
    });

    // Arraste das alças laterais.
    (function bindResizeHandles() {
        var dragState = null;

        $(document.body).on('mousedown', '.previsualizar .iframe-resize-handle', function (e) {
            e.preventDefault();
            var $f = $frame();
            if (!$f.length) return;
            dragState = {
                side: $(this).hasClass('iframe-resize-handle-left') ? 'left' : 'right',
                startX: e.clientX,
                startWidth: $f.width()
            };
            $(this).addClass('dragging');
            // Bloquear interação com o iframe durante o arraste.
            $('#iframe-preview').css('pointer-events', 'none');
            $('body').css('user-select', 'none');
        });

        $(document).on('mousemove', function (e) {
            if (!dragState) return;
            var delta = e.clientX - dragState.startX;
            // Lado direito cresce com delta positivo; o esquerdo cresce com delta negativo.
            // O frame é centralizado, então cada pixel de arraste move as duas bordas: x2.
            var novo = dragState.side === 'right'
                ? dragState.startWidth + delta * 2
                : dragState.startWidth - delta * 2;
            novo = Math.max(280, Math.min(novo, $('.previsualizar .html-editor-preview-stage').width()));
            $frame().css({ width: novo + 'px', 'max-width': '100%' });
            mostrarIndicador(novo);
        });

        $(document).on('mouseup', function () {
            if (!dragState) return;
            dragState = null;
            $('.previsualizar .iframe-resize-handle').removeClass('dragging');
            $('#iframe-preview').css('pointer-events', '');
            $('body').css('user-select', '');
            ocultarIndicadorDepois();
        });
    })();

    // ===== Render de widget (req-039): o iframe pede o HTML do widget; o pai consulta o backend
    // e devolve o resultado para o iframe popular o wrapper virtual.
    function renderWidgetParaIframe(signature, wrapperId) {
        $.ajax({
            type: 'POST',
            url: gestor.raiz + gestor.moduloCaminho + '/',
            dataType: 'json',
            data: {
                opcao: gestor.moduloOpcao,
                ajax: 'sim',
                ajaxOpcao: 'html-editor-widget-render',
                params: { signature: signature }
            },
            success: function (resp) {
                var html = (resp && resp.status === 'Ok' && resp.data) ? (resp.data.html || '') : '';
                enviarParaIframe(ACT.WIDGET_RENDERED, { wrapperId: wrapperId, signature: signature, html: html });
            },
            error: function () {
                enviarParaIframe(ACT.WIDGET_RENDERED, { wrapperId: wrapperId, signature: signature, html: '' });
            }
        });
    }

    // ===== Mensagens recebidas do iframe

    window.addEventListener('message', function (e) {
        var data;
        try { data = JSON.parse(e.data); } catch (err) { return; }
        if (!data || !data.action) return;

        switch (data.action) {
            case ACT.HISTORY:
                atualizarBotoesHistorico(!!data.canUndo, !!data.canRedo);
                break;
            case ACT.WIDGET_RENDER:
                renderWidgetParaIframe(String(data.signature || ''), String(data.wrapperId || ''));
                break;
        }
    });
});
