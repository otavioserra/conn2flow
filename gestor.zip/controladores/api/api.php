<?php

// ===== Controlador da API do Conn2Flow

global $_GESTOR;

$_GESTOR['modulo-id']							=	'api';
$_GESTOR['modulo#'.$_GESTOR['modulo-id']]		=	Array(
	'versao' => '1.0.0',
);

// =========================== Headers CORS e Configurações

function api_cors_configurar() {
    global $_CONFIG;

    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    $permitidas = $_CONFIG['api']['cors-origins'] ?? [];
    if ($origin !== '' && in_array($origin, $permitidas, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }

    return $origin === '' || in_array($origin, $permitidas, true);
}

$corsPermitido = api_cors_configurar();
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=UTF-8');

// ===== Resposta para preflight OPTIONS
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code($corsPermitido ? 204 : 403);
    exit;
}

// =========================== Rate Limiting Básico

function api_bearer_token() {
    $authorization = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($authorization === '' && function_exists('getallheaders')) {
        foreach ((array)getallheaders() as $nome => $valor) {
            if (strcasecmp((string)$nome, 'Authorization') === 0) {
                $authorization = (string)$valor;
                break;
            }
        }
    }

    return preg_match('/^Bearer\s+([^\s]+)$/i', trim($authorization), $matches) ? $matches[1] : null;
}

function api_token_validar_memoizado($token) {
    global $_GESTOR;

    $chave = hash('sha256', (string)$token);
    if (array_key_exists($chave, $_GESTOR['api-auth-cache'] ?? [])) return $_GESTOR['api-auth-cache'][$chave];

    gestor_incluir_biblioteca('oauth2');
    $resultado = oauth2_validar_token(['token' => $token]);
    $_GESTOR['api-auth-cache'][$chave] = is_array($resultado) ? $resultado : false;

    return $_GESTOR['api-auth-cache'][$chave];
}

function api_rate_limit_subject() {
    $token = api_bearer_token();
    if ($token !== null) {
        $usuario = api_token_validar_memoizado($token);
        if (is_array($usuario) && isset($usuario['id_usuarios'])) return 'user:' . (int)$usuario['id_usuarios'];
    }

    return 'ip:' . (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
}

function api_rate_limit_check($endpoint = 'default') {
    global $_CONFIG;

    $maxRequests = (int)($_CONFIG['api']['rate-limit-max'] ?? 100);
    $window = (int)($_CONFIG['api']['rate-limit-window'] ?? 3600);
    $windowStart = intdiv(time(), $window) * $window;
    $route = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) . ':' . (string)$endpoint;
    $subject = api_rate_limit_subject();

    try {
        gestor_incluir_biblioteca('banco-v2');
        $db = banco_v2();
        $db->executar(
            'INSERT INTO api_rate_limits (route, subject, window_start, request_count, updated_at) '
            . 'VALUES (?, ?, ?, 1, NOW()) '
            . 'ON DUPLICATE KEY UPDATE request_count=request_count+1, updated_at=NOW()',
            [$route, $subject, $windowStart]
        );
        $rows = $db->sql(
            'SELECT request_count FROM api_rate_limits WHERE route=? AND subject=? AND window_start=? LIMIT 1',
            [$route, $subject, $windowStart]
        );

        return isset($rows[0]['request_count']) && (int)$rows[0]['request_count'] <= $maxRequests;
    } catch (Throwable $e) {
        error_log('Falha no rate limit persistente da API: ' . $e->getMessage());
        return false;
    }
}

// =========================== Autenticação

function api_authenticate($require_auth = false) {
    global $_GESTOR;

    if (!$require_auth) {
        return true; // Endpoint público
    }

    // Verificar token de autenticação
    $token = api_bearer_token();

    if (!$token) {
        api_response_error('Token de autenticação não fornecido', 401);
    }

    // Validação real do token OAuth 2.0
    $token_validacao = api_token_validar_memoizado($token);
    if(!$token_validacao || !is_array($token_validacao)){
        api_response_error('Token de autenticação inválido ou expirado', 401);
    }

    return $token_validacao;
}

// =========================== Funções de Resposta

function api_response_success($data = null, $message = 'OK', $code = 200) {
    http_response_code($code);

    $response = [
        'status' => 'success',
        'message' => $message,
        'timestamp' => date('c')
    ];

    if ($data !== null) {
        $response['data'] = $data;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function api_response_error($message = 'Erro interno do servidor', $code = 500, $details = null) {
    http_response_code($code);

    $response = [
        'status' => 'error',
        'message' => $message,
        'timestamp' => date('c')
    ];

    if ($details !== null) {
        $response['details'] = $details;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// =========================== Parse do Corpo da Requisição

function api_get_request_body() {
    $input = file_get_contents('php://input');
    if (empty($input)) {
        return [];
    }

    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        api_response_error('JSON inválido no corpo da requisição', 400);
    }

    return $data;
}

// =========================== Handlers de Endpoint PROJECT

function api_handle_project() {
    global $_GESTOR;

    // Verificar sub-endpoint
    $sub_endpoint = isset($_GESTOR['caminho'][2]) ? $_GESTOR['caminho'][2] : null;

    switch ($sub_endpoint) {
        case 'update':
            api_project_update();
            break;

        case 'recover':
            api_project_recover();
            break;

        default:
            api_response_error('Sub-endpoint PROJECT não encontrado: ' . $sub_endpoint, 404);
    }
}

function api_project_update() {
    global $_GESTOR;

    // Requer autenticação
    api_authenticate(true);

    // Obter project ID do header
    $project_id = $_SERVER['HTTP_X_PROJECT_ID'] ?? null;

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method !== 'POST') {
        api_response_error('Método não permitido. Use POST.', 405);
    }

    // Verificar se é multipart/form-data
    $content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (strpos($content_type, 'multipart/form-data') === false) {
        api_response_error('Content-Type deve ser multipart/form-data', 400);
    }

    // Verificar se arquivo foi enviado
    if (!isset($_FILES['project_zip']) || $_FILES['project_zip']['error'] !== UPLOAD_ERR_OK) {
        api_response_error('Arquivo project_zip não foi enviado ou houve erro no upload', 400);
    }

    $uploaded_file = $_FILES['project_zip'];
    $temp_path = $uploaded_file['tmp_name'];
    $original_name = $uploaded_file['name'];

    // Validar extensão do arquivo
    $file_extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    if ($file_extension !== 'zip') {
        api_response_error('Apenas arquivos ZIP são permitidos', 400);
    }

    // Verificar tamanho do arquivo (máximo 100MB)
    $max_size = 100 * 1024 * 1024; // 100MB
    if ($uploaded_file['size'] > $max_size) {
        api_response_error('Arquivo muito grande. Máximo permitido: 100MB', 400);
    }

    // Criar diretório temporário para processamento
    $temp_dir = $_GESTOR['logs-path'] . 'temp_projects/';
    if (!is_dir($temp_dir)) {
        mkdir($temp_dir, 0755, true);
    }

    // Diretório temporário único para este upload
    $extract_dir = $temp_dir . 'upload_' . time() . '_' . uniqid() . '/';
    mkdir($extract_dir, 0755, true);

    try {
        // Mover arquivo para local temporário seguro
        $zip_path = $extract_dir . 'project.zip';
        if (!move_uploaded_file($temp_path, $zip_path)) {
            throw new Exception('Falha ao salvar arquivo temporário');
        }

        // Descompactar ZIP
        $zip = new ZipArchive();
        if ($zip->open($zip_path) !== true) {
            throw new Exception('Falha ao abrir arquivo ZIP');
        }

        $zip->extractTo($extract_dir);
        $zip->close();

        // Usar a raiz do sistema como destino
        $project_path = $_GESTOR['ROOT_PATH'];

        // Encontrar o diretório do conteúdo do projeto (pode ser diretamente no extract_dir ou em um subdiretório)
        $project_content_dir = $extract_dir;
        
        // Verificar se há um único diretório dentro do extract_dir (caso comum de ZIP com diretório raiz)
        $extracted_items = array_diff(scandir($extract_dir), ['.', '..']);
        if (count($extracted_items) === 1 && is_dir($extract_dir . DIRECTORY_SEPARATOR . $extracted_items[0])) {
            $project_content_dir = $extract_dir . DIRECTORY_SEPARATOR . $extracted_items[0];
        }

        // Copiar arquivos do projeto (sobrescrever existentes na raiz)
        api_copy_directory($project_content_dir, $project_path);

        // Parâmetro opcional full_log: quando ativo, retorna o log completo de debug do banco.
        $full_log = isset($_POST['full_log']) && filter_var($_POST['full_log'], FILTER_VALIDATE_BOOLEAN);

        // Executar atualização de banco de dados do projeto (inline, sem shell_exec)
        $db_logs = api_executar_atualizacao_banco($project_path, $project_id, $full_log);

        // Sincronizar hooks do projeto após atualização do banco
        require_once $_GESTOR['controladores-path'] . 'atualizacoes/atualizacoes-hooks.php';
        atualizacoes_hooks_sincronizar();

        // Limpar arquivos temporários
        api_remove_directory($extract_dir);

        // Resposta de sucesso
        $response_data = [
            'file_size' => $uploaded_file['size'],
            'updated_at' => date('c'),
            'status' => 'updated',
            'db_logs' => $db_logs,
            'full_log' => $full_log,
        ];

        api_response_success($response_data, 'Projeto atualizado com sucesso');

    } catch (Exception $e) {
        // Limpar arquivos temporários em caso de erro
        if (isset($extract_dir) && is_dir($extract_dir)) {
            api_remove_directory($extract_dir);
        }

        api_response_error('Erro durante atualização do projeto: ' . $e->getMessage(), 500);
    }
}

/**
 * Endpoint de Recuperação (Pull System) — req-058 / BATCH-058.
 *
 * Extrai um dump bruto (raw) das tabelas selecionadas do banco do gestor em arquivos
 * <PascalCase>Data.json e os devolve como pacote ZIP para download. É a via inversa do
 * deploy: o cliente extrai o ZIP localmente e o descompilador
 * (controladores/agents/arquitetura/recuperacao-dados-recursos.php) reconstrói os arquivos
 * físicos (HTML/CSS/MD) e metadados do repositório.
 *
 * Requisitos: POST autenticado por OAuth (api_authenticate(true)). O corpo pode informar as
 * tabelas via JSON {"tables":[...]} ou POST `tables` (lista separada por vírgulas); quando
 * omitido, exporta todas as tabelas registradas em db/data/schema-metadata.json.
 */
function api_project_recover() {
    global $_GESTOR;

    // Requer autenticação OAuth válida.
    api_authenticate(true);

    // ID do projeto (contexto futuro) via header X-Project-ID.
    $project_id = $_SERVER['HTTP_X_PROJECT_ID'] ?? null;

    $method = $_SERVER['REQUEST_METHOD'];
    if ($method !== 'POST') {
        api_response_error('Método não permitido. Use POST.', 405);
    }

    // Resolver a lista de tabelas a exportar: corpo JSON {"tables":[...]} ou POST `tables` (CSV).
    $tabelas = [];
    $body = json_decode(file_get_contents('php://input'), true);
    if (is_array($body) && isset($body['tables']) && is_array($body['tables'])) {
        $tabelas = $body['tables'];
    } elseif (isset($_POST['tables']) && is_string($_POST['tables']) && $_POST['tables'] !== '') {
        $tabelas = explode(',', $_POST['tables']);
    }
    $recover_contents = false;
    if (is_array($body) && array_key_exists('recover_contents', $body)) {
        $recover_contents = filter_var($body['recover_contents'], FILTER_VALIDATE_BOOLEAN);
    } elseif (isset($_POST['recover_contents'])) {
        $recover_contents = filter_var($_POST['recover_contents'], FILTER_VALIDATE_BOOLEAN);
    }
    $tabelas = array_values(array_filter(array_map(function ($t) {
        return preg_replace('/[^a-z0-9_]/', '', strtolower(trim((string)$t)));
    }, $tabelas)));

    // Incluir o script de atualizações de banco apenas para reusar suas funções
    // (reverseExport/db/schemaMetadata) sem disparar o fluxo de deploy.
    if (!defined('SDD_NO_AUTORUN')) {
        define('SDD_NO_AUTORUN', true);
    }
    $script = $_GESTOR['ROOT_PATH'] . 'controladores/atualizacoes/atualizacoes-banco-de-dados.php';
    if (!file_exists($script)) {
        api_response_error('Script de atualização de banco não encontrado.', 500);
    }
    require_once $script;

    // Sem tabelas informadas: todas as registradas no contrato de sincronização.
    if (empty($tabelas)) {
        $meta = schemaMetadata();
        $tabelas = array_values(array_unique(array_merge(
            array_keys($meta['tables'] ?? []),
            api_project_schema_metadata_tables($_GESTOR['ROOT_PATH'] . 'project-schema-metadata.json')
        )));
    }
    if (empty($tabelas)) {
        api_response_error('Nenhuma tabela disponível para recuperação.', 400);
    }

    // Diretório temporário único para o dump bruto.
    $temp_base = $_GESTOR['logs-path'] . 'temp_recover_' . time() . '_' . uniqid() . '/';
    if (!is_dir($temp_base)) {
        mkdir($temp_base, 0755, true);
    }
    $zip_path = rtrim($_GESTOR['logs-path'], '/\\') . DIRECTORY_SEPARATOR
        . 'project-recover_' . time() . '_' . uniqid() . '.zip';

    try {
        // Conexão PDO com o banco do gestor (credenciais de $_BANCO via helper db()).
        $pdo = db();

        // Dump bruto das tabelas selecionadas em <PascalCase>Data.json no diretório temporário.
        reverseExport($pdo, $tabelas, $temp_base);

        // Compactar todos os *Data.json gerados.
        if (!class_exists('ZipArchive')) {
            throw new Exception('Extensão ZipArchive indisponível no servidor');
        }
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new Exception('Falha ao criar arquivo ZIP de recuperação');
        }
        $jsonFiles = glob($temp_base . '*Data.json') ?: [];
        foreach ($jsonFiles as $jf) {
            $zip->addFile($jf, basename($jf));
        }
        if ($recover_contents) {
            api_zip_add_directory($zip, $_GESTOR['ROOT_PATH'] . 'contents', 'contents');
        }
        $zip->close();

        if (!is_file($zip_path)) {
            throw new Exception('Pacote ZIP de recuperação não foi gerado');
        }

        // Stream do ZIP como download. Limpa buffers e sobrescreve o Content-Type JSON do topo.
        while (ob_get_level() > 0) { ob_end_clean(); }
        http_response_code(200);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="project-recover.zip"');
        header('Content-Length: ' . filesize($zip_path));
        readfile($zip_path);

        // Limpeza imediata em disco.
        @unlink($zip_path);
        api_remove_directory($temp_base);
        exit;

    } catch (Throwable $e) {
        if (is_file($zip_path)) { @unlink($zip_path); }
        if (is_dir($temp_base)) { api_remove_directory($temp_base); }
        api_response_error('Erro durante a recuperação do projeto: ' . $e->getMessage(), 500);
    }
}

/**
 * Lê o manifesto transitório de projeto gerado pelo compilador local e retorna tabelas válidas.
 */
function api_project_schema_metadata_tables(string $manifestPath): array {
    if (!is_file($manifestPath)) return [];
    $raw = file_get_contents($manifestPath);
    $data = json_decode((string)$raw, true);
    if (!is_array($data) || !isset($data['tabelas']) || !is_array($data['tabelas'])) return [];
    return array_values(array_filter(array_map(function ($t) {
        return preg_replace('/[^a-z0-9_]/', '', strtolower(trim((string)$t)));
    }, array_keys($data['tabelas']))));
}

/**
 * Adiciona recursivamente uma pasta ao ZIP preservando timestamps dos arquivos.
 */
function api_zip_add_directory(ZipArchive $zip, string $sourceDir, string $zipBase): void {
    if (!is_dir($sourceDir)) return;
    $sourceDir = rtrim($sourceDir, '/\\');
    $zipBase = trim(str_replace('\\', '/', $zipBase), '/');
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($sourceDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $item) {
        $path = $item->getPathname();
        $rel = ltrim(str_replace('\\', '/', substr($path, strlen($sourceDir))), '/');
        if ($rel === '') continue;
        $zipName = $zipBase . '/' . $rel;
        if ($item->isDir()) {
            $zip->addEmptyDir($zipName);
            continue;
        }
        if ($item->isFile()) {
            $zip->addFile($path, $zipName);
            if (method_exists($zip, 'setMtimeName')) {
                $zip->setMtimeName($zipName, $item->getMTime());
            }
        }
    }
}

// =========================== Handlers de Endpoint SYSTEM

function api_handle_system() {
    global $_GESTOR;

    $sub_endpoint = isset($_GESTOR['caminho'][2]) ? $_GESTOR['caminho'][2] : null;

    switch ($sub_endpoint) {
        case 'update':
            api_system_update();
            break;

        default:
            api_response_error('Sub-endpoint SYSTEM não encontrado: ' . $sub_endpoint, 404);
    }
}

function api_system_update() {
    global $_GESTOR;

    // Requer autenticação
    api_authenticate(true);

    $method = $_SERVER['REQUEST_METHOD'];
    if ($method !== 'POST') {
        api_response_error('Método não permitido. Use POST.', 405);
    }

    // Obter ação do POST ou da query string
    $action = $_POST['action'] ?? $_REQUEST['action'] ?? null;
    if (!$action) {
        api_response_error('Parâmetro "action" é obrigatório. Ações válidas: start, deploy, db, finalize, status, cancel', 400);
    }

    $valid_actions = ['start', 'deploy', 'db', 'finalize', 'status', 'cancel'];
    if (!in_array($action, $valid_actions)) {
        api_response_error('Ação inválida: ' . $action . '. Válidas: ' . implode(', ', $valid_actions), 400);
    }

    // Construir parâmetros para o sistema de atualização
    $params = ['action' => $action];

    // Para ação start, repassar configurações adicionais
    if ($action === 'start') {
        $param_keys = [
            'domain', 'tag', 'only_files', 'only_db', 'dry_run', 'local',
            'debug', 'no_db', 'force_all', 'log_diff', 'backup', 'no_verify',
            'download_only', 'skip_download', 'tables', 'clean_temp', 'logs_retention_days'
        ];
        foreach ($param_keys as $key) {
            $val = $_POST[$key] ?? $_REQUEST[$key] ?? null;
            if ($val !== null) {
                $params[$key] = $val;
            }
        }
        // Domínio padrão
        if (empty($params['domain'])) {
            $params['domain'] = $_SERVER['SERVER_NAME'] ?? 'localhost';
        }
    }

    // Para ações que operam em sessão, exigir sid
    if (in_array($action, ['deploy', 'db', 'finalize', 'status', 'cancel'])) {
        $sid = $_POST['sid'] ?? $_REQUEST['sid'] ?? null;
        if (!$sid) {
            api_response_error('Parâmetro "sid" (session ID) é obrigatório para a ação: ' . $action, 400);
        }
        $params['sid'] = $sid;
    }

    // Executar atualização via include do script (mesma abordagem de admin-atualizacoes)
    $result = api_call_system_update($params);

    if (isset($result['error'])) {
        $http_code = 500;
        // Erros de sessão são 400 (bad request)
        if (strpos($result['error'], 'Sessão') !== false || strpos($result['error'], 'inválida') !== false) {
            $http_code = 400;
        }
        api_response_error($result['error'], $http_code, $result);
    }

    api_response_success($result, 'Ação "' . $action . '" executada com sucesso');
}

/**
 * Chama o script atualizacoes-sistema.php simulando uma requisição web.
 * Mesma técnica utilizada por admin_atualizacoes_call_system().
 */
function api_call_system_update(array $params): array {
    global $_GESTOR;

    $script = $_GESTOR['ROOT_PATH'] . 'controladores/atualizacoes/atualizacoes-sistema.php';

    if (!is_file($script)) {
        return ['error' => 'Script de atualização não encontrado: ' . $script];
    }

    // Construir query string a partir dos parâmetros
    $query = http_build_query($params);

    // Salvar estado atual de $_GET e $_REQUEST
    $saved_get = $_GET;
    $saved_request = $_REQUEST;

    // Simular requisição web (mesma abordagem de admin-atualizacoes)
    $_GET = $_REQUEST = [];
    parse_str($query, $_GET);
    $_REQUEST = $_GET;

    // Incluir script e capturar saída JSON
    ob_start();
    try {
        include $script;
    } catch (Throwable $e) {
        ob_end_clean();
        $_GET = $saved_get;
        $_REQUEST = $saved_request;
        return ['error' => 'Exceção durante atualização: ' . $e->getMessage()];
    }
    $raw = ob_get_clean();

    // Restaurar estado
    $_GET = $saved_get;
    $_REQUEST = $saved_request;

    // Decodificar resposta JSON
    $json = json_decode($raw, true);
    if ($json === null) {
        return ['error' => 'Resposta inválida do sistema de atualização', 'raw' => substr($raw, 0, 2000)];
    }

    return $json;
}

// =========================== Funções Auxiliares para Manipulação de Arquivos

function api_executar_atualizacao_banco($project_path, $project_id = null, $full_log = false) {
    global $_GESTOR, $_BANCO;

    // Caminho para o script de atualização de banco
    $script = $_GESTOR['ROOT_PATH'] . 'controladores/atualizacoes/atualizacoes-banco-de-dados.php';

    if (!file_exists($script)) {
        throw new Exception('Script de atualização de banco não encontrado: ' . $script);
    }

    // Configurar opções CLI para execução inline
    $cli = [
        'env-dir' => $_SERVER['SERVER_NAME'] ?? 'localhost', // domínio padrão
        'db' => [
            'host' => $_BANCO['host'],
            'name' => $_BANCO['nome'],
            'user' => $_BANCO['usuario'],
            'pass' => $_BANCO['senha'] ?? '',
        ],
        'debug' => (bool)$full_log,
        'force-all' => false,
        'tables' => null,
        'log-diff' => (bool)$full_log,
        'dry-run' => false,
        'project' => $project_id ?? null,
    ];

    // Definir opções globais para o script
    $GLOBALS['CLI_OPTS'] = $cli;

    // Capturar os logs do banco por referência durante a execução inline (sem processo externo).
    $dbLogs = [];
    $loggerAnterior = $GLOBALS['EXTERNAL_LOGGER'] ?? null;
    $GLOBALS['EXTERNAL_LOGGER'] = &$dbLogs;
    $erro = null;
    try {
        require $script;
    } catch (Throwable $e) {
        $erro = $e;
    }
    // Restaura o logger externo anterior (preserva o array capturado em $dbLogs).
    unset($GLOBALS['EXTERNAL_LOGGER']);
    if ($loggerAnterior !== null) $GLOBALS['EXTERNAL_LOGGER'] = $loggerAnterior;

    if ($erro !== null) {
        throw new Exception('Falha na atualização de banco de dados: ' . $erro->getMessage());
    }

    return api_filtrar_db_logs($dbLogs, (bool)$full_log);
}

/**
 * Filtra os logs do banco para a resposta da API.
 * full_log=true  => log completo de debug.
 * full_log=false => versão resumida (relatório final + linhas de warning/erro/rollback).
 */
function api_filtrar_db_logs(array $dbLogs, bool $full_log): array {
    if ($full_log) return array_values($dbLogs);
    $resumo = [];
    foreach ($dbLogs as $line) {
        $s = (string)$line;
        $u = strtoupper($s);
        if (strpos($u, 'WARN') !== false || strpos($u, 'ERRO') !== false || strpos($u, 'ERROR') !== false
            || strpos($u, 'ROLLBACK') !== false || strpos($u, 'TOTAL') !== false
            || strpos($s, '📦') !== false || strpos($s, '📝') !== false || strpos($s, 'Σ') !== false) {
            $resumo[] = $line;
        }
    }
    return array_values($resumo);
}

function api_copy_directory($source, $destination) {
    if (!is_dir($source)) {
        return false;
    }

    if (!is_dir($destination)) {
        mkdir($destination, 0755, true);
    }

    $dir = opendir($source);
    while (($file = readdir($dir)) !== false) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $sourcePath = $source . DIRECTORY_SEPARATOR . $file;
        $destinationPath = $destination . DIRECTORY_SEPARATOR . $file;

        if (is_dir($sourcePath)) {
            api_copy_directory($sourcePath, $destinationPath);
        } else {
            copy($sourcePath, $destinationPath);
        }
    }
    closedir($dir);
    return true;
}

function api_remove_directory($dir) {
    if (!is_dir($dir)) {
        return false;
    }

    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = $dir . DIRECTORY_SEPARATOR . $file;
        if (is_dir($path)) {
            api_remove_directory($path);
        } else {
            unlink($path);
        }
    }
    return rmdir($dir);
}

// =========================== Handler OAuth Refresh

function api_oauth_refresh() {
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method !== 'POST') {
        api_response_error('Método não permitido. Use POST.', 405);
    }

    $data = api_get_request_body();

    // Validar refresh_token
    if (!isset($data['refresh_token']) || empty($data['refresh_token'])) {
        api_response_error('Campo "refresh_token" é obrigatório', 400);
    }

    // Incluir biblioteca OAuth2
    gestor_incluir_biblioteca('oauth2');

    // Tentar renovar tokens
    $novos_tokens = oauth2_renovar_token(Array(
        'refresh_token' => $data['refresh_token']
    ));

    if (!$novos_tokens) {
        api_response_error('Refresh token inválido ou expirado', 401);
    }

    // Retornar novos tokens
    api_response_success([
        'access_token' => $novos_tokens['access_token'],
        'token_type' => $novos_tokens['token_type'],
        'expires_in' => $novos_tokens['expires_in'],
        'refresh_token' => $novos_tokens['refresh_token'],
        'scope' => $novos_tokens['scope']
    ], 'Tokens renovados com sucesso');
}

// =========================== Hook de Módulos para a API

/**
 * Carrega o arquivo de hook de um módulo para o contexto da API.
 *
 * Lê o JSON do módulo, encontra o arquivo configurado em hooks.api,
 * inclui o arquivo e retorna o nome da função de callback esperada.
 *
 * Convenção de nome de função: {modulo_id_underscores}_api
 * Ex: módulo "host-manager" → função "host_manager_api"
 *
 * @param string      $modulo_id ID do módulo (ex: 'host-manager').
 * @param string|null $plugin_id ID do plugin, ou null para módulo padrão.
 *
 * @return string|null Nome da função do hook ou null se não encontrado.
 */
function api_carregar_hook($modulo_id, $plugin_id = null) {
    global $_GESTOR;

    // Resolver diretório do módulo
    if (!empty($plugin_id)) {
        $modulo_dir = $_GESTOR['plugins-path'] . $plugin_id . '/modules/' . $modulo_id . '/';
    } else {
        $modulo_dir = $_GESTOR['modulos-path'] . $modulo_id . '/';
    }

    if (!is_dir($modulo_dir)) {
        return null;
    }

    $json_path = $modulo_dir . $modulo_id . '.json';

    if (!file_exists($json_path)) {
        return null;
    }

    $modulo_config = json_decode(file_get_contents($json_path), true);

    if (!$modulo_config || json_last_error() !== JSON_ERROR_NONE) {
        return null;
    }

    $hook_file = $modulo_config['hooks']['api'] ?? null;

    if (empty($hook_file)) {
        return null;
    }

    $hook_path = $modulo_dir . $hook_file;

    if (!file_exists($hook_path)) {
        return null;
    }

    include_once($hook_path);

    // Convenção: {modulo_id_com_underscores}_api
    $funcao_id = str_replace('-', '_', $modulo_id);
    $funcao    = $funcao_id . '_api';

    // Fallback: module IDs starting with digit generate invalid PHP function names
    // Try with underscore prefix: 3d_catalog_api → _3d_catalog_api
    if (!function_exists($funcao) && preg_match('/^\d/', $funcao_id)) {
        $funcao_alt = '_' . $funcao;
        if (function_exists($funcao_alt)) {
            $funcao = $funcao_alt;
        }
    }

    return function_exists($funcao) ? $funcao : null;
}

/**
 * Dispara o hook 'api' para módulos registrados.
 *
 * Segue o mesmo padrão de plataforma_gateways_disparar_hook():
 * - Busca módulos com hooks IS NOT NULL no banco
 * - Quando $modulo_id_alvo é especificado, despacha apenas para ele
 * - Caso contrário, dispara broadcast para todos os módulos com hook 'api'
 *
 * A função de hook do módulo recebe:
 *   ['modulo_id' => string, 'action' => string, 'data' => array, 'method' => string]
 *
 * @param string      $action         Ação/sub-endpoint (ex: 'list-accounts', 'create-account').
 * @param array       $data           Dados da requisição (body + query params).
 * @param string|null $modulo_id_alvo ID do módulo alvo (null = broadcast).
 *
 * @return array|null Resultado do processamento ou null.
 */
function api_disparar_hook($action, $data = [], $modulo_id_alvo = null) {
    global $_GESTOR;

    $resultado = null;

    if (!empty($modulo_id_alvo)) {
        $modulos = banco_select([
            'tabela' => 'modulos',
            'campos' => ['id', 'plugin'],
            'extra'  => "WHERE id = '" . banco_escape_field($modulo_id_alvo) . "' AND hooks IS NOT NULL AND status != 'D'",
        ]);
    } else {
        $modulos = banco_select([
            'tabela' => 'modulos',
            'campos' => ['id', 'plugin'],
            'extra'  => "WHERE hooks IS NOT NULL AND status != 'D'",
        ]);
    }

    if (!$modulos) {
        return null;
    }

    foreach ($modulos as $modulo) {
        $modulo_id = $modulo['id'];

        $funcao = api_carregar_hook($modulo_id, $modulo['plugin'] ?? null);

        if (!$funcao) {
            continue;
        }

        try {
            $resultado_modulo = $funcao([
                'modulo_id' => $modulo_id,
                'action'    => $action,
                'data'      => $data,
                'method'    => $_SERVER['REQUEST_METHOD'] ?? 'GET',
            ]);

            if ($resultado_modulo !== null) {
                $resultado = $resultado_modulo;
            }

            // Se o módulo marcou como processado, parar loop
            if (isset($resultado_modulo['processed']) && $resultado_modulo['processed']) {
                break;
            }
        } catch (Exception $e) {
            error_log('API Hook Error [' . $modulo_id . ']: ' . $e->getMessage());
        }
    }

    return $resultado;
}

/**
 * Trata requisições direcionadas a módulos via /_api/{modulo-id}/{action}.
 *
 * @param string $modulo_id ID do módulo da URL.
 * @param string $action    Ação/sub-endpoint da URL.
 *
 * @return void
 */
function api_handle_modulo($modulo_id, $action) {
    // Sanitizar modulo_id
    $modulo_id = preg_replace('/[^a-z0-9\-_]/', '', strtolower($modulo_id));

    if (empty($modulo_id)) {
        api_response_error('Módulo inválido', 400);
    }

    // Requer autenticação
    api_authenticate(true);

    $data = array_merge(
        $_GET ?? [],
        api_get_request_body()
    );

    $resultado = api_disparar_hook($action ?? '', $data, $modulo_id);

    if ($resultado === null) {
        api_response_error('Módulo não encontrado ou sem suporte ao hook API: ' . $modulo_id, 404);
    }

    if (isset($resultado['erro']) && $resultado['erro']) {
        $code = $resultado['code'] ?? 500;
        api_response_error($resultado['mensagem'] ?? 'Erro no módulo', $code, $resultado['detalhes'] ?? null);
    }

    api_response_success(
        $resultado['dados'] ?? $resultado,
        $resultado['mensagem'] ?? 'OK',
        $resultado['code'] ?? 200
    );
}

// =========================== Canal de Módulos Distribuídos (req-005)

/**
 * Despacha as requisições do canal de módulos distribuídos.
 *
 * Rota: api[/v1]/modulo-distribuido/{slug}/{acao}. A ação determina o lado:
 *  - 'db' / 'ping'          => lado DISTRIBUÍDO (executa a operação no banco local).
 *  - 'signin' / 'refresh'   => lado CENTRAL (autenticação/ativação, devolve tokens).
 *
 * A autenticação do canal é feita por assinatura HMAC (verificada em cada handler),
 * dispensando o OAuth para as operações máquina-a-máquina entre central e distribuído.
 *
 * @return void
 */
function api_handle_modulo_distribuido() {
    global $_GESTOR;

    gestor_incluir_biblioteca('modulo-distribuido');

    $rota = modulo_distribuido_parse_rota($_GESTOR['caminho']);
    if ($rota === null) {
        api_response_error('Rota de módulo distribuído inválida. Use modulo-distribuido/{slug}/{acao}.', 400);
    }

    $acao = $rota['acao'];

    // Ações de autenticação/ativação e o middleware de permissão são atendidos pelo central.
    if (in_array($acao, ['signin', 'refresh', 'ativar', 'permissao'], true)) {
        require_once $_GESTOR['ROOT_PATH'] . 'controladores/api/api-module-central.php';
        api_module_central_handle($rota);
        return;
    }

    // Demais ações (db, ping) são atendidas pelo lado distribuído (executa no banco local).
    require_once $_GESTOR['ROOT_PATH'] . 'controladores/api/api-module-distributed.php';
    api_module_distributed_handle($rota);
}

// =========================== Roteamento da API

function api_route_request() {
    global $_GESTOR;

    // Verificar se há caminho suficiente
    if (!isset($_GESTOR['caminho'][1])) {
        api_response_error('Endpoint não especificado', 400);
    }

    $endpoint = $_GESTOR['caminho'][1];
    $method = $_SERVER['REQUEST_METHOD'];

    // Rate limiting
    if (!api_rate_limit_check($endpoint)) {
        api_response_error('Rate limit excedido. Tente novamente mais tarde.', 429);
    }

    // Roteamento baseado no endpoint
    switch ($endpoint) {
        case 'auth':
            // Autenticação mobile (BATCH-008 conn2flow-app): login, logout, me, modules.
            require_once $_GESTOR['ROOT_PATH'] . 'controladores/api/api-auth.php';
            api_auth_handle(isset($_GESTOR['caminho'][2]) ? $_GESTOR['caminho'][2] : null);
            break;

        case 'oauth':
            // Verificar sub-endpoint OAuth
            $sub_endpoint = isset($_GESTOR['caminho'][2]) ? $_GESTOR['caminho'][2] : null;

            switch ($sub_endpoint) {
                case 'refresh':
                    api_oauth_refresh();
                    break;
                default:
                    // Redirecionar para o endpoint OAuth existente
                    header('Location: ' . $_GESTOR['url-raiz'] . 'oauth-authenticate/');
                    exit;
            }
            break;

        case 'status':
            api_response_success(['status' => 'API operacional', 'version' => '1.0.0']);
            break;

        case 'health':
            api_response_success(['status' => 'healthy', 'timestamp' => time()]);
            break;

        case 'project':
            api_handle_project();
            break;

        case 'system':
            api_handle_system();
            break;

        case 'v1':
        case 'modulo-distribuido':
            // Canal de módulos distribuídos (req-005): api[/v1]/modulo-distribuido/{slug}/{acao}.
            api_handle_modulo_distribuido();
            break;

        default:
            // Tentar despachar para módulo via hook 'api'
            // Rota: /_api/{modulo-id}[/{action}[/{sub-action}...]]
            $action = isset($_GESTOR['caminho'][2]) ? implode('/', array_slice($_GESTOR['caminho'], 2)) : '';
            api_handle_modulo($endpoint, $action);
    }
}

// =========================== Inicialização da API

if(!defined('SDD_NO_AUTORUN')){
    try {
        api_route_request();
    } catch (Exception $e) {
        error_log('API Error: ' . $e->getMessage());
        api_response_error('Erro interno do servidor', 500);
    }
}

?>
