<?php

global $_GESTOR;

$_GESTOR['biblioteca-html-editor']							=	Array(
	'versao' => '1.5.9',
);

// ===== Funções auxiliares

/**
 * Publisher controles.
 *
 * Controles específicos do Publisher para o Editor HTML. Lida com a interface de variáveis.
 *
 * @param array $params Parâmetros da função.
 * @param array $params['publisher'] variáveis do publisher.
 */
function html_editor_publisher_controls($params = false){
	global $_GESTOR;

	if($params)foreach($params as $var => $val)$$var = $val;

	// ===== HTML Editor Publisher Controles
    $html_editor_publisher_controls = gestor_componente(Array(
		'id' => 'html-editor-publisher-controls',
	));

	$alvo_atual = isset($alvo) ? $alvo : 'publisher';
	$tem_vinculo = isset($publisher) && is_array($publisher);

	// req-011 item 3: para o alvo publisher-highlights, sempre considerar com vínculo,
	// mesmo na tela de "Adicionar" onde `$target_variables` chega vazio (não há mapeamento
	// salvo no banco ainda). O JS preenche dinamicamente as variáveis ao selecionar o modelo
	// via `publisher_highlights_update_target_variables`. Sem essa flag, o container HTML
	// era removido pelo bloco `publisher-has-link` impedindo o mapeamento.
	// req-017 item 1: o alvo `menus` segue a mesma família de variáveis [[item#X]] e também
	// precisa exibir a aba de variáveis (com a lista fixa de variáveis do template de menu).
	// req-018: o alvo `galleries` segue a mesma família [[item#X]] (variáveis fixas de imagem).
	if($alvo_atual === 'publisher-highlights' || $alvo_atual === 'menus' || $alvo_atual === 'galleries' || $alvo_atual === 'forms'){
		$tem_vinculo = true;
	}

	if($tem_vinculo){
		// Variaveis globais alterar.

		$open = $_GESTOR['variavel-global']['open'];
		$close = $_GESTOR['variavel-global']['close'];
		$openText = $_GESTOR['variavel-global']['openText'];
		$closeText = $_GESTOR['variavel-global']['closeText'];

		if($alvo_atual === 'publisher-highlights' || $alvo_atual === 'menus' || $alvo_atual === 'galleries' || $alvo_atual === 'forms'){
			// req-004 item 7 / req-017 item 1 / req-018: variáveis do template seguem o padrão `[[item#NOME]]`.
			// Para `menus`/`galleries` a lista de variáveis é fixa (vinda de `*_variaveis_template()` via
			// `target_variables`); para `publisher-highlights` ela é dinâmica conforme o publicador.
			$template_map = [];
			if(isset($target_variables) && is_array($target_variables)){
				foreach($target_variables as $var){
					$var_id = is_array($var) ? ($var['id'] ?? '') : (string)$var;
					if($var_id === '') continue;
					// req-019 / DEC-031: variáveis globais (ex.: controles de galeria) usam o
					// placeholder [[var_id]] SEM o prefixo `item#`; as demais mantêm [[item#var_id]].
					$is_global = is_array($var) && !empty($var['global']);
					$variable_str = $is_global ? '[['.$var_id.']]' : '[[item#'.$var_id.']]';
					$template_map[] = [
						'id' => $var_id,
						'variable' => $variable_str,
						'label' => $var_id,
						'type' => 'text',
						'global' => $is_global,
					];
				}
			}

			$publisher_fields_schema = [
				'template_map' => $template_map,
				'fields' => [],
			];
		} else {
			// Filtrar campos do schema para remover formatação de variáveis do backend @[[...]]@ para frontend [[...]]
			$publisher_fields_schema = json_decode($publisher['fields_schema'] ?? '[]', true);

			if(isset($publisher_fields_schema['template_map'])){
				foreach($publisher_fields_schema['template_map'] as $key => $val){
					$publisher_fields_schema['template_map'][$key]['variable'] = preg_replace("/".preg_quote($open)."(.+?)".preg_quote($close)."/", strtolower($openText."$1".$closeText), $val['variable']);
				}
			}
		}

		// Incluir variáveis JS do HTML Editor
    	gestor_js_variavel_incluir('html_editor',[
			'publisher_fields_schema' => $publisher_fields_schema,
		]);

		// Remover blocos desnecessários
		$cel_nome = 'publisher-no-link'; $html_editor_publisher_controls = modelo_tag_del($html_editor_publisher_controls,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	} else {
		$cel_nome = 'publisher-has-link'; $html_editor_publisher_controls = modelo_tag_del($html_editor_publisher_controls,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	}

	return $html_editor_publisher_controls;
}

// ===== Funções principais

/**
 * Componente Editor HTML.
 *
 * Renderiza o componente Editor HTML e suas dependências.
 *
 * @param string $params['editar'] caso seja edição.
 * @param string $params['adicionarEditar'] caso seja adição mas queira modificar HTML e CSS.
 * @param array $params['modulo'] dados do módulo atual.
 * @param array $params['alvo'] alvo de modelos e ia.
 * @param array $params['alvos_modelos'] alvos extras para modelos.
 * @param array $params['publisher'] variáveis do publisher.
 * @param array $params['publisherPage'] controles específicos do publisher page.
 * 
 */
function html_editor_componente($params = false){
	global $_GESTOR;

	if($params)foreach($params as $var => $val)$$var = $val;

	// ===== Verificar parâmetros

	$alvo = isset($alvo)? $alvo : 'paginas';

	// ===== Definir callback de backup baseado no alvo

	$backupCallbackMap = [
		'paginas' => 'adminPaginasBackupCampo',
		'layouts' => 'adminLayoutsBackupCampo',
		'componentes' => 'adminComponentesBackupCampo',
		'publisher' => 'adminPaginasBackupCampo',
		'publisher-highlights' => 'adminPaginasBackupCampo',
		'menus' => 'adminPaginasBackupCampo',
		'galleries' => 'adminPaginasBackupCampo',
		'forms' => 'adminPaginasBackupCampo',
	];

	$backupCallback = isset($backupCallbackMap[$alvo]) ? $backupCallbackMap[$alvo] : 'adminPaginasBackupCampo';

    // ===== Inclusão do CodeMirror

	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/codemirror.min.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/theme/tomorrow-night-bright.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/dialog/dialog.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/display/fullscreen.css" />');
	gestor_pagina_css_incluir('<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/matchesonscrollbar.css" />');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/codemirror.min.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/selection/active-line.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/dialog/dialog.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/searchcursor.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/search.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/scroll/annotatescrollbar.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/matchesonscrollbar.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/search/jump-to-line.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/edit/matchbrackets.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/addon/display/fullscreen.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/mode/xml/xml.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/mode/css/css.js"></script>');
	gestor_pagina_javascript_incluir('<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.20/mode/htmlmixed/htmlmixed.js"></script>');

	// ===== Inclusão Componentes

	interface_componentes_incluir(Array(
		'componente' => Array(
			'modal-alerta',
		)
	));

	// ===== HTML Editor Componente

	$html_editor = gestor_componente(Array(
		'id' => 'html-editor',
	));

	// ===== Modificações do Editor HTML

	switch($alvo){
		case 'publisher':
		case 'publisher-highlights':
			// req-007 item 5: para publisher-highlights, carregar componente de simulação
			// específico com massa de dados enxuta para destaques. Publisher comum continua
			// usando o esqueleto padrão (com variantes sofisticadas para layouts complexos).
			$simulation_component_id = ($alvo === 'publisher-highlights')
				? 'html-editor-publisher-highlights-simulation'
				: 'html-editor-publisher-simulation';

			$html_editor_publisher_simulation = gestor_componente(Array(
				'id' => $simulation_component_id,
			));

			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-simulation#',$html_editor_publisher_simulation);
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-controls#',html_editor_publisher_controls([
				'publisher' => isset($publisher)? $publisher : null,
				'alvo' => $alvo,
				'target_variables' => isset($target_variables)? $target_variables : null,
			]));
		break;
		case 'menus':
			// req-017 item 1: reintegrar a aba "Variáveis"/"Simular" para o módulo menus, com
			// componente de simulação próprio (árvore mockada de itens) e variáveis fixas
			// [[item#X]] declaradas em `menus_variaveis_template()` e recebidas em $target_variables.
			$html_editor_publisher_simulation = gestor_componente(Array(
				'id' => 'html-editor-menus-simulation',
			));

			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-simulation#',$html_editor_publisher_simulation);
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-controls#',html_editor_publisher_controls([
				'alvo' => 'menus',
				'target_variables' => isset($target_variables)? $target_variables : null,
			]));
		break;
		case 'galleries':
			// req-018: aba "Variáveis"/"Simular" para o módulo galleries, com componente de
			// simulação próprio (lista mockada de imagens Picsum) e variáveis fixas [[item#X]]
			// declaradas em `galleries_variaveis_template()` e recebidas em $target_variables.
			$html_editor_publisher_simulation = gestor_componente(Array(
				'id' => 'html-editor-galleries-simulation',
			));

			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-simulation#',$html_editor_publisher_simulation);
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-controls#',html_editor_publisher_controls([
				'alvo' => 'galleries',
				'target_variables' => isset($target_variables)? $target_variables : null,
			]));
		break;
		case 'forms':
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-simulation#','');
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-controls#',html_editor_publisher_controls([
				'alvo' => 'forms',
				'target_variables' => isset($target_variables)? $target_variables : null,
			]));
		break;
		default:
			$cel_nome = 'publisher-html-editor-btns'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$cel_nome = 'publisher-html-editor-variables-menu'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$cel_nome = 'publisher-html-editor-variables-tab'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$html_editor = modelo_var_troca($html_editor,'#html-editor-publisher-simulation#','');
	}

	if(isset($publisherPage) && $publisherPage === true){
		gestor_js_variavel_incluir('html_editor',[
			'publisherPage' => true,
		]);
	} else {
		$cel_nome = 'publisher-page-html-editor-btns'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
	}

    // ===== Editor HTML visual
    $html_editor = modelo_var_troca($html_editor,'#html-editor-modal#',html_editor_include());

	// ===== Variáveis JS do Projeto para o Editor HTML (ex.: caminho do Tailwind CSS)

	if(isset($_GESTOR['project-javascript-html-editor-tailwindcss'])){
		$projectJavascriptTailwindcss = '';
		if($_GESTOR['project-javascript-html-editor-tailwindcss'])
		foreach($_GESTOR['project-javascript-html-editor-tailwindcss'] as $js){
			$projectJavascriptTailwindcss .= "	" . $js . "\n";
		}
	}

	if(isset($_GESTOR['project-css-html-editor-tailwindcss'])){
		$projectCssTailwindcss = '';
		if($_GESTOR['project-css-html-editor-tailwindcss'])
		foreach($_GESTOR['project-css-html-editor-tailwindcss'] as $css){
			$projectCssTailwindcss .= "	" . $css . "\n";
		}
	}

	if(isset($_GESTOR['project-html-editor-tailwindcss-config'])){
		$projectHtmlEditorTailwindcssConfig = $_GESTOR['project-html-editor-tailwindcss-config'];
	}

	// ===== Incluir variável JS do alvo para o frontend
	// req-070 §1.1: 'widget_js_include' parametriza quais scripts controladores de widget (*.widget.js)
	// o preview do Editor HTML deve incluir, vindo de cada módulo. Quando ausente (null), o frontend
	// aplica o fallback padrão com os 4 módulos do core.
	gestor_js_variavel_incluir('html_editor',[
		'alvo' => $alvo,
		'alvos_modelos' => isset($alvos_modelos)? $alvos_modelos : $alvo,
		'widget_js_include' => isset($widget_js_include)? $widget_js_include : null,
		'projectJavascriptTailwindcss' => isset($projectJavascriptTailwindcss)? $projectJavascriptTailwindcss : '',
		'projectCssTailwindcss' => isset($projectCssTailwindcss)? $projectCssTailwindcss : '',
		'projectTailwindcssConfig' => isset($projectHtmlEditorTailwindcssConfig)? $projectHtmlEditorTailwindcssConfig : [],
	]);

	// ===== Modificações específicas por alvo

	switch($alvo){
		case 'layouts':
			// Layouts não possuem html_extra_head - remover aba e conteúdo
			$cel_nome = 'html-extra-head-menu'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
			$cel_nome = 'html-extra-head-content'; $html_editor = modelo_tag_del($html_editor,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');
		break;
	}

	// ===== Pré-Visualização

	$modalPagina = gestor_componente(Array(
		'id' => 'html-editor-visual-modal',
	));

	$modalPagina = modelo_var_troca($modalPagina,'#title#',gestor_variaveis(Array('id' => 'html-editor-modal-title-preview')));
	$modalPagina = modelo_var_troca($modalPagina,'#desktop#',gestor_variaveis(Array('id' => 'html-editor-modal-desktop-preview')));
	$modalPagina = modelo_var_troca($modalPagina,'#tablet#',gestor_variaveis(Array('id' => 'html-editor-modal-tablet-preview')));
	$modalPagina = modelo_var_troca($modalPagina,'#mobile#',gestor_variaveis(Array('id' => 'html-editor-modal-mobile-preview')));
	$modalPagina = modelo_var_troca($modalPagina,'#button-tooltip#',gestor_variaveis(Array('modulo' => 'interface','id' => 'form-button-title')));
	$modalPagina = modelo_var_troca($modalPagina,'#button-value#',gestor_variaveis(Array('modulo' => 'interface','id' => 'form-button-value')));
	$modalPagina = modelo_var_troca($modalPagina,'#button-back-tooltip#',gestor_variaveis(Array('id' => 'html-editor-button-back-tooltip')));
	$modalPagina = modelo_var_troca($modalPagina,'#button-back-value#',gestor_variaveis(Array('id' => 'html-editor-button-back-value')));

	// req-034: controles do Editor HTML Visual (inclusão de elementos/widgets + histórico).
	$modalPagina = modelo_var_troca($modalPagina,'#add-element-tooltip#',gestor_variaveis(Array('id' => 'html-editor-add-element-tooltip')));
	$modalPagina = modelo_var_troca($modalPagina,'#undo-tooltip#',gestor_variaveis(Array('id' => 'html-editor-undo-tooltip')));
	$modalPagina = modelo_var_troca($modalPagina,'#redo-tooltip#',gestor_variaveis(Array('id' => 'html-editor-redo-tooltip')));

	$html_editor = modelo_var_troca($html_editor,'#html-editor-visual-modal#',$modalPagina);

	// ===== Modelos de Páginas

	$modelosPaginas = gestor_componente(Array(
		'id' => 'html-editor-modelos',
	));

	$html_editor = modelo_var_troca($html_editor,'<!-- modelos-componente -->',$modelosPaginas);

	// ===== Assistente IA

    gestor_incluir_biblioteca('ia');

	$html_editor = modelo_var_troca($html_editor,'<!-- ia-componente -->',ia_renderizar_prompt(
		Array(
			'alvo' => $alvo,
			'prompt_controls' => '<div class="menu-pagina-conteudo" data-id="assistente-ia"></div>'
		)
	));

	// ===== Modificações de página

	$html_editor_page_modification = gestor_componente(Array(
		'id' => 'html-editor-page-modification',
	));

	$selectPaginaConteudo = [
        [
            "texto" => gestor_variaveis(Array('id' => 'html-editor-select-all')),
            "valor" => "tudo"
        ],
        [
            "texto" => gestor_variaveis(Array('id' => 'html-editor-select-section')),
            "valor" => "sessao"
        ]
    ];

	$select_modification_page = '';
	if($selectPaginaConteudo){
		foreach($selectPaginaConteudo as $option){
			$select_modification_page .= '<option value="'.$option['valor'].'"'.($option['valor'] == 'tudo'? ' selected="selected"':'').'>'.htmlspecialchars($option['texto']).'</option>';
		}
	}

	$html_editor_page_modification = modelo_var_troca_tudo($html_editor_page_modification,'#select-modification-page#',$select_modification_page);

	$html_editor = modelo_var_troca($html_editor,'#html-editor-page-modification#',$html_editor_page_modification);

	// ===== Dropdown com todos os backups e conteúdo HTML/CSS
    if(isset($adicionarEditar)){
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-editor-html-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css-compiled-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html-extra-head-backup#','');
    } else if(isset($editar)){
        $html_editor = modelo_var_troca($html_editor,'#pagina-editor-html-backup#',interface_backup_campo_select(Array(
            'campo' => 'html',
            'callback' => $backupCallback,
            'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
        )));
        
        $html_editor = modelo_var_troca_fim($html_editor,'#pagina-html-backup#',interface_backup_campo_select(Array(
            'campo' => 'html',
            'callback' => $backupCallback,
            'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
        )));
        
        $html_editor = modelo_var_troca_fim($html_editor,'#pagina-css-backup#',interface_backup_campo_select(Array(
            'campo' => 'css',
            'callback' => $backupCallback,
            'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
        )));
        
        $html_editor = modelo_var_troca_fim($html_editor,'#pagina-css-compiled-backup#',interface_backup_campo_select(Array(
            'campo' => 'css_compiled',
            'callback' => $backupCallback,
            'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
        )));
        
        $html_editor = modelo_var_troca_fim($html_editor,'#pagina-html-extra-head-backup#',interface_backup_campo_select(Array(
            'campo' => 'html_extra_head',
            'callback' => $backupCallback,
            'id_numerico' => interface_modulo_variavel_valor(Array('variavel' => $modulo['tabela']['id_numerico'])),
        )));
    } else {
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html-extra-head#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css-compiled#','');

        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-editor-html-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-css-compiled-backup#','');
        $html_editor = modelo_var_troca_tudo($html_editor,'#pagina-html-extra-head-backup#','');
    }

    // req-044 §5.3: simulações específicas de módulo extraídas do interface. Deve ser carregado
	// ANTES de html-editor-interface (que expõe as instâncias/auxiliares que estas funções usam).
	gestor_pagina_javascript_incluir('biblioteca',[
		'caminho' => 'html-editor-modules',
		'biblioteca' => 'html-editor',
	]);

    // ===== Incluir script JS Interface do HTML Editor que conecta o mesmo com o Gestor/Modulos
	gestor_pagina_javascript_incluir('biblioteca',[
		'caminho' => 'html-editor-interface',
		'biblioteca' => 'html-editor',
	]);

	// req-034: controles do Editor HTML Visual na janela pai (botão "+", histórico,
	// alças de redimensionamento). Arquivo separado para não inflar o html-editor-interface.js.
	gestor_pagina_javascript_incluir('biblioteca',[
		'caminho' => 'html-editor-visual-controls',
		'biblioteca' => 'html-editor',
	]);

	$html_val = isset($html) ? $html : null;
	$html_extra_head_val = isset($html_extra_head) ? $html_extra_head : null;

	if (!is_null($html_val)) {
		$html_editor = modelo_var_troca_tudo($html_editor, '#pagina-html#', htmlspecialchars($html_val, ENT_QUOTES, 'UTF-8'));
	}
	if (!is_null($html_extra_head_val)) {
		$html_editor = modelo_var_troca_tudo($html_editor, '#pagina-html-extra-head#', htmlspecialchars($html_extra_head_val, ENT_QUOTES, 'UTF-8'));
	}

    // ===== Retornar componente
    return $html_editor;
}

/**
 * Incluir o editor HTML visual.
 *
 * Renderiza o editor HTML visual e suas dependências.
 *
 * @param string $params['js_vars'] variáveis JS a serem incluídas.
 * 
 */
function html_editor_include($params = false){
	global $_GESTOR;

	if($params)foreach($params as $var => $val)$$var = $val;

    // Incluir variáveis no HTML Editor
    $overlay_title = gestor_variaveis(Array('id' => 'html-editor-overlay-title'));

	// Configurar ambiente JS do HTML Editor
	$js_script = gestor_pagina_javascript_incluir('biblioteca',[
		'caminho' => 'html-editor',
		'biblioteca' => 'html-editor',
	],true);

    // ===== Variáveis JS do Projeto para o Editor HTML
	$projectJS = Array();

	$projectJS = hook_apply_filters('html-editor', 'html_editor_include.projectJS', $projectJS);

    // ===== Configurar ImagePick para o Editor Visual
    $imagepickJS = Array();

    $imagepickJS['padroes'] = Array(
        'fileId' => '-1',
        'nome' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-default-name')),
        'data' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-default-date')),
        'tipo' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-default-type')),
        'imgSrc' => $_GESTOR['url-full'] . 'images/imagem-padrao.png',
        'caminho' => '',
    );

    $imagepickJS['modal'] = Array(
        'head' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-modal-head')),
        'cancel' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-modal-cancel')),
        'url' => $_GESTOR['url-full'] . 'admin-arquivos/?paginaIframe=sim',
    );

    $imagepickJS['alertas'] = Array(
        'naoImagem' => gestor_variaveis(Array('modulo' => 'interface','id' => 'widget-image-alert-not-image')),
    );

	$imagepickJS = hook_apply_filters('html-editor', 'html_editor_include.imagepickJS', $imagepickJS);

    // Definir variáveis JS padrão do HTML Editor e demais passadas por parâmetro
    $js_vars_default = Array(
        'script' => $js_script,
        'overlay_title' => $overlay_title,
        'imagepick' => $imagepickJS,
        'project' => $projectJS,
    );

    // Mesclar variáveis padrão com as passadas por parâmetro
    $js_vars_final = isset($js_vars)? array_merge($js_vars_default,$js_vars) : $js_vars_default;

    // Incluir variáveis JS do HTML Editor
    gestor_js_variavel_incluir('html_editor',$js_vars_final);

    // Incluir script JS Helper do HTML Editor que conecta o mesmo com o Gestor/Modulos
	gestor_pagina_javascript_incluir('biblioteca',[
		'caminho' => 'html-editor-helper',
		'biblioteca' => 'html-editor',
	]);

    // Incluir componentes do HTML Editor

    $html_editor_modal = gestor_componente(Array(
		'id' => 'html-editor-modal'
	));

    // Incluir modal-iframe para o ImagePick
    interface_componentes_incluir(Array(
        'componente' => Array(
            'modal-iframe',
            'modal-alerta',
        )
    ));

    return '<div class="html-editor-container hidden">'.$html_editor_modal.'</div>';
}

// ==== Ajax

/**
 * AJAX Interface.
 *
 * Orquestra as chamadas AJAX do Editor HTML.
 *
 * @param array $params Parâmetros da função.
 */
function html_editor_ajax_interface($params = false){
	global $_GESTOR;

	if($params)foreach($params as $var => $val)$$var = $val;

    gestor_incluir_biblioteca('ia');

	ia_ajax_interface();

    switch($_GESTOR['ajax-opcao']){
        case 'html-editor-ia-requests': html_editor_ajax_ia_requests(); break;
        case 'html-editor-templates-load': html_editor_ajax_templates_load(); break;
        case 'html-editor-widget-types': html_editor_ajax_widget_types(); break;
        case 'html-editor-widgets-list': html_editor_ajax_widgets_list(); break;
        case 'html-editor-widget-render': html_editor_ajax_widget_render(); break;
        case 'html-editor-render-vars': html_editor_ajax_render_vars(); break;
	}
}

/**
 * ============================================================================
 * req-093 (BATCH-093) — Renderização de variáveis/widgets como caixas no Editor
 * HTML Visual CLÁSSICO e no preview, espelhando a Editbar (Dashboard Site Toolbar).
 *
 * Diferença-chave para a Editbar: o Editor Clássico trabalha com o HTML do
 * CodeMirror, onde as variáveis vêm SEM o cerco de execução (`[[var]]`, pois o
 * template-load converte `@[[`→`[[`). Por isso a regex é TOLERANTE a `@?[[...]]@?`
 * e o marcador guardado em `data-c2f-marker` preserva EXATAMENTE o texto de
 * entrada — garantindo round-trip perfeito na reversão do frontend (seja `[[var]]`
 * ou `@[[var]]@`). Estas funções são uma DUPLICAÇÃO deliberada das da Editbar
 * (decisão do Chefe: manter a Editbar intacta), adaptadas ao contrato do clássico.
 * ============================================================================
 */

// Regex tolerante ao cerco de execução: casa `[[id]]`, `@[[id]]`, `[[id]]@`, `@[[id]]@`.
function html_editor_var_pattern(){
	return '/@?\[\[(.+?)\]\]@?/';
}

// Envolve um conteúdo dinâmico numa caixa de destaque, guardando o marcador ORIGINAL em base64
// (`data-c2f-marker`) para a reconstrução determinística no save.
function html_editor_var_box($marker, $rendered, $tipo){
	$b64 = base64_encode($marker);
	$tag = ($tipo === 'widget') ? 'div' : 'span';
	return '<'.$tag.' class="c2f-dyn-box c2f-'.$tipo.'-box" data-c2f-marker="'.$b64.'" contenteditable="false">'.$rendered.'</'.$tag.'>';
}

// Renderiza um widget pela assinatura (`modulo->func({json})`) em modo page-load.
function html_editor_render_widget_signature($signature){
	global $_GESTOR;

	$sig = trim((string)$signature);
	if($sig === '' || !preg_match('/^[a-zA-Z0-9_\-]+->[a-zA-Z0-9_\-]+\(.*\)$/', $sig)) return '';

	gestor_incluir_biblioteca('widgets');
	$ajaxAnterior = isset($_GESTOR['ajax']) ? $_GESTOR['ajax'] : false;
	$_GESTOR['ajax'] = false;
	$out = widgets_get(Array('id' => $sig));
	$_GESTOR['ajax'] = $ajaxAnterior;

	return (string)$out;
}

// Resolve o valor renderizado de uma variável global pelo id. Retorna null quando desconhecida
// (nesse caso o marcador é mantido literal — pode ser uma variável LOCAL do módulo, resolvida pela
// simulação no frontend).
function html_editor_resolver_var($id){
	global $_GESTOR;

	if($id === 'pagina#menu'){
		return (function_exists('gestor_pagina_menu') ? (string)gestor_pagina_menu() : '');
	}

	$sys = Array(
		'pagina#url-raiz' => (isset($_GESTOR['url-raiz']) ? $_GESTOR['url-raiz'] : ''),
		'pagina#url-full-http' => (isset($_GESTOR['url-full-http']) ? $_GESTOR['url-full-http'] : ''),
		'gestor#versao' => (isset($_GESTOR['versao']) ? $_GESTOR['versao'] : ''),
	);
	if(array_key_exists($id, $sys)) return (string)$sys[$id];

	if(function_exists('gestor_variaveis_globais')){
		$valor = gestor_variaveis_globais(Array('id' => $id));
		if(isset($valor) && $valor !== false){
			return (string)(existe($valor) ? $valor : '');
		}
	}

	return null;
}

// Troca os widgets (comentário `<!-- widgets#SIG < --> … > -->` ou inline `@?[[widgets#SIG]]@?`) pelo
// widget renderizado, mantendo os marcadores de comentário vivos (o motor os reconhece como átomo).
function html_editor_boxes_widgets($html){
	$html = preg_replace_callback('/<!--\s*widgets#(.+?)\s*<\s*-->([\s\S]*?)<!--\s*widgets#\s*\1\s*>\s*-->/i', function($m){
		$sig = trim($m[1]);
		return '<!-- widgets#'.$sig.' < -->'.html_editor_render_widget_signature($sig).'<!-- widgets#'.$sig.' > -->';
	}, $html);

	$html = preg_replace_callback('/@?\[\[widgets#(.+?)\]\]@?/i', function($m){
		$sig = trim($m[1]);
		return '<!-- widgets#'.$sig.' < -->'.html_editor_render_widget_signature($sig).'<!-- widgets#'.$sig.' > -->';
	}, $html);

	return $html;
}

// Resolve TODAS as variáveis globais para o VALOR (texto puro, sem caixas) — usado no preview iframe.
// Variáveis desconhecidas (locais) e widgets inline são mantidos literais.
function html_editor_resolver_variaveis($html){
	return preg_replace_callback(html_editor_var_pattern(), function($m){
		if(stripos($m[1], 'widgets#') === 0) return $m[0]; // widget inline: tratado à parte
		$val = html_editor_resolver_var(trim($m[1]));
		return ($val === null) ? $m[0] : $val;
	}, $html);
}

// Envolve as variáveis GLOBAIS em caixas: em TEXTO vira `.c2f-var-box` (valor + marcador); em ATRIBUTO
// resolve para o valor (visual correto). Variáveis desconhecidas (locais/simulação) ficam literais.
function html_editor_boxes_variaveis($html){
	$pattern = html_editor_var_pattern();
	$parts = preg_split('/(<[^>]*>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
	$out = '';

	foreach($parts as $i => $part){
		if(($i % 2) === 1){
			// Segmento de TAG (atributos): resolve para o valor.
			$out .= preg_replace_callback($pattern, function($m){
				if(stripos($m[1], 'widgets#') === 0) return $m[0];
				$val = html_editor_resolver_var(trim($m[1]));
				return ($val === null) ? $m[0] : $val;
			}, $part);
		} else {
			// Segmento de TEXTO: cada variável GLOBAL vira caixa de destaque.
			$out .= preg_replace_callback($pattern, function($m){
				if(stripos($m[1], 'widgets#') === 0) return $m[0];
				$val = html_editor_resolver_var(trim($m[1]));
				if($val === null) return $m[0];
				return html_editor_var_box($m[0], htmlspecialchars($val, ENT_QUOTES, 'UTF-8'), 'var');
			}, $part);
		}
	}

	return $out;
}

/**
 * AJAX — Recebe o HTML do editor (CodeMirror) e devolve duas versões renderizadas (req-093):
 *   - `boxes`:  variáveis globais em caixas (`.c2f-var-box` + `data-c2f-marker`) + widgets renderizados
 *               entre comentários — para carregar no EDITOR VISUAL (átomos reversíveis no save).
 *   - `values`: variáveis globais resolvidas para valor puro (sem caixas) — para o PREVIEW iframe.
 * As variáveis LOCAIS/de simulação (desconhecidas do backend) são preservadas para o frontend resolver.
 */
function html_editor_ajax_render_vars(){
	global $_GESTOR;

	$html = $_REQUEST['params']['html'] ?? $_REQUEST['html'] ?? '';
	$html = (string)$html;

	$comWidgets = html_editor_boxes_widgets($html);

	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data' => Array(
			'boxes'  => html_editor_boxes_variaveis($comWidgets),
			'values' => html_editor_resolver_variaveis($comWidgets),
		),
	);
}

/**
 * AJAX Widget Render.
 *
 * Renderiza o HTML (esqueleto/conteúdo) de um widget a partir da sua assinatura
 * (`modulo->render({...})`) para preencher o wrapper virtual no Editor HTML Visual (req-039 §1.7).
 *
 */
function html_editor_ajax_widget_render(){
	global $_GESTOR;

	$signature = $_REQUEST['params']['signature'] ?? $_REQUEST['signature'] ?? '';
	$signature = trim((string)$signature);

	// Aceita apenas o formato modular `modulo->func({json})` para evitar execução arbitrária.
	if($signature === '' || !preg_match('/^[a-zA-Z0-9_\-]+->[a-zA-Z0-9_\-]+\(.*\)$/', $signature)){
		$_GESTOR['ajax-json'] = Array(
			'status' => 'error',
			'message' => 'Assinatura de widget inválida.',
		);
		return;
	}

	gestor_incluir_biblioteca('widgets');

	// Renderizar em modo page-load (HTML estrutural completo do widget), não em modo AJAX.
	$ajaxAnterior = isset($_GESTOR['ajax']) ? $_GESTOR['ajax'] : false;
	$_GESTOR['ajax'] = false;
	$html = widgets_get(Array('id' => $signature));
	$_GESTOR['ajax'] = $ajaxAnterior;

	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data' => Array(
			'signature' => $signature,
			'html' => (string)$html,
		),
	);
}

/**
 * AJAX Widget Types.
 *
 * Retorna a lista de categorias/tipos de widget ativos (req-066 §4.1) para o carregamento
 * inicial do painel de inclusão do Editor HTML Visual. Lê a tabela global `widgets`, populada
 * dinamicamente pela esteira de Sincronização de Recursos, em vez de uma lista hardcoded.
 *
 */
function html_editor_ajax_widget_types(){
	global $_GESTOR;

	$idioma = $_GESTOR['linguagem-codigo'];

	$tipos = [];
	$retorno_bd = banco_select([
		'tabela' => 'widgets',
		'campos' => ['id', 'name', 'icon'],
		'extra'  => "WHERE status = 'A' AND language = '" . banco_escape_field($idioma) . "' ORDER BY name ASC",
	]);

	if($retorno_bd){
		foreach($retorno_bd as $registro){
			$tipos[] = [
				'id'   => $registro['id'],
				'name' => $registro['name'],
				'icon' => $registro['icon'],
			];
		}
	}

	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data'   => $tipos,
	);
}

/**
 * AJAX Widgets List.
 *
 * Retorna os registros de widget (slug + nome) de UMA categoria/tipo, sob demanda (req-066 §4.2).
 * Resolve a tabela alvo (e a coluna de filtro opcional) na tabela global `widgets` a partir do
 * parâmetro `module` recebido do request e, então, consulta a tabela alvo dinamicamente.
 *
 */
function html_editor_ajax_widgets_list(){
	global $_GESTOR;

	$idioma = $_GESTOR['linguagem-codigo'];

	// Categoria/tipo solicitada pelo frontend (lazy load por grupo).
	$module = $_REQUEST['params']['module'] ?? $_REQUEST['params']['widget_type'] ?? $_REQUEST['module'] ?? '';
	$module = trim((string)$module);

	if($module === ''){
		$_GESTOR['ajax-json'] = Array('status' => 'Ok', 'data' => []);
		return;
	}

	// 1) Localizar a definição do widget na tabela global `widgets`.
	$definicao = banco_select([
		'unico'  => true,
		'tabela' => 'widgets',
		'campos' => ['tabela', 'coluna_where'],
		'extra'  => "WHERE id = '" . banco_escape_field($module) . "'"
			. " AND language = '" . banco_escape_field($idioma) . "'"
			. " AND status = 'A' LIMIT 1",
	]);

	if(!$definicao || empty($definicao['tabela'])){
		$_GESTOR['ajax-json'] = Array('status' => 'Ok', 'data' => []);
		return;
	}

	$tabela = $definicao['tabela'];
	$coluna_where = isset($definicao['coluna_where']) ? trim((string)$definicao['coluna_where']) : '';

	// Validação anti-SQL Injection: o nome da tabela e da coluna devem conter apenas
	// caracteres seguros (alfanuméricos e underscore), pois são interpolados na query.
	if(!preg_match('/^[a-zA-Z0-9_]+$/', $tabela)){
		$_GESTOR['ajax-json'] = Array('status' => 'Ok', 'data' => []);
		return;
	}

	// 2) Montar a cláusula WHERE da tabela alvo.
	$where = "WHERE status = 'A' AND language = '" . banco_escape_field($idioma) . "'";
	if($coluna_where !== '' && preg_match('/^[a-zA-Z0-9_]+$/', $coluna_where)){
		$where .= " AND " . $coluna_where . " = '" . banco_escape_field($module) . "'";
	}

	// 3) Consultar a tabela alvo. A coluna de rótulo padrão das tabelas de widget é `name`;
	// quando ausente/vazia, faz fallback para o próprio `id`.
	$registros = [];
	$retorno_bd = banco_select([
		'tabela' => $tabela,
		'campos' => ['id', 'name'],
		'extra'  => $where . " ORDER BY name ASC",
	]);

	if($retorno_bd){
		foreach($retorno_bd as $registro){
			$nome = (isset($registro['name']) && $registro['name'] !== '') ? $registro['name'] : $registro['id'];
			$registros[] = [
				'id'   => $registro['id'],
				'nome' => $nome,
			];
		}
	}

	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data'   => $registros,
	);
}

/**
 * Busca paginada de itens de widget para o painel "+" do Live Editor (BATCH-081 §6).
 *
 * Diferente de `html_editor_ajax_widgets_list` (usada pelo editor clássico, shape antigo), esta
 * função devolve `{status, data:{items:[{id,nome,module}], tem_mais}}`. Suporta:
 *  - `module`: restringe a UM grupo/categoria; vazio + `busca` → varre todas as categorias (cross-grupo);
 *  - `busca`:  filtra por `name`/`id` (LIKE), habilitando o autocomplete inteligente;
 *  - `pagina`/`limite`: paginação "Carregar mais".
 *
 * @param array $params { module?:string, busca?:string, pagina?:int, limite?:int }
 * @return array Estrutura de resposta pronta para `$_GESTOR['ajax-json']`.
 */
function html_editor_widgets_buscar($params = array()){
	global $_GESTOR;

	$idioma = $_GESTOR['linguagem-codigo'];
	$module = isset($params['module']) ? trim((string)$params['module']) : '';
	$busca  = isset($params['busca']) ? trim((string)$params['busca']) : '';
	$pagina = isset($params['pagina']) ? (int)$params['pagina'] : 1;
	$limite = isset($params['limite']) ? (int)$params['limite'] : 10;
	if($pagina < 1) $pagina = 1;
	if($limite < 1) $limite = 10;

	// 1) Definições de widget (tabela global `widgets`): uma categoria ou todas (cross-grupo).
	$extraDef = "WHERE status = 'A' AND language = '" . banco_escape_field($idioma) . "'";
	if($module !== ''){
		$extraDef .= " AND id = '" . banco_escape_field($module) . "'";
	}
	$definicoes = banco_select([
		'tabela' => 'widgets',
		'campos' => ['id', 'tabela', 'coluna_where'],
		'extra'  => $extraDef . " ORDER BY name ASC",
	]);

	if(!$definicoes){
		return Array('status' => 'Ok', 'data' => Array('items' => Array(), 'tem_mais' => false));
	}

	// 2) Coletar os itens de cada tabela alvo (com validação anti-injection e filtro de busca).
	$buscaEsc = banco_escape_field($busca);
	$itens = Array();

	foreach($definicoes as $def){
		$tabela = isset($def['tabela']) ? trim((string)$def['tabela']) : '';
		if($tabela === '' || !preg_match('/^[a-zA-Z0-9_]+$/', $tabela)){ continue; }

		$coluna_where = isset($def['coluna_where']) ? trim((string)$def['coluna_where']) : '';

		$where = "WHERE status = 'A' AND language = '" . banco_escape_field($idioma) . "'";
		if($coluna_where !== '' && preg_match('/^[a-zA-Z0-9_]+$/', $coluna_where)){
			$where .= " AND " . $coluna_where . " = '" . banco_escape_field($def['id']) . "'";
		}
		if($busca !== ''){
			$where .= " AND (name LIKE '%" . $buscaEsc . "%' OR id LIKE '%" . $buscaEsc . "%')";
		}

		$retorno_bd = banco_select([
			'tabela' => $tabela,
			'campos' => ['id', 'name'],
			'extra'  => $where . " ORDER BY name ASC",
		]);

		if($retorno_bd)foreach($retorno_bd as $registro){
			$nome = (isset($registro['name']) && $registro['name'] !== '') ? $registro['name'] : $registro['id'];
			$itens[] = Array('id' => $registro['id'], 'nome' => $nome, 'module' => $def['id']);
		}
	}

	// 3) Ordenar (por nome) e paginar.
	usort($itens, function($a, $b){ return strcasecmp($a['nome'], $b['nome']); });

	$total = count($itens);
	$offset = ($pagina - 1) * $limite;
	$pagina_itens = array_slice($itens, $offset, $limite);
	$tem_mais = ($offset + $limite) < $total;

	return Array('status' => 'Ok', 'data' => Array('items' => array_values($pagina_itens), 'tem_mais' => $tem_mais));
}

/**
 * AJAX Templates.
 *
 * Retorna um template via AJAX para o frontend.
 *
 */
function html_editor_ajax_templates_load(){
	global $_GESTOR;

	// Pegar parâmetros de paginação
	$pagina = (int)($_REQUEST['params']['pagina'] ?? 1);
	$limite = (int)($_REQUEST['params']['limite'] ?? 10);
	$framework_css = ($_REQUEST['params']['framework_css'] ?? 'fomantic-ui');
	$alvo = ($_REQUEST['params']['alvo'] ?? 'paginas');
	$alvos_modelos = ($_REQUEST['params']['alvos_modelos'] ?? $alvo);
	$offset = ($pagina - 1) * $limite;

	// Pegar idioma atual
	$idioma = $_GESTOR['linguagem-codigo'];

	// Filtrar por modelos
	if(strpos($alvos_modelos,',') !== false){
		$alvos_modelos_array = explode(',',$alvos_modelos);
		$alvos_modelos_array = array_map('trim',$alvos_modelos_array);
		$alvos_modelos_array = array_map(function($item){ return "'" . banco_escape_field($item) . "'"; }, $alvos_modelos_array);
		$alvos_modelos_string = implode(',',$alvos_modelos_array);
		$where_templates = "WHERE status = 'A' AND framework_css = '" . banco_escape_field($framework_css) . "' AND language = '" . banco_escape_field($idioma) . "' AND target IN (" . $alvos_modelos_string . ")";
	} else {
		$where_templates = "WHERE status = 'A' AND framework_css = '" . banco_escape_field($framework_css) . "' AND language = '" . banco_escape_field($idioma) . "' AND target = '" . banco_escape_field($alvo) . "'";
	}

	// Busca textual opcional por nome (usada pelo Live Editor — BATCH-080). Retrocompatível:
	// o editor clássico não envia `busca`, então o comportamento não muda.
	$busca = trim($_REQUEST['params']['busca'] ?? '');
	if($busca !== ''){
		$where_templates .= " AND nome LIKE '%".banco_escape_field($busca)."%'";
	}

	// Buscar templates no banco de dados

	// Hook: permite filtrar o WHERE de templates (ex: multi-usuário)
	$where_templates = hook_apply_filters('html-editor', 'templates.load.where', $where_templates);

	$retorno_bd = banco_select([
		'tabela' => 'templates',
		'campos' => [
			'id',
			'nome',
			'thumbnail',
			'target',
			'language',
			'html',
			'html_extra_head',
			'css',
			'css_compiled',
			'framework_css',
		],
		'extra' => 
			$where_templates
			." ORDER BY data_modificacao DESC"
			." LIMIT " . $limite . " OFFSET " . $offset
	]);

	// ===== Variaveis globais alterar.
	
	$open = $_GESTOR['variavel-global']['open'];
	$close = $_GESTOR['variavel-global']['close'];
	$openText = $_GESTOR['variavel-global']['openText'];
	$closeText = $_GESTOR['variavel-global']['closeText'];

	// Processar modelos
	$modelos = [];
	if($retorno_bd){
		foreach($retorno_bd as $modelo){
			$modelo['html'] = preg_replace("/".preg_quote($open)."(.+?)".preg_quote($close)."/", strtolower($openText."$1".$closeText), $modelo['html']);
			$modelo['css'] = preg_replace("/".preg_quote($open)."(.+?)".preg_quote($close)."/", strtolower($openText."$1".$closeText), $modelo['css']);
			
			$modelos[] = [
				'id' => $modelo['id'],
				'nome' => $modelo['nome'],
				'thumbnail' => $_GESTOR['url-raiz'] . ($modelo['thumbnail'] ?: 'images/imagem-padrao.png'),
				'target' => $modelo['target'],
				'language' => $modelo['language'],
				'html' => $modelo['html'],
				'html_extra_head' => $modelo['html_extra_head'],
				'css' => $modelo['css'],
				'css_compiled' => $modelo['css_compiled'],
				'framework_css' => $modelo['framework_css']
			];
		}
	}

	// Verificar se há mais modelos
	$total_modelos = banco_select([
		'tabela' => 'templates',
		'campos' => ['COUNT(*) as total'],
		'extra' => 
			$where_templates
	]);

	$tem_mais = false;
	if($total_modelos && $total_modelos[0]['COUNT(*) as total'] > ($offset + count($modelos))){
		$tem_mais = true;
	}

	// Retorno do AJAX
	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data' => [
			'modelos' => $modelos,
			'tem_mais' => $tem_mais,
			'pagina' => $pagina,
			'total_carregados' => count($modelos)
		]
	);
}

/**
 * AJAX IA Requests.
 *
 * Retorna uma requisição IA via AJAX para o frontend.
 *
 */
function html_editor_ajax_ia_requests(){
	global $_GESTOR;

	// Pegar dados anterior da página
	$html = $_REQUEST['data']['html'] ?? '';
	$css = $_REQUEST['data']['css'] ?? '';
	$framework_css = $_REQUEST['data']['framework_css'] ?? '';
	$sessao_id = $_REQUEST['data']['sessao_id'] ?? '';
	$sessao_opcao = $_REQUEST['data']['sessao_opcao'] ?? '';
	

	// Modificar o modo IA antes de enviar
	$modo = $_REQUEST['mode'] ?? '';

	$modo = modelo_var_troca_tudo($modo,'{{html}}',$html);
	$modo = modelo_var_troca_tudo($modo,'{{css}}',$css);
	$modo = modelo_var_troca_tudo($modo,'{{framework_css}}',$framework_css);

	// Modificar o modo por target
	$target = $_REQUEST['target'] ?? '';

	switch($target){
		case 'publisher':
			$publisher_variables = $_REQUEST['data']['publisher_variables'] ?? '';

            // Definição dos tipos e descrições
            $types_skeleton = [
                'text' => gestor_variaveis(Array('id' => 'hep-variable-type-text-description')),
                'textarea' => gestor_variaveis(Array('id' => 'hep-variable-type-textarea-description')),
                'html' => gestor_variaveis(Array('id' => 'hep-variable-type-html-description')),
                'image' => gestor_variaveis(Array('id' => 'hep-variable-type-image-description'))
            ];

			$types_skeleton_found = [];

			$variables = "[variables]\n";

            if($publisher_variables && is_array($publisher_variables)){
                foreach($publisher_variables as $variable){
                    $var_name = $variable['name'] ?? '';
                    $var_type = $variable['type'] ?? '';

					// Formatar variável no formato [[publisher#type#name]]
					$var_name = '[[publisher#' . $var_type . '#' . $var_name . ']]';

                    if($var_name && $var_type){
                        $variables .= $var_name . ' | ' . $var_type . "\n";
						$types_skeleton_found[$var_type] = true;
                    }
                }
            }

			$variables .= "[description]\n";

            // Adicionar descrições dos tipos
            foreach($types_skeleton as $type => $desc){
				if(!isset($types_skeleton_found[$type]))continue;
                $variables .= $type . ' | ' . $desc . "\n";
            }

			$modo = modelo_var_troca_tudo($modo,'{{variables}}',$variables);
		break;
		case 'publisher-highlights':
			// BATCH-009: o modo IA do publisher-highlights espera variáveis no
			// formato `[[item#nome_da_variavel]]` (sem o `tipo_de_dado`), pois o
			// tipo é resolvido em runtime via mapeamento com o publisher vinculado.
			$publisher_variables = $_REQUEST['data']['publisher_variables'] ?? '';

			$variables = "[variables]\n";

			if($publisher_variables && is_array($publisher_variables)){
				foreach($publisher_variables as $variable){
					$var_name = $variable['name'] ?? '';
					if(!$var_name) continue;
					$variables .= '[[item#' . $var_name . ']]' . "\n";
				}
			}

			$modo = modelo_var_troca_tudo($modo,'{{variables}}',$variables);
		break;
		case 'menus':
			// req-019: variáveis fixas dos templates de menu (item#X), espelhando
			// menus_variaveis_template(). O modo IA recebe a lista de placeholders válidos.
			$variables = "[variables]\n";
			foreach(['label','url','target','slug','css_classes','children'] as $var_name){
				$variables .= '[[item#'.$var_name.']]'."\n";
			}
			$modo = modelo_var_troca_tudo($modo,'{{variables}}',$variables);
		break;
		case 'galleries':
			// req-019 / DEC-031: variáveis de imagem (item#X) + variáveis globais de controle
			// ([[X]] sem item#), espelhando galleries_variaveis_template().
			$variables = "[variables]\n";
			foreach(['img-src','caminho','nome','legenda'] as $var_name){
				$variables .= '[[item#'.$var_name.']]'."\n";
			}
			foreach(['show_arrows','show_dots','autoplay','autoplay_speed','loop'] as $var_name){
				$variables .= '[['.$var_name.']]'."\n";
			}
			$modo = modelo_var_troca_tudo($modo,'{{variables}}',$variables);
		break;
		default:
			$cel_nome = 'publisher'; $modelo_texto = modelo_tag_del($modelo_texto,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->');

	}

	// Preparar prompt completo
	$prompt = $_REQUEST['prompt'] ?? '';
	$prompt = $modo . "\n\n" . $prompt;

	// Pegar o modelo e servidor id
	$server_id = $_REQUEST['server_id'] ?? '';
	$model = $_REQUEST['model'] ?? null;

	// Enviar request para o servidor de IA
	$retorno = ia_enviar_prompt([
		'servidor_id' => $server_id,
		'prompt' => $prompt,
		'modelo' => $model,
	]);

	// Pegar HTML e CSS do retorno
	$html_gerado = '';
	$css_gerado = '';
	
	if($retorno['status'] === 'success' && isset($retorno['data']['texto_gerado'])){
		$texto_resposta = $retorno['data']['texto_gerado'];
		
		// Extrair HTML entre ```html e ```
		if(preg_match('/```html\s*(.*?)\s*```/s', $texto_resposta, $matches_html)){
			$html_gerado = trim($matches_html[1]);
		}
		
		// Extrair CSS entre ```css e ```
		if(preg_match('/```css\s*(.*?)\s*```/s', $texto_resposta, $matches_css)){
			$css_gerado = trim($matches_css[1]);
		}
	} else {
		// Em caso de erro, retornar mensagem
		$_GESTOR['ajax-json'] = Array(
			'status' => 'error',
			'message' => $retorno['message'] ?? gestor_variaveis(Array('modulo' => 'admin-ia','id' => 'requests-error-message')),
		);
		return;
	}

	// Incluir HTML e CSS gerado no retorno
	$retorno['data']['html_gerado'] = $html_gerado;
	$retorno['data']['css_gerado'] = $css_gerado;
	$retorno['data']['sessao_id'] = $sessao_id;
	$retorno['data']['sessao_opcao'] = $sessao_opcao;

	// Retorno do AJAX
	$_GESTOR['ajax-json'] = Array(
		'status' => 'Ok',
		'data' => $retorno['data'],
	);
}

?>
