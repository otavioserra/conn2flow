<?php
/*********
	Descrição: configurações gerais para o funcionamento do gestor.
**********/

// ===== Definições de variáveis gerais do gestor.

$_GESTOR										=	Array();

$_GESTOR['versao']						        = 	'2.9.22'; // Versão do gestor como um todo.
$_GESTOR['id']									=	'conn2flow-'; // Identificador básico do gestor

// ===== Definição dos marcadores de abertura e fechamento de varíaveis globais.

$_GESTOR['variavel-global']						=	Array(
	'open' => '@[[', // Abertura de uma variável na execução da mesma
	'close' => ']]@', // Fechamento de uma variável na execução da mesma
	'openText' => '[[', // Abertura de uma variável na definição da mesma
	'closeText' => ']]', // Fechamento de uma variável na definição da mesma
);

if (php_sapi_name() === 'cli') {
	// Ambiente de linha de comando (usado por Phinx, scripts, etc.)
	// Define o ROOT_PATH de forma absoluta e confiável a partir da localização deste arquivo.
	$_GESTOR['ROOT_PATH'] = __DIR__ . '/';
	// Define um SERVER_NAME padrão para a lógica de configuração funcionar.
	$_SERVER['SERVER_NAME'] = 'localhost';
} else if(isset($_CRON)){
	// Ambiente de execução via CRON
	$_SERVER['SERVER_NAME'] = $_CRON['SERVER_NAME'];
	$_GESTOR['ROOT_PATH'] = $_CRON['ROOT_PATH'];
} else {
	// Ambiente de execução via Web (Apache, etc.)
	$_GESTOR['ROOT_PATH'] = $_INDEX['sistemas-dir'];
}

// ===== Definição dos caminhos de autenticação.

$_GESTOR['AUTH_PATH']							=	$_GESTOR['ROOT_PATH'] . 'autenticacoes/';
$_GESTOR['AUTH_PATH_SERVER']					=	$_GESTOR['AUTH_PATH'] . $_SERVER['SERVER_NAME'] . '/';

// ===== Carregar dependências do Composer e o arquivo .env correto para o ambiente =====

require_once $_GESTOR['ROOT_PATH'] . 'vendor/autoload.php';

if (class_exists(Dotenv\Dotenv::class)) {
    $loaded = false;

    // candidato principal: pasta do domínio atual
    $domainBase = $_GESTOR['AUTH_PATH_SERVER'];

    if (is_dir($domainBase) && file_exists($domainBase . '.env')) {
        try {
            $dotenv = Dotenv\Dotenv::createImmutable($domainBase);
            $dotenv->load();

            $loaded = true;
        } catch (\Dotenv\Exception\InvalidPathException $e) {
            // tentar próximo candidato
        }
    }

    if (!$loaded) {
        $candidates = [];
        $tried  = [];

        // Paths relativos para autenticações
        $authBase   = $_GESTOR['AUTH_PATH'];
        $serverName = $_SERVER['SERVER_NAME'] ?? 'localhost';

        // permitir fallback para domínios adicionais. Adicionar a primeira pasta disponível em autenticacoes/ (sem duplicatas)
        $dirs = glob($authBase . '*', GLOB_ONLYDIR);
        if ($dirs) {
            // preservar a ordem retornada pelo glob (primeira pasta como fallback)
            foreach ($dirs as $d) {
                $d = rtrim($d, '/') . '/';
                if (!in_array($d, $candidates, true)) $candidates[] = $d;
            }
        }

        // tentar carregar o .env de cada pasta candidata até encontrar um válido para o domínio atual
        if(!empty($candidates))
        foreach ($candidates as $path) {
            $tried[] = $path;
            if (is_dir($path) && file_exists($path . '.env')) {
                try {
                    $dotenv = Dotenv\Dotenv::createImmutable($path);
                    $dotenv->load();

                    // atualizar para o path efetivamente usado
                    $_GESTOR['AUTH_PATH_SERVER'] = $path;

                    $loaded = true;
                    break;
                } catch (\Dotenv\Exception\InvalidPathException $e) {
                    // tentar próximo candidato
                }
            }
        }
    }

    if (!$loaded) {
        http_response_code(503);
        // NÃO expor caminhos locais em detalhes — mostrar apenas domínios/basename
        $attempted = array_map(function($p){ return basename(rtrim($p, '\\/')); }, $tried);
        echo json_encode([
            'error' => '503',
            'info' => 'Configuration file (.env) not found for domain: ' . $serverName,
            'details' => 'Tried auth directories for domains: ' . implode(', ', array_filter($attempted))
        ]);
        exit;
    }
} else {
    // Se a classe Dotenv não existe, é porque as dependências do Composer não foram instaladas.
    http_response_code(500);
    echo "Erro Crítico: A classe Dotenv não foi encontrada. Execute 'composer install' na pasta 'gestor'.\n";
    exit(1); // Sai com um código de erro para scripts de linha de comando.
}

// ===== Popular as configurações globais a partir do .env =====

global $_BANCO, $_CONFIG;

// Configurações do Banco
$_BANCO = [
    'tipo'    => $_ENV['DB_CONNECTION'] ?? 'mysqli',
    'host'    => $_ENV['DB_HOST'] ?? 'localhost',
    'nome'    => $_ENV['DB_DATABASE'] ?? '',
    'usuario' => $_ENV['DB_USERNAME'] ?? '',
    'senha'   => $_ENV['DB_PASSWORD'] ?? '',
];

// Linguagem padrão do gestor e listagem de códigos de linguagens.
$_GESTOR['linguagem-padrao']			=	$_ENV['LANGUAGE_DEFAULT'] ?? 'pt-br';
$_GESTOR['linguagem-codigo']			=	$_GESTOR['linguagem-padrao'];
$_GESTOR['languages']		        	=	$_ENV['LANGUAGES'] ? explode(',', $_ENV['LANGUAGES']) : [];

// UID suffix para cookies e sessões, para evitar conflitos entre projetos no mesmo domínio.
$cookieHostSuffix = '';
if (isset($domainBase) && $domainBase !== '') {
    $cookieHostSuffix = '_' . substr(strtoupper(md5(basename(rtrim($domainBase, '/')))), 0, 8);
}

// Configurações Gerais
$_CONFIG = [
    'session-authname'                  => ($_ENV['SESSION_AUTHNAME'] ?? '_C2FSID') . $cookieHostSuffix,
    'session-lifetime'                  => (int)($_ENV['SESSION_LIFETIME'] ?? 10800),
    'session-garbagetime'               => (int)($_ENV['SESSION_GARBAGETIME'] ?? 86400),
    'session-garbage-colector-time'     => (int)($_ENV['SESSION_GARBAGE_COLECTOR_TIME'] ?? 3600),
    'cookie-authname'                   => ($_ENV['COOKIE_AUTHNAME'] ?? '_C2FCID') . $cookieHostSuffix,
    'cookie-authprofile'                => ($_ENV['COOKIE_AUTHPROFILE'] ?? '_C2FCP') . $cookieHostSuffix,
    'cookie-verify'                     => ($_ENV['COOKIE_VERIFY'] ?? '_C2FCVID') . $cookieHostSuffix,
    'cookie-language'                   => ($_ENV['LANGUAGE_COOKIE'] ?? '_C2FCL') . $cookieHostSuffix,
    'cookie-lifetime'                   => (int)($_ENV['COOKIE_LIFETIME'] ?? 1296000),
    'cookie-renewtime'                  => (int)($_ENV['COOKIE_RENEWTIME'] ?? 86400),
    'cookie-secure'                     => filter_var($_ENV['COOKIE_SECURE'] ?? false, FILTER_VALIDATE_BOOLEAN),
    'openssl-password'                  => $_ENV['OPENSSL_PASSWORD'] ?? '',
    'usuario-hash-password'             => $_ENV['USUARIO_HASH_PASSWORD'] ?? '',
    'usuario-hash-algo'                 => $_ENV['USUARIO_HASH_ALGO'] ?? 'sha512',
    'usuario-recaptcha-active'          => filter_var($_ENV['USUARIO_RECAPTCHA_ACTIVE'] ?? false, FILTER_VALIDATE_BOOLEAN),
    'usuario-recaptcha-site'            => $_ENV['USUARIO_RECAPTCHA_SITE'] ?? '',
    'usuario-recaptcha-server'          => $_ENV['USUARIO_RECAPTCHA_SERVER'] ?? '',
    'usuario-recaptcha-v2-active'       => filter_var($_ENV['USUARIO_RECAPTCHA_V2_ACTIVE'] ?? false, FILTER_VALIDATE_BOOLEAN),
    'usuario-recaptcha-v2-site'         => $_ENV['USUARIO_RECAPTCHA_V2_SITE'] ?? '',
    'usuario-recaptcha-v2-server'       => $_ENV['USUARIO_RECAPTCHA_V2_SERVER'] ?? '',
    'usuario-maximo-senhas-invalidas'   => (int)($_ENV['USUARIO_MAXIMO_SENHAS_INVALIDAS'] ?? 3),
    'usuario-autorizacao-lifetime'      => (int)($_ENV['USUARIO_AUTORIZACAO_LIFETIME'] ?? 300),
    'token-lifetime'                    => (int)($_ENV['TOKEN_LIFETIME'] ?? 3600),
    'plano-teste-id-usuario-perfil'     => $_ENV['PLANO_TESTE_ID_USUARIO_PERFIL'] ?? '2',
    'autenticacao-token-lifetime'       => (int)($_ENV['AUTENTICACAO_TOKEN_LIFETIME'] ?? 15552000),

    // Configurações do Site
    'site-name'                         => $_ENV['SITE_NAME'] ?? 'Conn2Flow',

    // Configurações do PayPal
    'paypal'  => [
        'default'                       => $_ENV['PAYPAL_DEFAULT'] ?? 'padrao',
        'mode'                          => $_ENV['PAYPAL_MODE'] ?? 'sandbox',
        'webhook_id'                    => $_ENV['PAYPAL_WEBHOOK_ID'] ?? '',
        ($_ENV['PAYPAL_MODE'] ?? 'sandbox') => [
            'client_id'                 => $_ENV['PAYPAL_CLIENT_ID'] ?? '',
            'client_secret'             => $_ENV['PAYPAL_SECRET'] ?? '',
        ],
    ],

    // Configurações OAuth 2.0
    'oauth2'  => [
        'token-expiration'            => (int)($_ENV['OAUTH2_TOKEN_EXPIRATION'] ?? 3600),
        'refresh-token-expiration'    => (int)($_ENV['OAUTH2_REFRESH_TOKEN_EXPIRATION'] ?? 2592000),
        'maximo-tokens-usuario'       => (int)($_ENV['OAUTH2_MAXIMO_TOKENS_USUARIO'] ?? 5),
    ],

    // Hardening HTTP/API (req-107). Listas são separadas por vírgula no .env.
    'security' => [
        'csp'                 => trim((string)($_ENV['SECURITY_CSP'] ?? '')),
        'csp-report-only'     => filter_var($_ENV['SECURITY_CSP_REPORT_ONLY'] ?? false, FILTER_VALIDATE_BOOLEAN),
        'x-frame-options'     => trim((string)($_ENV['SECURITY_X_FRAME_OPTIONS'] ?? 'SAMEORIGIN')),
    ],
    'api' => [
        'cors-origins'        => array_values(array_filter(array_map('trim', explode(',', (string)($_ENV['API_CORS_ORIGINS'] ?? ''))))),
        'rate-limit-max'      => max(1, (int)($_ENV['API_RATE_LIMIT_MAX'] ?? 100)),
        'rate-limit-window'   => max(60, (int)($_ENV['API_RATE_LIMIT_WINDOW'] ?? 3600)),
    ],

    // Arquitetura de Módulos Distribuídos (req-005)
    // secret      : segredo HMAC compartilhado entre central e distribuído (igual nos dois).
    // central-url : URL base do central (usada pelo distribuído p/ o Iframe e o middleware).
    // endpoint    : endpoint da API do distribuído (usado pelo central p/ o canal de banco).
    'modulo-distribuido' => [
        'secret'      => $_ENV['MODULO_DISTRIBUIDO_SECRET'] ?? '',
        'central-url' => $_ENV['MODULO_DISTRIBUIDO_CENTRAL_URL'] ?? '',
        'endpoint'    => $_ENV['MODULO_DISTRIBUIDO_ENDPOINT'] ?? '',
    ],

    // Controle de Acessos
    'acessos-maximo-falhas-logins'      => (int)($_ENV['ACESSOS_MAXIMO_FALHAS_LOGINS'] ?? 10),
    'acessos-maximo-logins-simples'     => (int)($_ENV['ACESSOS_MAXIMO_LOGINS_SIMPLES'] ?? 3),
    'acessos-tempo-bloqueio-ip'         => (int)($_ENV['ACESSOS_TEMPO_BLOQUEIO_IP'] ?? 86400),
    'acessos-tempo-desbloqueio-ip'      => (int)($_ENV['ACESSOS_TEMPO_DESBLOQUEIO_IP'] ?? 2592000),
    'acessos-maximo-cadastros'          => [
        'signup' => (int)($_ENV['ACESSOS_MAXIMO_CADASTROS_SIGNUP'] ?? 1),
        'formulario-contato' => (int)($_ENV['ACESSOS_MAXIMO_CADASTROS_FORMULARIO_CONTATO'] ?? 10),
    ],
    'acessos-maximo-cadastros-simples'  => [
        'signup' => (int)($_ENV['ACESSOS_MAXIMO_CADASTROS_SIMPLES_SIGNUP'] ?? 1),
        'formulario-contato' => (int)($_ENV['ACESSOS_MAXIMO_CADASTROS_SIMPLES_FORMULARIO_CONTATO'] ?? 3),
    ],
    // Controle de Formulários
    'formularios-tempo-limpeza'             => (int)($_ENV['FORMULARIOS_TEMPO_LIMPEZA'] ?? 2592000),
    'formularios-tempo-bloqueio-ip'         => (int)($_ENV['FORMULARIOS_TEMPO_BLOQUEIO_IP'] ?? 86400),
    'formularios-maximo-cadastros'          => (int)($_ENV['FORMULARIOS_MAXIMO_CADASTROS'] ?? 10),
    'formularios-maximo-cadastros-simples'  => (int)($_ENV['FORMULARIOS_MAXIMO_CADASTROS_SIMPLES'] ?? 3),
    'email' => [
        'ativo' => filter_var($_ENV['EMAIL_ACTIVE'] ?? false, FILTER_VALIDATE_BOOLEAN),
        'server' => [
            'host' => $_ENV['EMAIL_HOST'] ?? '',
            'user' => $_ENV['EMAIL_USER'] ?? '',
            'pass' => $_ENV['EMAIL_PASS'] ?? '',
            'secure' => filter_var($_ENV['EMAIL_SECURE'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'port' => (int)($_ENV['EMAIL_PORT'] ?? 587),
        ],
        'sender' => [
            'from' => $_ENV['EMAIL_FROM'] ?? '',
            'fromName' => $_ENV['EMAIL_FROM_NAME'] ?? '',
            'replyTo' => $_ENV['EMAIL_REPLY_TO'] ?? '',
            'replyToName' => $_ENV['EMAIL_REPLY_TO_NAME'] ?? '',
        ]
    ],
    'language' => [
        'widget-active' => filter_var($_ENV['LANGUAGE_WIDGET_ACTIVE'] ?? false, FILTER_VALIDATE_BOOLEAN),
        'auto-detect' => filter_var($_ENV['LANGUAGE_AUTO_DETECT'] ?? false, FILTER_VALIDATE_BOOLEAN),
    ],
];

// O caminho das chaves agora também vem do .env, mas a pasta base é a do ambiente.
$_GESTOR['openssl-path'] = $_GESTOR['AUTH_PATH_SERVER'] . ($_ENV['OPENSSL_KEYS_SUBDIR'] ?? 'chaves/gestor/');

// ===== Definição do caminho em disco dos plugins.

$_GESTOR['plugins-path']						=	$_GESTOR['ROOT_PATH'].'plugins/';

// ===== Definição dos caminhos em disco padrões.

$_GESTOR['bibliotecas-path']					=	$_GESTOR['ROOT_PATH'].'bibliotecas/';
$_GESTOR['modulos-path']						=	$_GESTOR['ROOT_PATH'].'modulos/';
$_GESTOR['controladores-path']					=	$_GESTOR['ROOT_PATH'].'controladores/';
$_GESTOR['assets-path']							=	$_GESTOR['ROOT_PATH'].'assets/';
$_GESTOR['contents-path']						=	$_GESTOR['ROOT_PATH'].'contents/';
$_GESTOR['logs-path']							=	$_GESTOR['ROOT_PATH'].'logs/';

// ===== Carrega as configurações de ambiente do .env =====

$_GESTOR['url-raiz'] = $_ENV['URL_RAIZ'] ?? '/';
$_GESTOR['url-raiz-sem-lang'] = $_GESTOR['url-raiz'];
$_GESTOR['development-env'] = filter_var($_ENV['DEVELOPMENT_ENV'] ?? false, FILTER_VALIDATE_BOOLEAN);

// ===== Definições de variáveis padrões do sistema que dependem de host 

$_GESTOR['url-full']							=	'//'.$_SERVER['SERVER_NAME'].$_GESTOR['url-raiz'];
$_GESTOR['url-full-http']						=	'https://'.$_SERVER['SERVER_NAME'].$_GESTOR['url-raiz'];

// ===== Definições dos caminhos relativos.

$_GESTOR['modulos-bibliotecas']					=	'bibliotecas/'; // Caminho relativo a raiz dos módulos bibliotecas do gestor
$_GESTOR['pagina#contato-url']					=	'contato/'; // Página de contatos relativo a raiz do sistema.

// ===== Definição e inclusão de todas as bibliotecas necessárias para o funcionamento do gestor

$_GESTOR['bibliotecas-dados'] = Array(
	'banco' => Array('banco.php'),
	'gestor' => Array('gestor.php'),
	'modelo' => Array('modelo.php'),
	'hooks' => Array('hooks.php'),
	'interface' => Array('interface.php'),
	'html' => Array('html.php'),
	'usuario' => Array('usuario.php'),
	'comunicacao' => Array('comunicacao.php'),
	'arquivo' => Array('arquivo.php'),
	'ftp' => Array('ftp.php'),
	'api-cliente' => Array('api-cliente.php'),
	'pagina' => Array('pagina.php'),
	'formato' => Array('formato.php'),
	'configuracao' => Array('configuracao.php'),
	'host' => Array('host.php'),
	'paypal' => Array('paypal.php'),
	'stripe' => Array('stripe.php'),
	'variaveis' => Array('variaveis.php'),
	'log' => Array('log.php'),
	'autenticacao' => Array('autenticacao.php'),
	'pdf' => Array('pdf.php'),
	'cpanel' => Array('cpanel.php'),
	'ip' => Array('ip.php'),
	'widgets' => Array('widgets.php'),
	'formulario' => Array('formulario.php'),
	'geral' => Array('geral.php'),
	'plugins-consts' => Array('plugins-consts.php'),
	'plugins-installer' => Array('plugins-installer.php'),
	'ia' => Array('ia.php'),
    'html-editor' => Array('html-editor.php'),
    'oauth2' => Array('oauth2.php'),
    '2fa' => Array('2fa.php'),
    'jwt' => Array('jwt.php'),
    'oauth' => Array('oauth.php'),
    'seguranca' => Array('seguranca.php'),
    'interface-v2' => Array('interface-v2.php'),
    'banco-v2' => Array('banco-v2.php'),
    'modulo-distribuido' => Array('modulo-distribuido.php'),
);

// Bibliotecas principais do sistema

$_GESTOR['bibliotecas']							=	Array('banco','gestor','modelo','hooks');

if(isset($_GESTOR['bibliotecas']))
foreach($_GESTOR['bibliotecas'] as $_biblioteca){
    if(isset($_GESTOR['bibliotecas-dados']) && isset($_GESTOR['bibliotecas-dados'][$_biblioteca])){
        $_caminhos = $_GESTOR['bibliotecas-dados'][$_biblioteca];

        if($_caminhos)
        foreach($_caminhos as $_caminho){
            require_once($_GESTOR['modulos-bibliotecas'].$_caminho);
        }
    }
}

// Adicionar o config do projeto caso exista, para adcionar configurações específicas do projeto.
if(isset($_GESTOR['ROOT_PATH']) && file_exists($_GESTOR['ROOT_PATH'].'config-project.php')){
	require_once($_GESTOR['ROOT_PATH'].'config-project.php');
}

?>
