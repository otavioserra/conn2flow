<?php

// ===== Força charset UTF-8 em todo o sistema

ini_set('default_charset', 'UTF-8');
if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

// =========================== Configuração Inicial

require_once(__DIR__ . '/config.php');

// =========================== Funções de Montagem da Página

function gestor_pagina_menu($params = false){
	global $_GESTOR;
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// ===== 
	
	if(!isset($_GESTOR['usuario-token-id'])){
		return '';
	}
	
	// ===== Layout do menu
	
	$menu = gestor_componente(Array(
		'id' => 'menu-principal-sistema',
	));
	
	$cel_nome = 'icon'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'icon-2'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'item'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'categoria'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'simples'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'itemContCel'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	$cel_nome = 'conteiner'; $cel[$cel_nome] = modelo_tag_val($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->'); $menu = modelo_tag_in($menu,'<!-- '.$cel_nome.' < -->','<!-- '.$cel_nome.' > -->','<!-- '.$cel_nome.' -->');
	
	// ===== Verificar quais módulos o usuário pode acessar
	
	$usuario = gestor_usuario();
	
	// ===== Verificar se o usuário é filho de um host ou não.
	
	if(existe($usuario['id_hosts'])){
		// ===== Verificar se o usuário tem um perfil de gestor ativo.
		
		if(existe($usuario['gestor_perfil'])){
			$gestor_perfil = $usuario['gestor_perfil'];
			
			// ===== Verificar se o módulo alvo tem permissão no perfil.
			
			$usuarios_perfis_modulos = banco_select_name
			(
				banco_campos_virgulas(Array(
					'modulo',
				))
				,
				"usuarios_gestores_perfis_modulos",
				"WHERE perfil='".$gestor_perfil."'"
				." AND id_hosts='".$usuario['id_hosts']."'"
			);
		} else {
			// ===== Pegar o usuário pai do usuário em questão.
			
			$hosts = banco_select(Array(
				'unico' => true,
				'tabela' => 'hosts',
				'campos' => Array(
					'id_usuarios',
				),
				'extra' => 
					"WHERE id_hosts='".$usuario['id_hosts']."'"
			));
			
			// ===== Pegar o identificador do perfil do pai do usuário.
			
			$usuarios = banco_select(Array(
				'unico' => true,
				'tabela' => 'usuarios',
				'campos' => Array(
					'id_usuarios_perfis',
				),
				'extra' => 
					"WHERE id_usuarios='".$hosts['id_usuarios']."'"
			));
			
			// ===== Pegar o perfil do usuário.
			
			$usuarios_perfis = banco_select(Array(
				'unico' => true,
				'tabela' => 'usuarios_perfis',
				'campos' => Array(
					'id',
				),
				'extra' => 
					"WHERE id_usuarios_perfis='".$usuarios['id_usuarios_perfis']."'"
			));
			
			$perfil = $usuarios_perfis['id'];
			
			// ===== Verificar se o módulo alvo tem permissão no perfil.
			
			$usuarios_perfis_modulos = banco_select_name
			(
				banco_campos_virgulas(Array(
					'modulo',
				))
				,
				"usuarios_perfis_modulos",
				"WHERE perfil='".$perfil."'"
			);
		}
	} else {
		// ===== Pegar o perfil do usuário.
		
		$usuarios_perfis = banco_select(Array(
			'unico' => true,
			'tabela' => 'usuarios_perfis',
			'campos' => Array(
				'id',
			),
			'extra' => 
				"WHERE id_usuarios_perfis='".$usuario['id_usuarios_perfis']."'"
		));
		
		$perfil = $usuarios_perfis['id'];
		
		// ===== Verificar se o módulo alvo tem permissão no perfil.
		
		$usuarios_perfis_modulos = banco_select_name
		(
			banco_campos_virgulas(Array(
				'modulo',
			))
			,
			"usuarios_perfis_modulos",
			"WHERE perfil='".$perfil."'"
		);
	}
	
	// ===== Pegar dados de páginas e módulos
	
	$paginas = banco_select_name
	(
		banco_campos_virgulas(Array(
			'modulo',
			'caminho',
		))
		,
		"paginas",
		"WHERE raiz IS NOT NULL"
		." AND status='A'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
	);
	
	$modulos = banco_select_name
	(
		banco_campos_virgulas(Array(
			'id_modulos',
			'modulo_grupo_id', // campo textual
			'id',
			'nome',
			'icone',
			'icone2',
			'titulo',
			'plugin',
		))
		,
		"modulos",
		"WHERE nao_menu_principal IS NULL"
		." AND status='A'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
		." ORDER BY nome ASC"
	);

	$modulos_grupos = banco_select(Array(
		'tabela' => 'modulos_grupos',
		'campos' => Array(
			'id', // campo textual
			'nome',
			'ordemMenu',
		),
		'extra' => 
			"WHERE language='".$_GESTOR['linguagem-codigo']."' ORDER BY ordemMenu ASC, nome ASC"
	));
	
	// ===== Verifica se o usuário é admin do host para mostrar no menu o Host Configurações ou não.
	
	$host_verificacao = gestor_sessao_variavel('host-verificacao-'.$_GESTOR['usuario-id']);
	
	$privilegios_admin = false;
	if(isset($host_verificacao['privilegios_admin'])){
		$privilegios_admin = true;
	}
	
	// ===== Verificar se o usuário faz parte de um host. Se sim, baixar os plugins do host.
	
	if(isset($_GESTOR['host-id'])){
		$hosts_plugins = banco_select(Array(
			'tabela' => 'hosts_plugins',
			'campos' => Array(
				'plugin',
				'habilitado',
			),
			'extra' => 
				"WHERE id_hosts='".$_GESTOR['host-id']."'"
		));
	}
	
	// ===== Montar o menu conforme permissão
	
	$dashboard = '';
	$grupos = Array();
	
	if($modulos)
	foreach($modulos as $modulo){
		// ===== Se o módulo tiver permissão de acesso incluir
		$modulo_perfil = false;
		
		if($modulo['id'] == 'dashboard'){
			$modulo_perfil = true;
		} else {
			if($usuarios_perfis_modulos)
			foreach($usuarios_perfis_modulos as $upm){
				if($upm['modulo'] == $modulo['id']){
					$modulo_perfil = true;
					break;
				}
			}
		}
		
		if(!$modulo_perfil){
			continue;
		}
		
		// ===== Verificar se o usuário faz parte de um host. Se sim, verificar os plugins do usuario e ver se esse faz parte de um plugin habilitado.
		
		if(isset($_GESTOR['host-id'])){
			if($modulo['plugin']){
				$habilitado = false;
				
				if($hosts_plugins)
				foreach($hosts_plugins as $hosts_plugin){
					if(
						$hosts_plugin['plugin'] == $modulo['plugin'] &&
						$hosts_plugin['habilitado']
					){
						$habilitado = true;
					}
				}
				
				if(!$habilitado){
					continue;
				}
			}
		}
		
		// ===== Se for o host configurações e não tiver privilégio, não mostrar no menu.
		
		if($modulo['id'] == 'host-configuracao' && !$privilegios_admin && isset($_GESTOR['host-id'])){
			continue;
		}
		
		// ===== Montar ítem do menu do módulo
		
		$cel_nome = 'item';
		$cel_aux = $cel[$cel_nome];
		
		$cel_aux = modelo_var_troca($cel_aux,"#nome#",(existe($modulo['titulo']) ? $modulo['titulo'] : $modulo['nome']));
		$cel_aux = modelo_var_troca($cel_aux,"#class#",(isset($_GESTOR['modulo-id']) && $modulo['id'] == $_GESTOR['modulo-id'] ? ' active':''));
		
		if($modulo['icone2']){
			$cel_nome_icon = 'icon-2';
			$cel_icon = $cel[$cel_nome_icon];
			
			$cel_icon = modelo_var_troca($cel_icon,"#icon-2#",($modulo['icone2'] ? $modulo['icone2'] : 'question circle outline'));
		} else {
			$cel_nome_icon = 'icon';
			$cel_icon = $cel[$cel_nome_icon];
		}
		
		$cel_icon = modelo_var_troca($cel_icon,"#icon#",($modulo['icone'] ? $modulo['icone'] : 'question circle outline'));
		
		$cel_aux = modelo_var_troca($cel_aux,"<!-- icon -->",$cel_icon);
		
		// ===== Se existe a página padrão, senão o link será para a raiz.
		
		$pagina_found = false;
		
		if($paginas)
		foreach($paginas as $pagina){
			if($modulo['id'] == $pagina['modulo']){
				$cel_aux = modelo_var_troca_tudo($cel_aux,"#link#",$_GESTOR['url-raiz'].$pagina['caminho']);
				$pagina_found = true;
				break;
			}
		}
		
		if(!$pagina_found){
			continue;
		}
		
		// ===== Caso seja dashboard incluir depois primeiro, senão colocar em ordem alfabética
		
		if($modulo['id'] == 'dashboard'){
			$dashboard = $cel_aux;
		} else {
			// ===== Incluir o item no módulo grupo.
			
			if(!isset($grupos[$modulo['modulo_grupo_id']])){
				$achouGrupo = false;
				$nomeGrupo = '';
				if($modulos_grupos)
				foreach($modulos_grupos as $modulo_grupo){
					if($modulo_grupo['id'] == $modulo['modulo_grupo_id']){
						$achouGrupo = true;
						$nomeGrupo = $modulo_grupo['nome'];
						break;
					}
				}
                
				if($achouGrupo){
					$grupos[$modulo['modulo_grupo_id']] = $cel['categoria'];
                    
					$grupos[$modulo['modulo_grupo_id']] = modelo_var_troca($grupos[$modulo['modulo_grupo_id']],'#categoria-nome#',$nomeGrupo);
				} else {
					continue;
				}
			}
            
			$grupos[$modulo['modulo_grupo_id']] = modelo_var_in($grupos[$modulo['modulo_grupo_id']],'<!-- itemMenu -->',$cel_aux);
		}
	}
	
	// ===== Montar o conteiner do menu.
	
	$menuConteiner = $cel['conteiner'];
	
	// ===== Incluir dashboard no conteiner
	
	$cel_simples = $cel['simples'];
	$cel_simples = modelo_var_troca($cel_simples,"<!-- itemMenu -->",$dashboard);
	
	$cel_conteiner = $cel['itemContCel'];
	$cel_conteiner = modelo_var_troca($cel_conteiner,"#itemCont#",$cel_simples);
	
	$menuConteiner = modelo_var_in($menuConteiner,'<!-- itemContCel -->',$cel_conteiner);
	
	// ===== Incluir grupos no conteiner.
	
	$menuConteinerSemPrioridade = '';
	
	if($modulos_grupos)
	foreach($modulos_grupos as $modulo_grupo){
		if(isset($grupos[$modulo_grupo['id']])){
			$cel_conteiner = $cel['itemContCel'];
			$cel_conteiner = modelo_var_troca($cel_conteiner,"#itemCont#",$grupos[$modulo_grupo['id']]);
            
			if($modulo_grupo['ordemMenu']){
				$menuConteiner = modelo_var_in($menuConteiner,'<!-- itemContCel -->',$cel_conteiner);
			} else {
				$menuConteinerSemPrioridade .= $cel_conteiner;
			}
		}
	}
	
	if(existe($menuConteinerSemPrioridade)){
		$menuConteiner = modelo_var_in($menuConteiner,'<!-- itemContCel -->',$menuConteinerSemPrioridade);
	}
	
	// ===== Incluir sair no conteiner
	
	$cel_nome = 'item';
	$cel_aux = $cel[$cel_nome];
	
	$cel_aux = modelo_var_troca($cel_aux,"#nome#",gestor_variaveis(Array('id' => 'logout-label','modulo' => 'dashboard')));
	$cel_aux = modelo_var_troca($cel_aux,"#class#",'');
	
	$cel_nome_icon = 'icon';
	$cel_icon = $cel[$cel_nome_icon];
	
	$cel_icon = modelo_var_troca($cel_icon,"#icon#",'sign out alternate');
	
	$cel_aux = modelo_var_troca($cel_aux,"<!-- icon -->",$cel_icon);
	
	$cel_aux = modelo_var_troca_tudo($cel_aux,"#link#",$_GESTOR['url-raiz'].'signout/');
	
	// ===== Incluir sair no conteiner
	
	$cel_simples = $cel['simples'];
	$cel_simples = modelo_var_troca($cel_simples,"<!-- itemMenu -->",$cel_aux);
	
	$cel_conteiner = $cel['itemContCel'];
	$cel_conteiner = modelo_var_troca($cel_conteiner,"#itemCont#",$cel_simples);
	
	$menuConteiner = modelo_var_in($menuConteiner,'<!-- itemContCel -->',$cel_conteiner);
	
	// ===== Remover celulas inúteis

	$menuConteiner = modelo_var_troca($menuConteiner,'<!-- itemContCel -->','');
	$menuConteiner = modelo_var_troca($menuConteiner,'<!-- itemMenu -->','');

	// ===== JavaScript do painel administrativo (BATCH-103): filtro do menu.
	//
	// A tag acompanha o HTML do menu em vez de entrar na fila de assets (`gestor_pagina_css_incluir`
	// / `gestor_pagina_javascript_incluir`): esta função é chamada por `gestor_pagina_variaveis()`,
	// que roda DEPOIS de `gestor_pagina_extra_head_e_javascript()` — quando o `<!-- pagina#js -->` já
	// foi resolvido, qualquer item enfileirado ali fica órfão e o script nunca chega à página.
	// Como `admin.js` só interessa a quem vê o menu, carregá-lo junto dele mantém o custo restrito
	// ao painel e dispensa um gate extra no pipeline.

	$menuConteiner .= "\n".'<script src="'.$_GESTOR['url-raiz'].'global/admin.js?v='.$_GESTOR['versao'].'"></script>';

	// ===== Retornar o conteiner.

	return $menuConteiner;
}

function gestor_pagina_variaveis_modulos($params = false){
	global $_GESTOR;
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// modulosExtra - Conjunto - Opcional - Conjunto de móulos extras para ler variáveis globais quando necessário.
	
	// ===== 
	
	if(isset($modulosExtra)){
		foreach($modulosExtra as $modulo){
			$_GESTOR['paginas-variaveis'][$modulo] = true;
		}
	}
	
}

function gestor_pagina_layout($params = false){
	global $_GESTOR;
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// layout - String - Obrigatório - Layout principal onde a página será incluída.
	
	// ===== 
	
	$open = $_GESTOR['variavel-global']['open'];
	$close = $_GESTOR['variavel-global']['close'];
	
	// ===== Variáveis do layout
	
	$layout = modelo_var_troca($layout,'<!-- pagina#titulo -->',($_GESTOR['pagina#titulo'] ? '<title>'.(isset($_GESTOR['pagina#titulo-extra']) ? $_GESTOR['pagina#titulo-extra'] : '').$_GESTOR['pagina#titulo'].'</title>' : ''));
	
	// ===== Página fundir layout + página

	$conteudo = $_GESTOR['pagina'];

	// Para editores logados (Dashboard Site Toolbar / Meta 3), envolver o conteúdo da página
	// num wrapper identificável — alvo da edição visual in-place (swap p/ render com caixas).
	if(gestor_dashboard_toolbar_ativo()){
		$conteudo = '<div id="c2f-page-content" data-c2f-content>'.$conteudo.'</div>';
	}

	$_GESTOR['pagina'] = modelo_var_troca($layout,$open.'pagina#corpo'.$close,$conteudo);

	// Para edição de LAYOUT in-place (BATCH-075/Meta 3 ponto 4), envolver o CORPO do layout num
	// #c2f-layout-root (que contém o #c2f-page-content). O iframe da toolbar é injetado depois,
	// após <body>, FORA deste wrapper. Só o body do layout é editável (o <head> não).
	if(gestor_dashboard_toolbar_ativo()){
		$layoutId = isset($_GESTOR['layout#id']) ? (string)$_GESTOR['layout#id'] : '';
		$_GESTOR['pagina'] = preg_replace_callback('/(<body\b[^>]*>)([\s\S]*?)(<\/body>)/i', function($m) use ($layoutId){
			return $m[1].'<div id="c2f-layout-root" data-c2f-layout data-layout-id="'.htmlspecialchars($layoutId, ENT_QUOTES, 'UTF-8').'">'.$m[2].'</div>'.$m[3];
		}, $_GESTOR['pagina'], 1);
	}
}

function gestor_pagina_widgets(){
	global $_GESTOR;

	// ===== Variáveis globais de página

	$open = $_GESTOR['variavel-global']['open'];
	$close = $_GESTOR['variavel-global']['close'];

	// ===== Widgets Envelopados (Wrappers) - BATCH-008
	// Sintaxe:
	//   <!-- widgets#MODULO_ID->FUNCAO(JSON_PARAMS) < -->
	//     ...HTML mockup estático (template de preview visual para designers)...
	//   <!-- widgets#MODULO_ID->FUNCAO(JSON_PARAMS) > -->
	// O conteúdo interno é capturado e repassado ao callback do widget pela
	// chave 'html' do array de parâmetros, junto com o 'id'.

	// No modo de edição do Live Editor (Dashboard Site Toolbar) PRESERVAMOS os comentários
	// `<!-- widgets#SIG < --> … <!-- widgets#SIG > -->` ao redor do render (trocamos apenas o
	// conteúdo interno = mockup → widget renderizado). Assim o DOM vivo carrega a fronteira EXATA
	// de cada widget, e o live editor delimita/marca cada um sem heurística de alinhamento
	// (resolve widgets duplicados/consecutivos e o mapeamento no contêiner pai). Para o visitante
	// normal, os marcadores continuam sendo removidos (comportamento original).
	$editMode = function_exists('gestor_dashboard_toolbar_ativo') ? gestor_dashboard_toolbar_ativo() : false;

	$wrapperPattern = '/<!--\s*widgets#(.+?)\s*<\s*-->([\s\S]*?)<!--\s*widgets#\s*\1\s*>\s*-->/i';

	if(preg_match_all($wrapperPattern, $_GESTOR['pagina'], $matchesWrapper, PREG_SET_ORDER)){
		// ===== Incluir a biblioteca dos widgets e disparar a função de iniciação dos mesmos.
		gestor_incluir_biblioteca('widgets');

		foreach($matchesWrapper as $wrapperMatch){
			$widgetId    = $wrapperMatch[1];
			$widgetHtml  = $wrapperMatch[2];
			$widgetBlock = $wrapperMatch[0];

			$widget = widgets_get(Array(
				'id'   => $widgetId,
				'html' => $widgetHtml,
			));

			if(existe($widget)){
				$substituicao = $editMode
					? ('<!-- widgets#'.$widgetId.' < -->'.$widget.'<!-- widgets#'.$widgetId.' > -->')
					: $widget;
				$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$widgetBlock,$substituicao);
			}
		}
	}

	// ===== Compatibilidade retrógrada: marcador inline @[[widgets#...]]@
	// O padrão procurado é algo como
	//   @[[widgets#MODULO_ID->FUNCAO(JSON_PARAMS)]]@
	// ou apenas @[[widgets#meu-widget]]@ para compatibilidade.
	// Tudo que estiver entre "widgets#" e o fechamento será passado
	// diretamente para widgets_get() que conhece o formato.

	$pattern = "/".preg_quote($open)."widgets#(.+?)".preg_quote($close)."/i";
	preg_match_all($pattern, $_GESTOR['pagina'], $matchesWidgets);

	if($matchesWidgets){
		// ===== Incluir a biblioteca dos widgets e disparar a função de iniciação dos mesmos.
		gestor_incluir_biblioteca('widgets');

		// ===== Varrer todos os matchs e trocar os marcadores por seus widgets.
		foreach($matchesWidgets[1] as $match){
			// $match contém a string completa depois de "widgets#" –
			// pode ser "modulo->func({...})" ou um nome simples.
			$widget = widgets_get(Array(
				'id' => $match,
			));

			if(existe($widget)){
				$substituicao = $editMode
					? ('<!-- widgets#'.$match.' < -->'.$widget.'<!-- widgets#'.$match.' > -->')
					: $widget;
				$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open."widgets#".$match.$close,$substituicao);
			}
		}
	}
}

/**
 * req-096 (BATCH-096): inclui os assets do motor PDF.js somente quando a página final contém o
 * contêiner `.conn2flow-pdfjs` (gerado pelo Editor HTML). Deve rodar DEPOIS de gestor_pagina_widgets()
 * — o contêiner pode vir do HTML de um widget — e ANTES de gestor_pagina_extra_head_e_javascript(),
 * que serializa as inclusões na página.
 */
function gestor_pagina_pdf_viewer(){
	global $_GESTOR;

	if(!isset($_GESTOR['pagina'])) return;
	if(!function_exists('gestor_pdf_viewer_detectar')) return;
	if(!gestor_pdf_viewer_detectar($_GESTOR['pagina'])) return;

	$assets = gestor_pdf_viewer_assets($_GESTOR['url-raiz'],$_GESTOR['versao']);

	foreach($assets as $asset){
		gestor_pagina_javascript_incluir($asset);
	}
}

function gestor_pagina_widgets_ajax(){
	global $_GESTOR;

	// ===== Se receber uma requisição AJAX para widgets, disparar os controladores AJAX dos widgets e retornar o resultado.
	if(!isset($_GESTOR['ajaxWidgets'])) return;

	$widgetsAjaxList = array_filter(explode('<#;>', $_GESTOR['ajaxWidgets']));
	
	if($widgetsAjaxList){
		// ===== Incluir a biblioteca dos widgets e disparar a função de iniciação dos mesmos.
		gestor_incluir_biblioteca('widgets');
		
		// ===== Varrer todos os matchs e trocar os marcadores por seus widgets.
		foreach($widgetsAjaxList as $match){
			// inclui o widget e dispara a função correspondente, porém se houver retorno é porque teve erro.
			$widget = widgets_get(Array(
				'id' => $match,
			));
			
			if(!empty($widget)){
				gestor_roteador_erro(Array(
					'codigo' => 500,
					'ajax' => $_GESTOR['ajax'],
					'mensagem' => 'Widget AJAX error: ['.$match.'] - Return: '.$widget,
				));
			}
		}
	}
}

function gestor_pagina_variaveis(){
	global $_GESTOR;

	// ===== Variáveis globais de página
	
	$open = $_GESTOR['variavel-global']['open'];
	$close = $_GESTOR['variavel-global']['close'];
	
	// ===== Página variáveis operações
	
	$caminho = (isset($_GESTOR['caminho-total']) ? $_GESTOR['caminho-total'] : '');
	$caminho = rtrim($caminho,'/').'/';
	
	// ===== Página variáveis trocar
	
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#menu'.$close,gestor_pagina_menu());
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#url-raiz'.$close,$_GESTOR['url-raiz']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#url-full-http'.$close,$_GESTOR['url-full-http']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#url-caminho'.$close,$caminho);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#titulo'.$close,$_GESTOR['pagina#titulo']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#contato-url'.$close,$_GESTOR['pagina#contato-url']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'gestor#versao'.$close,$_GESTOR['versao']);

	// ===== Projeto variáveis trocar

	if(isset($_GESTOR['project-version'])) $_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'project#version'.$close,$_GESTOR['project-version']);
	
	// ===== Dados do usuário
	
	$usuario = gestor_usuario();
	
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'usuario#nome'.$close,$usuario['nome']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'usuario#slug'.$close,$usuario['id']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'usuario#perfil-nome'.$close,$usuario['perfil_nome']);
	$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'usuario#perfil-slug'.$close,$usuario['perfil_slug']);
	
	if(isset($_GESTOR['modulo-id'])) $_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#modulo-id'.$close,$_GESTOR['modulo-id']);
	if(isset($_GESTOR['modulo-registro-id'])) $_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.'pagina#registro-id'.$close,$_GESTOR['modulo-registro-id']);
	

	$variaveisEncontradas = Array();

	// ===== Variáveis globais.

	$pattern = "/".preg_quote($open)."(.+?)".preg_quote($close)."/i";
	preg_match_all($pattern, $_GESTOR['pagina'], $matches);
	
	if($matches)
	foreach($matches[1] as $match){
		// ===== Pegar o valor da variável
		$valor = gestor_variaveis_globais(Array('id' => $match));

		if(isset($valor)){
			$variaveisEncontradas[] = $match;
			$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.$match.$close,existe($valor) ? $valor : '');
		}
	}

	// ===== Variáveis do módulo atual.

	if(isset($_GESTOR['modulo-id'])){
		$pattern = "/".preg_quote($open)."(.+?)".preg_quote($close)."/i";
		preg_match_all($pattern, $_GESTOR['pagina'], $matches);
		
		if($matches)
		foreach($matches[1] as $match){
			if(in_array($match,$variaveisEncontradas)) continue;
			$variaveisEncontradas[] = $match;
			// ===== Pegar o valor da variável
			$valor = gestor_variaveis(Array('modulo' => $_GESTOR['modulo-id'],'id' => $match));
			
			if(existe($valor)){
				$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.$match.$close,$valor);
			}
		}
	}
	
	// ===== Módulos extras que devem ser lidos e colocados as variáveis nas páginas.
	
	if(isset($_GESTOR['paginas-variaveis'])){
		$modulosExtra = $_GESTOR['paginas-variaveis'];
		
		foreach($modulosExtra as $modulo => $valor){
			$pattern = "/".preg_quote($open)."(.+?)".preg_quote($close)."/i";
			preg_match_all($pattern, $_GESTOR['pagina'], $matches);
			
			if($matches)
			foreach($matches[1] as $match){
				if(in_array($match,$variaveisEncontradas)) continue;
				$variaveisEncontradas[] = $match;
				// ===== Pegar o valor da variável
				$valor = gestor_variaveis(Array('modulo' => $modulo,'id' => $match));
				
				if(existe($valor)){
					$_GESTOR['pagina'] = modelo_var_troca_tudo($_GESTOR['pagina'],$open.$match.$close,$valor);
				}
			}
		}
	}
}

function gestor_pagina_css(){
	global $_GESTOR;

	// ===== Inclusão de bibliotecas CSS Fomantic-UI / Tailwind CSS

	$layout_framework = $_GESTOR['layout#framework_css'] ?? null;
	$pagina_framework = $_GESTOR['pagina#framework_css'] ?? null;

	$fomantic_ui_included = false;
	if ($layout_framework == 'fomantic-ui' || $pagina_framework == 'fomantic-ui' || (empty($layout_framework) && empty($pagina_framework))) {
		$fomantic_ui_included = true;
	}

	$tailwindcss_included = false;
	if ($layout_framework == 'tailwindcss' || $pagina_framework == 'tailwindcss') {
		$tailwindcss_included = true;
	}
	
	$css_global = '';

	$css_padrao = Array();
	if($fomantic_ui_included) $css_padrao[] = '<link rel="stylesheet" type="text/css" media="all" href="https://cdn.jsdelivr.net/npm/fomantic-ui@2.9.4/dist/semantic.min.css" />';
	if($tailwindcss_included) $css_padrao[] = '<link rel="stylesheet" type="text/css" media="all" href="'.$_GESTOR['url-raiz'].'tailwindcss/system-output.css?v='.$_GESTOR['versao'].'" />';

	if(!isset($_GESTOR['css-compiled'])) $_GESTOR['css-compiled'] = Array();
	if(!isset($_GESTOR['css'])) $_GESTOR['css'] = Array();
	if(!isset($_GESTOR['css-fim'])) $_GESTOR['css-fim'] = Array();

	// CSS do projeto regras de negócio, se existir.

	if(!isset($_GESTOR['project-css'])) $_GESTOR['project-css'] = Array();

	if(isset($_GESTOR['layout#id']) && isset($_GESTOR['project-css-layouts-remove']) && in_array($_GESTOR['layout#id'], $_GESTOR['project-css-layouts-remove'])){
		// Não incluir CSS do projeto, pois o layout atual está na lista de layouts para não incluir o CSS do projeto.
		$_GESTOR['project-css'] = Array();
	} else if(isset($_GESTOR['layout#id']) && isset($_GESTOR['project-css-layouts-include']) && in_array($_GESTOR['layout#id'], $_GESTOR['project-css-layouts-include'])){
		// Incluir somente os CSS's do projeto relacionados a este layout, pois o layout atual está na lista de layouts para incluir somente os CSS's do projeto relacionados a este layout.
		$_GESTOR['project-css'] = $_GESTOR['project-css-layouts-include'][$_GESTOR['layout#id']];
	}

	// Incluir os CSS's seguindo a ordem: CSS padrão, CSS do projeto, CSS compilado, CSS normal e CSS fim.
	$csss = array_merge($css_padrao,$_GESTOR['project-css'],$_GESTOR['css-compiled'],$_GESTOR['css'],$_GESTOR['css-fim']);

	if($csss)
	foreach($csss as $css){
		if(existe($css_global)){
			$css_global .= "	" . $css . "\n";
		} else {
			$css_global .= $css . "\n";
		}
	}
	
	$_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'],'<!-- pagina#css -->',$css_global);
}

function gestor_pagina_css_incluir($css = false){
	global $_GESTOR;
	
	if(!$css){
		$_GESTOR['css-fim'][] = $css = '<link rel="stylesheet" type="text/css" media="all" href="'.$_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/css.css?v='.$_GESTOR['modulo#'.$_GESTOR['modulo-id']]['versao'].'">';
		
		// ===== Verifica se já foi adicionado este css, se sim, remover o último que foi adicionado.
		if(!isset($_GESTOR['css-fim-adicionados'])){
			$_GESTOR['css-fim-adicionados'] = Array();
		} else {
			if(in_array($css,$_GESTOR['css-fim-adicionados'])){
				array_pop($_GESTOR['css-fim']);
				return;
			}
		}
	
		$_GESTOR['css-fim-adicionados'][] = $css;
	} else {
		$_GESTOR['javascript-fim'][] = $css;
		
		// ===== Verifica se já foi adicionado este css, se sim, remover o último que foi adicionado.
		if(!isset($_GESTOR['javascript-fim-adicionados'])){
			$_GESTOR['javascript-fim-adicionados'] = Array();
		} else {
			if(in_array($css,$_GESTOR['javascript-fim-adicionados'])){
				array_pop($_GESTOR['javascript-fim']);
				return;
			}
		}
	
		$_GESTOR['javascript-fim-adicionados'][] = $css;
	}
}

function gestor_pagina_extra_head_e_javascript(){
	global $_GESTOR;
	global $_CONFIG;

	// ===== Inclusão de bibliotecas CSS Fomantic-UI

	$layout_framework = $_GESTOR['layout#framework_css'] ?? null;
	$pagina_framework = $_GESTOR['pagina#framework_css'] ?? null;

	$fomantic_ui_included = false;
	if ($layout_framework == 'fomantic-ui' || $pagina_framework == 'fomantic-ui' || (empty($layout_framework) && empty($pagina_framework))) {
		$fomantic_ui_included = true;
	}
	
	// ===== Inclusão de bibliotecas javascript
	
	$js_global_includes = '';
	$js_padrao[] = '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>'; // jQuery

	if($fomantic_ui_included) $js_padrao[] = '<script src="https://cdn.jsdelivr.net/npm/fomantic-ui@2.9.4/dist/semantic.min.js"></script>'; // Semantic-UI

	$js_padrao[] = '<script src="'.$_GESTOR['url-raiz'].'global/global.js?v='.$_GESTOR['versao'].'"></script>'; // Global JS
	
	if(!isset($_GESTOR['html-extra-head'])) $_GESTOR['html-extra-head'] = Array();
	if(!isset($_GESTOR['javascript'])) $_GESTOR['javascript'] = Array();
	if(!isset($_GESTOR['javascript-fim'])) $_GESTOR['javascript-fim'] = Array();

	// Javascript do projeto regras de negócio, se existir.

	if(!isset($_GESTOR['project-javascript'])) $_GESTOR['project-javascript'] = Array();

	// Token do painel para formulários e clientes AJAX autenticados por cookie.
	if(isset($_COOKIE[$_CONFIG['cookie-authname']])){
		gestor_incluir_biblioteca('seguranca');
		$csrfToken = gestor_csrf_token();
		$_GESTOR['html-extra-head'][] = '<meta name="csrf-token" content="'.htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8').'">';
		if(!isset($_GESTOR['javascript-vars'])) $_GESTOR['javascript-vars'] = Array();
		$_GESTOR['javascript-vars']['csrfToken'] = $csrfToken;
	}
	
	if(isset($_GESTOR['layout#id']) && isset($_GESTOR['project-javascript-layouts-remove']) && in_array($_GESTOR['layout#id'], $_GESTOR['project-javascript-layouts-remove'])){
		// Não incluir javascript do projeto, pois o layout atual está na lista de layouts para não incluir o javascript do projeto.
		$_GESTOR['project-javascript'] = Array();
	} else if(isset($_GESTOR['layout#id']) && isset($_GESTOR['project-javascript-layouts-include']) && in_array($_GESTOR['layout#id'], $_GESTOR['project-javascript-layouts-include'])){
		// Incluir somente os javascript's do projeto relacionados a este layout, pois o layout atual está na lista de layouts para incluir somente os javascript's do projeto relacionados a este layout.
		$_GESTOR['project-javascript'] = $_GESTOR['project-javascript-layouts-include'][$_GESTOR['layout#id']];
	}
	
	// Incluir os javascript's seguindo a ordem: javascript padrão, javascript extra head, javascript normal, javascript fim e javascript do projeto.
	$jss = array_merge($js_padrao,$_GESTOR['html-extra-head'],$_GESTOR['javascript'],$_GESTOR['javascript-fim'],$_GESTOR['project-javascript']);
	
	if($jss)
	foreach($jss as $js){
		$js_global_includes .= "	" . $js . "\n";
	}
	
	// ===== Inclusão de variáveis javascript
	
	$caminho = (isset($_GESTOR['caminho-total']) ? $_GESTOR['caminho-total'] : '');
	$caminho = rtrim($caminho,'/').'/';
	
	$variaveis_js = Array(
		'versao' => $_GESTOR['versao'],
		'raiz' => $_GESTOR['url-raiz'],
		'raizSemLang' => $_GESTOR['url-raiz-sem-lang'],
		'language' => $_GESTOR['linguagem-codigo'],
		'pageLanguages' => $_GESTOR['page-languages'],
		'languageSystem' => $_GESTOR['linguagem-padrao'],
		'languageCookie' => $_CONFIG['cookie-language'],
		'moduloId' => (isset($_GESTOR['modulo-id']) ? $_GESTOR['modulo-id'] : false ),
		'moduloVersao' => (isset($_GESTOR['modulo-versao']) ? $_GESTOR['modulo-versao'] : false ),
		'moduloOpcao' => (isset($_GESTOR['opcao']) ? $_GESTOR['opcao'] : false ),
		'widgetsToAjax' => (isset($_GESTOR['widgetsToAjax']) ? $_GESTOR['widgetsToAjax'] : null ),
		'moduloCaminho' => $caminho,
	);
	
	if($_GESTOR['paginaIframe']) $variaveis_js['paginaIframe'] = true;
	
	$js_global_vars = '<script>
		var gestor = '.json_encode((isset($_GESTOR['javascript-vars']) ? array_merge($variaveis_js, $_GESTOR['javascript-vars']):$variaveis_js), JSON_UNESCAPED_UNICODE).';
	</script>'."\n";
	
	// ===== Inclusão na página
	
	$_GESTOR['pagina'] = modelo_var_troca($_GESTOR['pagina'],'<!-- pagina#js -->',$js_global_vars.$js_global_includes);
}

function gestor_pagina_javascript_incluir($js = false,$id = false, $retornar = false){
	global $_GESTOR;

	$js_script = '';
	$js_id = '';
	
	if(!$js){
		if(!isset($_GESTOR['modulo-id'])){
			return;
		}
		if(isset($_GESTOR['modulo#'.$_GESTOR['modulo-id']]['plugin'])){
			$js_script = '<script src="'.$_GESTOR['url-raiz'].$_GESTOR['modulo#'.$_GESTOR['modulo-id']]['plugin'].'/'.$_GESTOR['modulo-id'].'/js.js?v='.$_GESTOR['modulo#'.$_GESTOR['modulo-id']]['versao'].'"></script>';
			$js_id = $_GESTOR['modulo#'.$_GESTOR['modulo-id']]['plugin'].'/'.$_GESTOR['modulo-id'].'/js.js';
		} else {
			$js_script = '<script src="'.$_GESTOR['url-raiz'].$_GESTOR['modulo-id'].'/js.js?v='.$_GESTOR['modulo#'.$_GESTOR['modulo-id']]['versao'].'"></script>';
			$js_id = $_GESTOR['modulo-id'].'/js.js';
		}
	} elseif(gettype($js) == 'array') {
		$tipo = (isset($js['tipo']) ? $js['tipo'] : '');
		$modulo_id = (isset($js['modulo_id']) ? $js['modulo_id'] : 'undefined');
		$versao = (isset($js['versao']) ? $js['versao'] : $_GESTOR['versao']);
		
		$js_script = '<script src="'.$_GESTOR['url-raiz'].$modulo_id.'/'.$tipo.'.js?v='.$versao.'"></script>';
		$js_id = $modulo_id.'/'.$tipo.'.js';
	} else {
		switch($js){
			case 'biblioteca':
				if (is_array($id)) {
                    $js = '<script src="'.$_GESTOR['url-raiz'].'interface/'.(isset($id['caminho']) ? $id['caminho'] : '').'.js?v='.$_GESTOR['biblioteca-'.(isset($id['biblioteca']) ? $id['biblioteca'] : '')]['versao'].'"></script>';
                } else {
					$js = '<script src="'.$_GESTOR['url-raiz'].'interface/'.$id.'.js?v='.$_GESTOR['biblioteca-'.$id]['versao'].'"></script>';
                }
			break;
		}
		
		$js_script = $js;
		$js_id = $js;
	}

	// ===== Se não existir o javascript, retornar.
	if(!existe($js_script)){
		return;
	}

	// ===== Se for para retornar o javascript, retornar.
	if($retornar){
		return $js_script;
	} else {
		$_GESTOR['javascript-fim'][] = $js_script;
	}

	// ===== Verifica se já foi adicionado este javascript, se sim, remover o último que foi adicionado.
	if(!isset($_GESTOR['javascript-fim-adicionados'])){
		$_GESTOR['javascript-fim-adicionados'] = Array();
	} else {
		if(in_array($js_id,$_GESTOR['javascript-fim-adicionados'])){
			array_pop($_GESTOR['javascript-fim']);
			return;
		}
	}

	$_GESTOR['javascript-fim-adicionados'][] = $js_id;
}

function gestor_pagina_ultimas_operacoes(){
	global $_GESTOR;
	
	$_GESTOR['pagina'] = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $_GESTOR['pagina']);
}

/**
 * Retorna true quando o Dashboard Site Toolbar deve estar ativo na requisição atual:
 * editor logado com permissão de editar páginas, numa página pública (não o painel
 * administrativo, não um iframe e não o próprio toolbar). O resultado é cacheado em
 * $_GESTOR para que o wrapper de conteúdo (gestor_pagina_layout) e a injeção do iframe
 * (gestor_dashboard_toolbar) usem exatamente o mesmo gate.
 */
function gestor_dashboard_toolbar_ativo(){
	global $_GESTOR;

	if(isset($_GESTOR['dashboard-toolbar-ativo'])) return $_GESTOR['dashboard-toolbar-ativo'];

	$ativo = true;

	if(isset($_GESTOR['opcao']) && isset($_GESTOR['modulo-id']) && $_GESTOR['modulo-id'] == 'dashboard' && $_GESTOR['opcao'] == 'dashboard-site-toolbar'){
		// Acessando o próprio toolbar → não ativar (evita loop).
		$ativo = false;
	} else if(!gestor_usuario_perfil()){
		$ativo = false;
	} else if(!gestor_permissao_token() || !gestor_permissao_modulo(false)){
		$ativo = false;
	} else if(!(isset($_GESTOR['usuario-id']) && (int)$_GESTOR['usuario-id'] > 0)){
		$ativo = false;
	} else if(isset($_GESTOR['layout#id']) && $_GESTOR['layout#id'] == 'layout-administrativo-do-gestor'){
		$ativo = false;
	} else if(isset($_GESTOR['paginaIframe']) && $_GESTOR['paginaIframe']){
		$ativo = false;
	} else if(isset($_REQUEST['c2f-device-preview'])){
		// Preview de dispositivo do Live Editor: o iframe carrega a PRÓPRIA página (layout + CSS + JS
		// reais do site, para media queries e interações como o menu hambúrguer funcionarem) mas SEM
		// a toolbar/editor — evita recursão do iframe da barra (BATCH-085 §preview-device).
		$ativo = false;
	} else if(!gestor_acesso('editar','admin-paginas')){
		$ativo = false;
	}

	$_GESTOR['dashboard-toolbar-ativo'] = $ativo;
	return $ativo;
}

function gestor_dashboard_toolbar($params = false){
	global $_GESTOR;

	if($params)foreach($params as $var => $val)$$var = $val;

	// ===== Parâmetros

	// caminho - String - Opcional - caminho da página pública hospedeira (resolve id/publisher_id).

	// ===== Gate único (mesmo do wrapper de conteúdo): editor logado em página pública.

	if(!gestor_dashboard_toolbar_ativo()) return;

	// ===== Precisa de um corpo de página (<body>) para injetar.

	if(!isset($_GESTOR['pagina']) || stripos($_GESTOR['pagina'],'<body') === false) return;

	// ===== Resolver a página hospedeira (id + publisher_id) pelo caminho.

	$page_id = '';
	$publisher_id = '';

	if(isset($caminho) && $caminho !== ''){
		$pagina_atual = banco_select(Array(
			'unico' => true,
			'tabela' => 'paginas',
			'campos' => Array('id','publisher_id'),
			'extra' =>
				"WHERE caminho='".banco_escape_field($caminho)."'"
				." AND language='".$_GESTOR['linguagem-codigo']."'"
				." AND status='A'",
		));

		if($pagina_atual){
			$page_id = (existe($pagina_atual['id']) ? $pagina_atual['id'] : '');
			$publisher_id = (existe($pagina_atual['publisher_id']) ? $pagina_atual['publisher_id'] : '');
		}
	}

	// ===== Montar o src do iframe com o contexto da página hospedeira.

	$src = $_GESTOR['url-raiz'].'dashboard-site-toolbar/?page_id='.rawurlencode($page_id);
	if($publisher_id !== '' && $publisher_id !== null){
		$src .= '&publisher_id='.rawurlencode($publisher_id);
	}

	// ===== Iframe fixo no topo (~30px) da barra.

	$iframe =
		'<iframe id="c2f-site-toolbar" src="'.$src.'" title="Dashboard Site Toolbar" '
		.'style="position:fixed;top:0;left:0;width:100%;height:30px;border:0;margin:0;padding:0;z-index:2147483000;background:transparent;" allowtransparency="true"></iframe>';

	// ===== Injetar o iframe imediatamente após a abertura do <body>.

	$_GESTOR['pagina'] = preg_replace_callback('/(<body\b[^>]*>)/i', function($m) use ($iframe){
		return $m[1].$iframe;
	}, $_GESTOR['pagina'], 1);

	// ===== Script de compensação de topo (dashboard.toolbar.js) — a URL dashboard/toolbar.js
	//       é servida como o físico dashboard.toolbar.js (ver arquivo-estatico.php).

	gestor_pagina_javascript_incluir(Array(
		'tipo' => 'toolbar',
		'modulo_id' => 'dashboard',
	));
}

// =========================== Funções de Autenticação de Usuário

function gestor_permissao_validar_jwt($params = false){
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// token - String - Obrigatório - Token JWT de verificação.
	// chavePrivada - String - Obrigatório - Chave privada para conferir a assinatura do token.
	// chavePrivadaSenha - String - Obrigatório - Senha da chave privada.
	
	// ===== 
	
	if(isset($chavePrivada) && isset($chavePrivadaSenha)){
		// ===== Quebra o token em header, payload e signature
		
		$part = explode(".",$token);
		
		if(gettype($part) != 'array'){
			return false;
		}
		
		$header = $part[0];
		$payload = $part[1];
		$signature = $part[2];

		$encodedData = $signature;
		
		// ===== Abrir chave privada com a senha
		
		$resPrivateKey = openssl_get_privatekey($chavePrivada,$chavePrivadaSenha);
		
		// ===== Decode base64 to reaveal dots (Dots are used in JWT syntaxe)

		$encodedData = base64_decode($encodedData);

		// ===== Decrypt data in parts if necessary. Using dots as split separator.

		$rawEncodedData = $encodedData;

		$countCrypt = 0;
		$partialDecodedData = '';
		$decodedData = '';
		$split2 = explode('.',$rawEncodedData);
		foreach($split2 as $part2){
			$part2 = base64_decode($part2);
			
			openssl_private_decrypt($part2, $partialDecodedData, $resPrivateKey);
			$decodedData .= $partialDecodedData;
		}

		// ===== Validate JWT

		if($header.".".$payload === $decodedData){
			$payload = base64_decode($payload);
			$payload = json_decode($payload,true);
			
			// ===== Verifica se as variáveis existem, senão foi formatado errado e não deve aceitar.
			
			if(!isset($payload['exp']) || !isset($payload['sub'])){
				return false;
			}
			
			$expiracao_ok = false;
			
			// ===== Se a expiração for igual a 0 é sessão, senão tem que comparar tempo.
			
			if((int)$payload['exp'] === 0){
				$expiracao_ok = true;
			} else {
				// ===== Se o tempo de expiração do token for menor que o tempo agora, é porque este token está vencido.
				
				if((int)$payload['exp'] > time()){
					$expiracao_ok = true;
				}
			}
			
			if($expiracao_ok){
				// Se tudo estiver válido, retorna o pubID do token.
				
				return $payload['sub'];
			} else {
				return false;
			}
		} else {
			return false;
		}
	} else {
		return false;
	}
}

function gestor_cookie_verificacao(){
	global $_GESTOR;
	global $_CONFIG;
	
	// ===== Verifica se cookie no navegador está ativo.
	
	if(!isset($_COOKIE[$_CONFIG['cookie-verify']]) && !isset($_COOKIE[$_CONFIG['cookie-authname']])){
		// ===== Criar um cookie de verificação
		
		gestor_incluir_biblioteca('seguranca');
		$cookieId = seguranca_token_aleatorio(32);
		
		setcookie($_CONFIG['cookie-verify'], $cookieId, [
			'expires' => '0',
			'path' => '/',
			'domain' => $_SERVER['SERVER_NAME'],
			'secure' => true,
			'httponly' => true,
			'samesite' => 'Lax',
		]);
		
		// ===== Redirecionar o usuário afim de conferir se está ativo numa nova conexão com a URL e queryString caso o mesmo não tenha sido logado de outra forma.
		
		$url = $_GESTOR['caminho-total'] ? urlencode($_GESTOR['caminho-total']) : '';
		$queryString = urlencode(gestor_querystring());
		
		header("Location: " . $_GESTOR['url-raiz'] . '_gestor-cookie-verify/'.$cookieId.'/?url='.$url.(existe($queryString) ? '&queryString='.$queryString : ''));
		exit;
	}
}

function gestor_permissao_token(){
	global $_GESTOR;

	// ===== Idempotência por requisição (req-047 / BATCH-085 §1).
	// Memoiza o resultado para não revalidar/renovar o JWT mais de uma vez no mesmo request.
	// Sem isto, chamar esta função duas vezes (ex.: o filtro global roteador.paginas do
	// bloqueio de assinatura expirada, seguido de gestor_permissao()) faria a segunda
	// chamada ler o token que a primeira acabou de renovar e invalidar (o cookie novo só
	// vale no próximo request), deslogando um usuário legítimo com 401.

	if(array_key_exists('permissao-token-resultado', $_GESTOR)){
		return $_GESTOR['permissao-token-resultado'];
	}

	$_GESTOR['permissao-token-resultado'] = gestor_permissao_token_processar();
	return $_GESTOR['permissao-token-resultado'];
}

function gestor_permissao_token_processar(){
	global $_GESTOR;
	global $_CONFIG;

	// ===== Verifica se cookie no navegador está ativo.

	gestor_cookie_verificacao();
	
	// ===== Verifica se existe o cookie de autenticação gerado no login com sucesso.
	
	if(!isset($_COOKIE[$_CONFIG['cookie-authname']])){
		return false;
	}
	
	$JWTToken = $_COOKIE[$_CONFIG['cookie-authname']];
	
	if(!existe($JWTToken)){
		return false;
	}
	
	// ===== Abrir chave privada e a senha da chave
	
	$keyPrivatePath = $_GESTOR['openssl-path'] . 'privada.key';
	
	$fp = fopen($keyPrivatePath,"r");
	$keyPrivateString = fread($fp,8192);
	fclose($fp);
	
	$chavePrivadaSenha = $_CONFIG['openssl-password'];
	
	// ===== Verificar se o JWT é válido.
	
	$tokenPubId = gestor_permissao_validar_jwt(Array(
		'token' => $JWTToken,
		'chavePrivada' => $keyPrivateString,
		'chavePrivadaSenha' => $chavePrivadaSenha,
	));
	
	if($tokenPubId){
		// ===== Verifica se o token está ativo. Senão estiver invalidar o cookie.
		
		$usuarios_tokens = banco_select_name
		(
			banco_campos_virgulas(Array(
				'id_usuarios_tokens',
				'id_usuarios',
				'pubIDValidation',
				'data_criacao',
				'expiration',
			))
			,
			"usuarios_tokens",
			"WHERE pubID='".$tokenPubId."'"
		);
		
		if($usuarios_tokens){
			// ===== Limpeza dos tokens mais antigos no banco de dados.
			
			$invalidar_token = false;
			
			if(!existe(gestor_sessao_variavel('usuario-tokens-limpeza'))){
				// ===== Deletar todos os tokens de sessão (expiration == 0) quando as datas de criação mais o tempo de limpeza dos mesmos forem menor que o tempo agora.
				
				banco_delete
				(
					"usuarios_tokens",
					"WHERE expiration=0"
					." AND TIMESTAMPADD(SECOND,".$_CONFIG['session-garbagetime'].",data_criacao) < NOW()"
				);
				
				// ===== Deletar todos os tokens persistentes (expiration != 0) quando o tempo de expiração mais o tempo de vida dos tokens forem menor que o tempo agora.
				
				banco_delete
				(
					"usuarios_tokens",
					"WHERE expiration!=0"
					." AND expiration < ".time()
				);
				
				gestor_sessao_variavel('usuario-tokens-limpeza',true);
				
				// ===== Verificar se um dos tokens excluídos é o token atual. Se sim, invalidar token.
				
				$usuarios_tokens_verificar = banco_select_name
				(
					banco_campos_virgulas(Array(
						'id_usuarios_tokens',
					))
					,
					"usuarios_tokens",
					"WHERE pubID='".$tokenPubId."'"
				);
				
				if(!$usuarios_tokens_verificar){
					$invalidar_token = true;
				}
			}
			
			if(!$invalidar_token){
				// ===== Verificar se o token não expirou.
				
				$expiration = $usuarios_tokens[0]['expiration'];
				
				$expiracao_ok = false;
				$token_sessao = false;
				
				// ===== Se a expiração for igual a 0 é sessão, senão tem que comparar tempo de expiração.
				
				if((int)$expiration === 0){
					$expiracao_ok = true;
					$token_sessao = true;
					
					// ===== Caso o tempo de criação deste token for maior que o tempo de limpeza, deve ser deletado e não aceito.
					
					$data_criacao = $usuarios_tokens[0]['data_criacao'];
					
					$time_criacao = strtotime($data_criacao);
					
					if($time_criacao + $_CONFIG['session-garbagetime'] < time()){
						$expiracao_ok = false;
						
						$id_usuarios_tokens = $usuarios_tokens[0]['id_usuarios_tokens'];
						
						banco_delete
						(
							"usuarios_tokens",
							"WHERE id_usuarios_tokens='".$id_usuarios_tokens."'"
						);
					}
				} else {
					// ===== Se o tempo de expiração do token for maior que o tempo agora, é porque este token está ativo. Senão está vencido e deve ser deletado.
					
					if((int)$expiration > time()){
						$expiracao_ok = true;
					} else {
						$id_usuarios_tokens = $usuarios_tokens[0]['id_usuarios_tokens'];
						
						banco_delete
						(
							"usuarios_tokens",
							"WHERE id_usuarios_tokens='".$id_usuarios_tokens."'"
						);
					}
				}
				
				if($expiracao_ok){
					// ===== Validar o token com o hash de validação para evitar geração de token por hacker caso ocorra roubo da tabela 'usuarios_tokens'.
					
					$bd_hash = $usuarios_tokens[0]['pubIDValidation'];
					$token_hash = hash_hmac($_CONFIG['usuario-hash-algo'], $tokenPubId, $_CONFIG['usuario-hash-password']);
					
					if($bd_hash === $token_hash){
						$data_criacao = $usuarios_tokens[0]['data_criacao'];
						$id_usuarios = $usuarios_tokens[0]['id_usuarios'];
						
						if(!$token_sessao){
							// ===== Verificar se precisa renovar JWTToken, se sim, apagar token anterior e criar um novo no lugar.
							
							$time_criacao = strtotime($data_criacao);
							
							if($time_criacao + $_CONFIG['cookie-renewtime'] < time()){
								gestor_incluir_biblioteca('usuario');
								
								usuario_gerar_token_autorizacao(Array(
									'id_usuarios' => $id_usuarios,
								));
								
								$id_usuarios_tokens = $usuarios_tokens[0]['id_usuarios_tokens'];
								
								banco_delete
								(
									"usuarios_tokens",
									"WHERE id_usuarios_tokens='".$id_usuarios_tokens."'"
								);
							}
						}
						
						$_GESTOR['usuario-id'] = $id_usuarios;
						$_GESTOR['usuario-token-id'] = $tokenPubId;

						// ===== Proteção contra Session Hijacking (req-030)
						// Valida User-Agent e bloco de IP; em discrepância suspeita, invalida
						// o token e cai no fluxo de falha (limpa cookie e retorna false).

						gestor_incluir_biblioteca('seguranca');

						if(seguranca_sessao_validar()){
							return true;
						}

						seguranca_sessao_invalidar($tokenPubId);
					}
				}
			}
		}
	}
	
	// ===== Caso não valide, deletar cookie e retornar 'false'.
	
	setcookie($_CONFIG['cookie-authname'], "", [
		'expires' => time() - 3600,
		'path' => '/',
		'domain' => $_SERVER['SERVER_NAME'],
		'secure' => true,
		'httponly' => true,
		'samesite' => 'Lax',
	]);
	
	unset($_COOKIE[$_CONFIG['cookie-authname']]);
	
	return false;
}

function gestor_permissao_fingerprint(){
	global $_GESTOR;
	
	// =====
	
	if(existe(gestor_sessao_variavel('browser-fingerprint'))){
		return true;
	} else {
		return false;
	}
}

/**
 * Verifica se o usuário atual pode acessar o módulo da requisição.
 *
 * @param bool $alertar Quando false, retorna apenas o resultado da consulta,
 *                      sem gravar alerta em sessão.
 * @param string|false $modulo_forcado Módulo a consultar; false usa a rota atual.
 */
function gestor_permissao_modulo($alertar = true, $modulo_forcado = false){
	global $_GESTOR;
	
	$usuario = gestor_usuario();
	$modulo = $modulo_forcado ?: ($_GESTOR['modulo'] ?? '');
	
	if(!existe($modulo)){
		return true;
	}
	
	$modulos = banco_select_name
	(
		banco_campos_virgulas(Array(
			'id_modulos',
		))
		,
		"modulos",
		"WHERE id='".$modulo."'"
		." AND status='A'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
	);
	
	if($modulos){
		// ===== Verificar se o usuário é filho de um host ou não.
		
		if(existe($usuario['id_hosts'])){
			// ===== Verificar se o usuário tem um perfil de gestor ativo.
			
			if(existe($usuario['gestor_perfil'])){
				$gestor_perfil = $usuario['gestor_perfil'];
				
				// ===== Verificar se o módulo alvo tem permissão no perfil.
				
				$usuarios_gestores_perfis_modulos = banco_select_name
				(
					banco_campos_virgulas(Array(
						'id_usuarios_gestores_perfis_modulos',
					))
					,
					"usuarios_gestores_perfis_modulos",
					"WHERE perfil='".$gestor_perfil."'"
					." AND modulo='".$modulo."'"
					." AND id_hosts='".$usuario['id_hosts']."'"
				);
				
				// ===== Caso tenha permissão retornar true.
				
				if($usuarios_gestores_perfis_modulos){
					return true;
				}
			} else {
				// ===== Pegar o usuário pai do usuário em questão.
				
				$hosts = banco_select(Array(
					'unico' => true,
					'tabela' => 'hosts',
					'campos' => Array(
						'id_usuarios',
					),
					'extra' => 
						"WHERE id_hosts='".$usuario['id_hosts']."'"
				));
				
				// ===== Pegar o identificador do perfil do pai do usuário.
				
				$usuarios = banco_select(Array(
					'unico' => true,
					'tabela' => 'usuarios',
					'campos' => Array(
						'id_usuarios_perfis',
					),
					'extra' => 
						"WHERE id_usuarios='".$hosts['id_usuarios']."'"
				));
				
				// ===== Pegar o perfil do usuário.
				
				$usuarios_perfis = banco_select(Array(
					'unico' => true,
					'tabela' => 'usuarios_perfis',
					'campos' => Array(
						'id',
					),
					'extra' => 
						"WHERE id_usuarios_perfis='".$usuarios['id_usuarios_perfis']."'"
				));
				
				$perfil = $usuarios_perfis['id'];
				
				// ===== Verificar se o módulo alvo tem permissão no perfil.
				
				$usuarios_perfis_modulos = banco_select_name
				(
					banco_campos_virgulas(Array(
						'id_usuarios_perfis_modulos',
					))
					,
					"usuarios_perfis_modulos",
					"WHERE perfil='".$perfil."'"
					." AND modulo='".$modulo."'"
				);
				
				// ===== Caso tenha permissão retornar true.
				
				if($usuarios_perfis_modulos){
					return true;
				}
			}
		} else {
			// ===== Pegar o perfil do usuário.
			
			$usuarios_perfis = banco_select(Array(
				'unico' => true,
				'tabela' => 'usuarios_perfis',
				'campos' => Array(
					'id',
				),
				'extra' => 
					"WHERE id_usuarios_perfis='".$usuario['id_usuarios_perfis']."'"
			));
			
			$perfil = $usuarios_perfis['id'];
			
			// ===== Verificar se o módulo alvo tem permissão no perfil.
			
			$usuarios_perfis_modulos = banco_select_name
			(
				banco_campos_virgulas(Array(
					'id_usuarios_perfis_modulos',
				))
				,
				"usuarios_perfis_modulos",
				"WHERE perfil='".$perfil."'"
				." AND modulo='".$modulo."'"
			);
			
			// ===== Caso tenha permissão retornar true.
			
			if($usuarios_perfis_modulos){
				return true;
			}
		}
	}
	
	if($alertar){
		gestor_incluir_biblioteca('interface');

		interface_alerta(Array(
			'redirect' => true,
			'msg' => gestor_variaveis(Array('modulo' => 'usuarios','id' => 'alert-without-permission'))
		));
	}
	
	return false;
}

function gestor_permissao(){
	global $_GESTOR;
	
	if(!gestor_permissao_token()){
		if($_GESTOR['ajax']){
			gestor_roteador_erro(Array(
				'codigo' => 401,
				'ajax' => $_GESTOR['ajax'],
			));
		} else {
			$caminho = (isset($_GESTOR['caminho-total']) ? $_GESTOR['caminho-total'] : '');
			$caminho = rtrim($caminho,'/').'/';
			
			gestor_sessao_variavel("redirecionar-local",$caminho);
			
			gestor_roteador_erro(Array(
				'codigo' => 401,
			));
		}
	}
	
	/* if(!gestor_permissao_fingerprint()){
		if($_GESTOR['ajax']){
			gestor_roteador_erro(Array(
				'codigo' => 401,
				'ajax' => $_GESTOR['ajax'],
			));
		} else {
			$caminho = (isset($_GESTOR['caminho-total']) ? $_GESTOR['caminho-total'] : '');
			$caminho = rtrim($caminho,'/').'/';
			
			gestor_sessao_variavel("redirecionar-local",$caminho);
			
			gestor_roteador_erro(Array(
				'codigo' => 401,
				'redirect' => 'validate-user/',
				'querystring' => true,
			));
		}
	} */
	
	if(!gestor_permissao_modulo()){
		if($_GESTOR['ajax']){
			gestor_roteador_erro(Array(
				'codigo' => 401,
				'ajax' => $_GESTOR['ajax'],
				'redirect' => 'dashboard/',
			));
		} else {
			gestor_roteador_erro(Array(
				'codigo' => 401,
				'redirect' => 'dashboard/',
			));
		}
	}
}

function gestor_usuario(){
	global $_GESTOR;
	
	if(isset($_GESTOR['usuario-id'])){
		if(!isset($_GESTOR['usuario'])){
			$usuarios = banco_select_name
			(
				banco_campos_virgulas(Array(
					'id_hosts',
					'id_usuarios',
					'id_usuarios_perfis',
					'id',
					'usuario',
					'nome',
					'email',
					'gestor',
					'gestor_perfil',
				))
				,
				"usuarios",
				"WHERE id_usuarios='".$_GESTOR['usuario-id']."'"
			);

			$usuarios_perfis = banco_select_name
			(
				banco_campos_virgulas(Array(
					'nome',
					'id',
				))
				,
				"usuarios_perfis",
				"WHERE id_usuarios_perfis='".$usuarios[0]['id_usuarios_perfis']."'"
			);
			
			$_GESTOR['usuario'] = $usuarios[0];
			$_GESTOR['usuario']['perfil_nome'] = $usuarios_perfis[0]['nome'];
			$_GESTOR['usuario']['perfil_slug'] = $usuarios_perfis[0]['id'];
		}
		
		return $_GESTOR['usuario'];
	} else {
		return Array(
			'id_hosts' => '',
			'id_usuarios' => '0',
			'id_usuarios_perfis' => '0',
			'id' => '_anonimo',
			'gestor' => '',
			'gestor_perfil' => '',
			'usuario' => '_anonimo',
			'nome' => 'Anônimo',
			'perfil_nome' => 'Anônimo',
			'perfil_slug' => 'anonimo',
		);
	}
}

function gestor_usuario_perfil(){
	global $_CONFIG;

	// ===== Verifica se cookie no navegador está ativo.
	
	gestor_cookie_verificacao();
	
	// ===== Verifica se existe o cookie de profile existe.
	
	if(isset($_COOKIE[$_CONFIG['cookie-authprofile']])){
		return $_COOKIE[$_CONFIG['cookie-authprofile']];
	} else {
		return false;
	}
}

function gestor_acesso($operacao = false,$modulo = false,$usuario = false){
	global $_GESTOR;
	
	// ===== Parâmetros
	
	// operacao - String - Opcional - operação do módulo atual.
	// modulo - String - Opcional - foçar um módulo diferente do atual.
	// usuario - String - Opcional - foçar um usuário diferente do atual.
	
	// ===== 
	
	if(!$usuario){
		$usuario = gestor_usuario();
	}
	
	if(!$modulo){
		$modulo = $_GESTOR['modulo'];
	}
	
	if(!existe($modulo)){
		return false;
	}
	
	$modulos = banco_select_name
	(
		banco_campos_virgulas(Array(
			'id_modulos',
		))
		,
		"modulos",
		"WHERE id='".$modulo."'"
		." AND status='A'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
	);
	
	if($modulos){
		$usuarios_perfis = banco_select(Array(
			'unico' => true,
			'tabela' => 'usuarios_perfis',
			'campos' => Array(
				'id',
			),
			'extra' => 
				"WHERE id_usuarios_perfis='".$usuario['id_usuarios_perfis']."'"
		));

		$perfil = $usuarios_perfis['id'];

		// ===== Acesso base ao módulo pelo perfil.

		$usuarios_perfis_modulos = banco_select_name
		(
			banco_campos_virgulas(Array(
				'id_usuarios_perfis_modulos',
			))
			,
			"usuarios_perfis_modulos",
			"WHERE modulo='".$modulo."'"
			." AND perfil='".$perfil."'"
		);

		$modulo_acesso = ($usuarios_perfis_modulos ? true : false);

		// ===== Sem operação informada, o acesso ao módulo é suficiente.

		if(!$operacao){
			return $modulo_acesso;
		}

		$modulos_operacoes = banco_select_name
		(
			banco_campos_virgulas(Array(
				'id',
			))
			,
			"modulos_operacoes",
			"WHERE (operacao='".$operacao."' OR id='".$operacao."')"
			." AND language='".$_GESTOR['linguagem-codigo']."'"
			." AND modulo_id='".$modulo."'"
			." AND status='A'"
		);

		// ===== Operação não cadastrada: fallback para permissão de módulo.

		if(!$modulos_operacoes){
			return $modulo_acesso;
		}
		
		if($modulos_operacoes){
			$operacao_id = $modulos_operacoes[0]['id'];
			
			$usuarios_perfis_modulos_operacoes = banco_select_name
			(
				banco_campos_virgulas(Array(
					'id_usuarios_perfis_modulos_operacoes',
				))
				,
				"usuarios_perfis_modulos_operacoes",
				"WHERE operacao='".$operacao_id."'"
				." AND perfil='".$perfil."'"
			);
			
			if($usuarios_perfis_modulos_operacoes){
				return true;
			}
		}
	}
	
	return false;
}

// =========================== Funções de Acesso

function gestor_roteador_301_ou_404($params = false){
	global $_GESTOR;
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// caminho - String - Obrigatório - Caminho para verificar se tem alguma página 301, senão gera erro 404.
	
	// ===== 
	
	if(isset($caminho)){
		$paginas_301 = banco_select_name
		(
			banco_campos_virgulas(Array(
				'id_paginas',
			))
			,
			"paginas_301",
			"WHERE caminho='".banco_escape_field($caminho)."'"
		);
		
		if($paginas_301){
			$paginas = banco_select_name
			(
				banco_campos_virgulas(Array(
					'caminho',
				))
				,
				"paginas",
				"WHERE id_paginas='".$paginas_301[0]['id_paginas']."'"
				." AND language='".$_GESTOR['linguagem-codigo']."'"
				." AND status='A'"
			);
			
			if($paginas){
				gestor_roteador_erro(Array(
					'codigo' => 301,
					'redirect' => $paginas[0]['caminho'],
				));
			}
		}
	}
	
	gestor_roteador_erro(Array(
		'codigo' => 404,
	));
}

function gestor_roteador_erro($params = false){
	global $_GESTOR;
	
	if($params)foreach($params as $var => $val)$$var = $val;
	
	// ===== Parâmetros
	
	// codigo - Int - Obrigatório - Código do erro HTTP.
	// ajax - Bool - Opcional - Indicar se é uma conexão AJAX ou normal.
	// redirect - String - Opcional - Redirecionar para um local específico.
	// querystring - Bool - Opcional - Incluir a querystring no redirecionamento.
	
	// ===== 
	
	if(isset($codigo)){
		http_response_code($codigo);
		
		if(isset($ajax)){
			if(isset($_GESTOR['pagina-alerta'])) if($_GESTOR['pagina-alerta']) gestor_sessao_variavel("alerta",$_GESTOR['pagina-alerta']);
			
			header("Content-Type: application/json; charset: UTF-8");
			
			if(isset($redirect)){
				echo json_encode(Array(
					'error' => $codigo,
					'info' => 'JSON unauthorized',
					'redirect' => $redirect,
				));
			} else {
				switch($codigo){
					case 401:
						echo json_encode(Array(
							'error' => '401',
							'info' => 'JSON unauthorized',
						));
					break;
					case 404:
						echo json_encode(Array(
							'error' => '404',
							'info' => 'JSON not found',
						));
					break;
					case 500:
						echo json_encode(Array(
							'error' => '500',
							'info' => isset($mensagem) ? $mensagem : 'JSON internal server error',
						));
					break;
				}
			}
		} else {
			if(isset($redirect)){
				if(isset($querystring)){
					gestor_redirecionar($redirect,gestor_querystring());
				} else {
					gestor_redirecionar($redirect);
				}
			} else {
				switch($codigo){
					case 401:
						gestor_redirecionar('signin');
					break;
					case 404:
						gestor_redirecionar('404');
					break;
				}
			}
		}
		
		exit;
	}
}

function gestor_hotfix(){
	
	
	echo '<p>Hotfix Done!</p>';
	
	exit;
}

/**
 * Live Editor — restauração de backup via sessão (BATCH-085).
 *
 * Substitui a injeção de HTML no CLIENTE (que quebrava ao trocar de backup) por um fluxo server-side:
 * o front clica num backup → sinaliza via AJAX (`site-toolbar-backup-restore`) → grava-se uma variável
 * de sessão → recarrega a página. Aqui, no roteamento (page load normal), detectamos a sinalização e
 * substituímos o HTML da PÁGINA ou do LAYOUT pela versão do backup — que é então renderizada pelo
 * pipeline normal do gestor (robusto). A sinalização é consumida UMA vez; um flag JS
 * (`gestor.siteToolbarBackupRestaurado`) avisa o front para reentrar no modo de edição já com o backup.
 *
 * @param array $paginas Resultado do select de páginas do roteador (por referência).
 * @return void
 */
function gestor_site_toolbar_backup_aplicar(&$paginas){
	global $_GESTOR;

	// Só no page load normal (não-AJAX) e para usuário logado — evita a query de sessão para visitantes.
	if(!empty($_GESTOR['ajax'])) return;
	if(!(isset($_GESTOR['usuario-id']) && (int)$_GESTOR['usuario-id'] > 0)) return;
	if(!function_exists('gestor_sessao_variavel')) return;

	$sinal = gestor_sessao_variavel('site-toolbar-backup-restore');
	if(!$sinal || !is_array($sinal)) return;

	// Confere se a sinalização é da página que está sendo roteada (pelo caminho normalizado).
	$caminhoAtual = rtrim(($_GESTOR['caminho-total'] ?? ''), '/').'/';
	if(($sinal['caminho'] ?? '') !== $caminhoAtual) return;

	// Consome a sinalização (uma vez só, mesmo que algo falhe adiante).
	if(function_exists('gestor_sessao_variavel_del')) gestor_sessao_variavel_del('site-toolbar-backup-restore');

	$id = (int)($sinal['id'] ?? 0);
	$type = (($sinal['type'] ?? '') === 'layout') ? 'layout' : 'page';
	if($id <= 0) return;

	$row = banco_select(Array(
		'unico' => true,
		'tabela' => 'backup_campos',
		'campos' => Array('valor'),
		'extra' => "WHERE id_backup_campos='".$id."' AND campo='html'",
	));
	if(!$row) return;

	$valor = (string)$row['valor'];

	// Override consumido no roteador: para a página, ainda substituímos $paginas[0]['html'] (prod); o
	// override em $_GESTOR cobre também o dev-env, onde o html vem do arquivo físico.
	if($type === 'layout'){
		$_GESTOR['site-toolbar-backup-layout-html'] = $valor;
	} else {
		$_GESTOR['site-toolbar-backup-page-html'] = $valor;
		if(is_array($paginas) && isset($paginas[0])) $paginas[0]['html'] = $valor;
	}

	if(!isset($_GESTOR['javascript-vars'])) $_GESTOR['javascript-vars'] = Array();
	$_GESTOR['javascript-vars']['siteToolbarBackupRestaurado'] = true;
}

function gestor_roteador(){
	global $_GESTOR;
	global $_INDEX;
	global $_CONFIG;
	
	// ===== Condições iniciais para definir o módulo e a página
	
	$caminho = (isset($_GESTOR['caminho-total']) ? $_GESTOR['caminho-total'] : '');
	$caminho = rtrim($caminho,'/').'/';
	
	$_GESTOR['ajax'] = (isset($_REQUEST['ajax']) ? true : false);
	$_GESTOR['ajaxPagina'] = (isset($_REQUEST['ajaxPagina']) ? true : false);
	$_GESTOR['ajaxWidgets'] = (isset($_REQUEST['ajaxWidgets']) ? $_REQUEST['ajaxWidgets'] : false);
	$_GESTOR['ajax-opcao'] = (isset($_REQUEST['ajaxOpcao']) ? banco_escape_field($_REQUEST['ajaxOpcao']) : false);
	$_GESTOR['opcao'] = (isset($_REQUEST['opcao']) ? banco_escape_field($_REQUEST['opcao']) : false);
	$_GESTOR['paginaIframe'] = (isset($_REQUEST['paginaIframe']) ? true : false);
	$_GESTOR['hotfix'] = (isset($_REQUEST['hotfix']) ? true : false);
	
	$_GESTOR['modulo-registro-id'] = (isset($_REQUEST['ajaxRegistroId']) ? banco_escape_field($_REQUEST['ajaxRegistroId']) : NULL);

	$_GESTOR['page-languages'] = [$_GESTOR['linguagem-codigo']];

	$lang = $_GESTOR['linguagem-codigo'];
	
	// ===== Implementação de um hotfix.
	
	if($_GESTOR['hotfix']){
		gestor_hotfix();
	}
	
	// ===== Rotear URLs de sistema
	
	if(isset($_GESTOR['caminho']) && isset($_GESTOR['caminho'][0]))
	switch($_GESTOR['caminho'][0]){
		case '_gestor-cookie-verify': 
			// ===== Verifica se é retorno de redirecionamento veio junto com o cookie. Se sim redirecionar usuário para a URL com queryString. Senão redireciona automaticamente para página informando a obrigatoriedade do uso de cookies para funcionar a página com permissão.
			
			if(!isset($_COOKIE[$_CONFIG['cookie-verify']])){
				header("Location: " . $_GESTOR['url-raiz'] . 'cookies-is-mandatory/'); exit;
			} else {
				$url = urldecode(banco_escape_field($_REQUEST['url']));
				$queryString = $_REQUEST['queryString'] ? urldecode(banco_escape_field($_REQUEST['queryString'])) : '';
				
				header("Location: " . $_GESTOR['url-raiz'] . $url .(existe($queryString) ? '?'.$queryString : '')); exit;
			}
		break;
	}
	
	// ===== Definição dos campos necessários para retornar os dados da página
	
	if($_GESTOR['ajax']){
		$campos = Array(
			'modulo',
			'plugin',
			'sem_permissao',
			'opcao',
		);
		
		// ===== Se válido pegar o html também.
		
		if($_GESTOR['ajaxPagina']){
			$campos[] = 'html';
		}
	} else if($_GESTOR['opcao']){
		$campos = Array(
			'modulo',
			'plugin',
			'sem_permissao',
		);
	} else {
		$campos = Array(
			'layout_id',
			'html',
			'html_extra_head',
			'css',
			'css_compiled',
			'modulo',
			'plugin',
			'opcao',
			'sem_permissao',
			'nome',
			'framework_css',
		);
	}

	// ===== Pegar o id também em ambiente de desenvolvimento afim de buscar o resource por id.

	if($_GESTOR['development-env']){
		$campos[] = 'id';
	}

	// ===== Buscar no banco de dados o alvo da requisição
	
	$paginas = banco_select_name
	(
		banco_campos_virgulas($campos)
		,
		"paginas",
		"WHERE caminho='".banco_escape_field($caminho)."'"
		." AND language='".$_GESTOR['linguagem-codigo']."'"
		." AND (tipo='sistema' OR tipo='pagina')"
		." AND status='A'"
		// ===== Janela de publicação (agendamento — BATCH-075/Meta 5): fora da janela → 404.
		." AND (data_publicacao_inicio IS NULL OR data_publicacao_inicio <= NOW())"
		." AND (data_publicacao_fim IS NULL OR data_publicacao_fim >= NOW())"
	);

	// ===== Caso não encontre a página e a mesma exista em linguagem diferente do padrão do sistema, devolver a página com a primeira língua disponível.

	if(!isset($paginas)){
		$paginas = banco_select_name
		(
			banco_campos_virgulas($campos)
			,
			"paginas",
			"WHERE caminho='".banco_escape_field($caminho)."'"
			." AND (tipo='sistema' OR tipo='pagina')"
			." AND status='A'"
			." AND (data_publicacao_inicio IS NULL OR data_publicacao_inicio <= NOW())"
			." AND (data_publicacao_fim IS NULL OR data_publicacao_fim >= NOW())"
		);
	}

	// ===== Hook: roteador.paginas
	if (isset($paginas)) {
		gestor_incluir_biblioteca('hooks');
		$paginas = hook_apply_filters('gestor', 'roteador.paginas', $paginas);
	}

	// ===== Live Editor: aplicar restauração de backup sinalizada por sessão (BATCH-085).
	if (isset($paginas)) {
		gestor_site_toolbar_backup_aplicar($paginas);
	}

	// ===== Verificar se a página existe. Se sim, montar a página, executar módulo se houver e imprimir. Senão gerar erro 404 ou redirecionar para página 404.

	if(isset($paginas)){
		// ===== Definir o módulo alvo da página.
		$_GESTOR['modulo'] = $paginas[0]['modulo'];

		// ===== Verificar linguagens de uma página

		$paginas_languages = banco_select_name
		(
			banco_campos_virgulas(Array(
				'language'
			))
			,
			"paginas",
			"WHERE caminho='".banco_escape_field($caminho)."'"
			." AND (tipo='sistema' OR tipo='pagina')"
			." AND status='A'"
		);

		if($paginas_languages){
			$languages = Array();
			foreach($paginas_languages as $paginas_language){
				$languages[] = $paginas_language['language'];
			}

			if(count($languages) > 1){
				$_GESTOR['page-languages'] = $languages;
			}
		}

		// ==== Verificar se a página tem permissão, se houver e o usuário não estiver logado, deve redirecionar para a página de login e finalizar a requisição.
		if(!existe($paginas[0]['sem_permissao'])){
			gestor_permissao();
		} else {
			$sem_permissao = true;
		}

		// ====== Definir variáveis.
		$modulo = $paginas[0]['modulo'];
		$plugin = $paginas[0]['plugin'];
		$id = $paginas[0]['id'] ?? '';

		// ===== Montar a página de acordo com o tipo de requisição (AJAX ou normal).
		if($_GESTOR['ajax']){
			// ===== Definir opção da página.
			if(!$_GESTOR['opcao']) $_GESTOR['opcao'] = $paginas[0]['opcao'];
			
			// ===== Incluir html da página.
			
			if($_GESTOR['ajaxPagina']){
				if($_GESTOR['development-env']){

					if(existe($modulo)){
						if(existe($plugin)){
							$html_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
						} else {
							$html_path = $_GESTOR['modulos-path'].$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
						}
					} else {
						$html_path = $_GESTOR['ROOT_PATH'].'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
					}

					$html = (file_exists($html_path)) ? file_get_contents($html_path) : (existe($paginas[0]['html']) ? $paginas[0]['html'] : '');
				} else {
					$html = $paginas[0]['html'];
				}
				
				$_GESTOR['pagina'] = $html;
			}
			
			// ===== Módulo alvo quando houver no backend, executar.
			$module_path = '';

			// ===== Verificar se a página é de acesso sem permissão, caso seja, deve procurar por um arquivo de módulo com o sufixo '.ajax.public' para ser possível ter um módulo específico para conexões AJAX sem permissão, caso contrário, deve procurar pelo módulo normalmente.
			$modulo_ajax_publico = '';
			if(isset($sem_permissao)){
				$modulo_ajax_publico = '.ajax.public';
			}

			if(existe($modulo)){
				if(existe($plugin)){
					$module_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/'.$modulo.$modulo_ajax_publico.'.php';
				} else {
					$module_path = $_GESTOR['modulos-path'].$modulo.'/'.$modulo.$modulo_ajax_publico.'.php';
				}
			} else if($_GESTOR['opcao']){
				$module_path = $_GESTOR['modulos-path'].'global.php';
			}

			if(is_file($module_path)){
				require_once($module_path);
			}

			// ===== Incluir controladores de widgets na requisição AJAX.

			gestor_pagina_widgets_ajax();

			// ===== Retornar a página formatada para o cliente. Ou erro caso haja.

			if(isset($_GESTOR['ajax-json'])){
				header("Content-Type: application/json; charset: UTF-8");
				echo json_encode($_GESTOR['ajax-json']);
				exit;
			} else {
				gestor_roteador_erro(Array(
					'codigo' => 500,
					'ajax' => $_GESTOR['ajax'],
					'mensagem' => 'AJAX error: No response data set.',
				));
			}
		} else {
			// ===== Caso haja necessidade, alterar opção no módulo e redirecionar para a raiz do módulo
			if($_GESTOR['opcao']){
				$module_path = '';

				if(existe($modulo)){
					if(existe($plugin)){
						$module_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/'.$modulo.'.php';
					} else {
						$module_path = $_GESTOR['modulos-path'].$modulo.'/'.$modulo.'.php';
					}
				}

				if(is_file($module_path)){
					require_once($module_path);
				}
				
				gestor_redirecionar_raiz();
			}
			
			// ===== Senão houver opção de alteração retornar a página alvo
			
			$nome = $paginas[0]['nome'];

			if($_GESTOR['development-env']){
				if(existe($modulo)){
					if(existe($plugin)){
						$html_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
						$css_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.css';
					} else {
						$html_path = $_GESTOR['modulos-path'].$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
						$css_path = $_GESTOR['modulos-path'].$modulo.'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.css';
					}
				} else {
					$html_path = $_GESTOR['ROOT_PATH'].'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.html';
					$css_path = $_GESTOR['ROOT_PATH'].'/resources/'.$lang.'/pages/'.$id.'/'.$id.'.css';
				}

				$html = (file_exists($html_path)) ? file_get_contents($html_path) : (existe($paginas[0]['html']) ? $paginas[0]['html'] : '');
				$css = (file_exists($css_path)) ? file_get_contents($css_path) : (existe($paginas[0]['css']) ? $paginas[0]['css'] : '');
			} else {
				$html = $paginas[0]['html'];
				$css = $paginas[0]['css'];
			}

			// Live Editor (BATCH-085): backup restaurado tem precedência (cobre dev-env, que lê do arquivo).
			if(isset($_GESTOR['site-toolbar-backup-page-html'])){
				$html = $_GESTOR['site-toolbar-backup-page-html'];
			}

			$html_extra_head = $paginas[0]['html_extra_head'];
			$css_compiled = $paginas[0]['css_compiled'];
			$framework_css = $paginas[0]['framework_css'];

			if(!$_GESTOR['opcao']) $_GESTOR['opcao'] = $paginas[0]['opcao'];
			
			// ===== Definir a página, título e framework CSS.
			
			$_GESTOR['pagina'] = $html;
			$_GESTOR['pagina#titulo'] = $nome;
			$_GESTOR['pagina#framework_css'] = $framework_css;

			// ===== Módulo alvo quando houver executar

			$module_path = '';

			if(existe($modulo)){
				if(existe($plugin)){
					$module_path = $_GESTOR['plugins-path'].$plugin.'/modules/'.$modulo.'/'.$modulo.'.php';
				} else {
					$module_path = $_GESTOR['modulos-path'].$modulo.'/'.$modulo.'.php';
				}
			} else if($_GESTOR['opcao']){
				$module_path = $_GESTOR['modulos-path'].'global.php';
			}

			if(is_file($module_path)){
				require_once($module_path);
			}

			// ===== Incluir componentes na página.

			gestor_componentes_incluir_pagina();
			
			// ===== Incluir um layout específico, ou padrão ou nenhum.
			
			if(isset($_GESTOR['layout'])){
				$layout = (isset($_GESTOR['layout']['html']) ? $_GESTOR['layout']['html'] : '');
				$layout_css = (isset($_GESTOR['layout']['css']) ? $_GESTOR['layout']['css'] : '');
			} else if($paginas[0]['layout_id']){
				if($_GESTOR['paginaIframe']){
					$layouts = gestor_layout(Array(
						'id' => 'layout-iframes',
						'return_css' => true,
					));
				} else {
					$layouts = gestor_layout(Array(
						'id' => $paginas[0]['layout_id'],
						'return_css' => true,
					));
				}
				
				$layout = $layouts['html'];
				$layout_css = $layouts['css'];
				$layout_css_compiled = $layouts['css_compiled'];

				// Live Editor (BATCH-085): backup de LAYOUT restaurado tem precedência.
				if(isset($_GESTOR['site-toolbar-backup-layout-html'])){
					$layout = $_GESTOR['site-toolbar-backup-layout-html'];
				}

				$_GESTOR['layout#id'] = $paginas[0]['layout_id'];
			} else {
				$layout = '';
				$layout_css = '';
				$layout_css_compiled = '';
			}
			
			// ===== Incluir os recursos da página e do layout.

			gestor_pagina_recursos_incluir(Array(
				'css' => $layout_css,
				'css_compiled' => $layout_css_compiled,
			));

			gestor_pagina_recursos_incluir(Array(
				'css' => $css,
				'css_compiled' => $css_compiled,
				'html_extra_head' => $html_extra_head,
			));
			
			// ===== Inclusão de variáveis de linguagem para o widget e detecção automática

			$widgetActive = (isset($_CONFIG['language']['widget-active']) && $_CONFIG['language']['widget-active'] ? true : false);
			$autoDetect = (isset($_CONFIG['language']['auto-detect']) && $_CONFIG['language']['auto-detect'] ? true : false);

			if($widgetActive || $autoDetect){
				gestor_incluir_biblioteca('variaveis');
				
				$languages = Array();
				foreach($_GESTOR['languages'] as $lang){
					$label = gestor_variaveis(Array('id' => 'language-label-' . $lang));
					$languages[] = Array(
						'codigo' => $lang,
						'nome' => ($label ? $label : $lang),
					);
				}

				if(!isset($_GESTOR['javascript-vars'])){
					$_GESTOR['javascript-vars'] = Array();
				}

				$_GESTOR['javascript-vars']['languages'] = Array(
					'codigos' => $languages,
					'widgetActive' => $widgetActive,
					'autoDetect' => $autoDetect
				);
			}
			
			// ===== Aplicar o layout à página

			gestor_pagina_layout(Array(
				'layout' => $layout,
			));

			// ===== Incluir widgets na página e/ou layout.

			gestor_pagina_widgets();

			// ===== Dashboard Site Toolbar (injeção só para editores logados em páginas públicas).
			//       Antes de gestor_pagina_extra_head_e_javascript() para o JS auxiliar ser incluído.

			gestor_dashboard_toolbar(Array('caminho' => $caminho));

			// ===== Motor de exibição PDF.js (req-096): assets incluídos só se a página usa o leitor.

			gestor_pagina_pdf_viewer();

			// ===== Inclusão de bibliotecas globais de uma página

			gestor_pagina_css();
			gestor_pagina_extra_head_e_javascript();

			// ===== Inclusão de variáveis globais de uma página
			
			gestor_pagina_variaveis();

			// ===== Ultimas operações para a página.

			gestor_pagina_ultimas_operacoes();
			
			// ===== Retornar a página formatada para o cliente
			
			header("Content-Type: text/html; charset: UTF-8");
			echo $_GESTOR['pagina'];
			exit;
		}
	} else {
		// ===== Caso não exista a página, gerar erro 404.
		if($_GESTOR['ajax']){
			gestor_roteador_erro(Array(
				'codigo' => 404,
				'ajax' => $_GESTOR['ajax'],
			));
		} else {
			gestor_roteador_301_ou_404(Array(
				'caminho' => $caminho,
			));
		}
	}
}

/** Rejeita traversal e separadores ambíguos antes de qualquer concatenação de caminho. */
function gestor_caminho_publico_valido($caminho){
	$caminho = (string)$caminho;

	for($i = 0; $i < 3; $i++){
		$decodificado = rawurldecode($caminho);
		if($decodificado === $caminho) break;
		$caminho = $decodificado;
	}

	return strpos($caminho, '..') === false
		&& strpos($caminho, "\0") === false
		&& strpos($caminho, '\\') === false;
}

/** Emite cabeçalhos defensivos para todas as respostas do bootstrap web. */
function gestor_cabecalhos_seguranca(){
	global $_CONFIG;

	if(headers_sent()) return;

	header('X-Content-Type-Options: nosniff');
	header('Referrer-Policy: strict-origin-when-cross-origin');

	$xFrame = trim((string)($_CONFIG['security']['x-frame-options'] ?? 'SAMEORIGIN'));
	if($xFrame !== '' && strcasecmp($xFrame, 'OFF') !== 0) header('X-Frame-Options: '.$xFrame);

	$https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
	if($https) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

	$csp = trim((string)($_CONFIG['security']['csp'] ?? ''));
	if($csp !== ''){
		$nome = !empty($_CONFIG['security']['csp-report-only'])
			? 'Content-Security-Policy-Report-Only'
			: 'Content-Security-Policy';
		header($nome.': '.$csp);
	}
}

function gestor_config(){
	global $_GESTOR;
	global $_CONFIG;
	
	// =========================== Definição do Caminho da Página

	if(isset($_REQUEST['_gestor-caminho'])){
		if(!gestor_caminho_publico_valido($_REQUEST['_gestor-caminho'])){
			http_response_code(400);
			exit;
		}

		$_GESTOR['caminho-total'] = (string)$_REQUEST['_gestor-caminho'];
		$_GESTOR['caminho'] = explode('/',strtolower($_GESTOR['caminho-total']));

		// Verificar se o primeiro segmento é uma linguagem válida, se sim definir a linguagem e remover do array de caminho.
		if(!empty($_GESTOR['caminho'][0]) && in_array($_GESTOR['caminho'][0], $_GESTOR['languages'])){
			$_GESTOR['linguagem-codigo'] = $_GESTOR['caminho'][0];
			array_shift($_GESTOR['caminho']);
			$_GESTOR['caminho-total'] = substr($_GESTOR['caminho-total'], strlen($_GESTOR['linguagem-codigo']) + 1);
			$_GESTOR['language-in-url'] = true;

			// Ajustar URL Raiz para incluir a linguagem
			$_GESTOR['url-raiz'] = $_GESTOR['url-raiz'] . $_GESTOR['linguagem-codigo'].'/';
			$_GESTOR['url-full'] =	$_GESTOR['url-full'] . $_GESTOR['linguagem-codigo'].'/';
			$_GESTOR['url-full-http'] =	$_GESTOR['url-full-http'] . $_GESTOR['linguagem-codigo'].'/';
		}
		
		// Remover último segmento caso seja nulo (barra no final da URL)
		if($_GESTOR['caminho'][count($_GESTOR['caminho'])-1] == NULL){
			array_pop($_GESTOR['caminho']);
		}
		
		$_GESTOR['caminho-extensao'] = pathinfo($_GESTOR['caminho-total'], PATHINFO_EXTENSION);
	}

	// Se não tem linguagem na URL verifique o cookie '$_CONFIG['cookie-language']' e defina $_GESTOR['linguagem-codigo'] se válido
	if(isset($_COOKIE[$_CONFIG['cookie-language']]) && !isset($_GESTOR['language-in-url'])){
		$cookieLang = $_COOKIE[$_CONFIG['cookie-language']];
		if(in_array($cookieLang, $_GESTOR['languages'])){
			$_GESTOR['linguagem-codigo'] = $cookieLang;
		}
	}

	// =========================== Retornar arquivo estático caso exista e finalizar gestor

	$_GESTOR['arquivo-estatico'] = false;

	if((isset($_GESTOR['caminho-extensao']) ? $_GESTOR['caminho-extensao'] : null)){
		$_GESTOR['arquivo-estatico'] = Array(
			'alvo' => (isset($_GESTOR['caminho'][0]) ? $_GESTOR['caminho'][0] : null),
			'alvo2' => (isset($_GESTOR['caminho'][1]) ? $_GESTOR['caminho'][1] : null),
			'ext' => $_GESTOR['caminho-extensao'],
		);
	}

	if($_GESTOR['arquivo-estatico']){
		require_once($_GESTOR['controladores-path'].'arquivo-estatico/arquivo-estatico.php');
		exit;
	}

	// =========================== Controladores

	if(isset($_GESTOR['caminho']) && isset($_GESTOR['caminho'][0]))
	switch($_GESTOR['caminho'][0]){
		case '_gateways':
			require_once($_GESTOR['controladores-path'].'plataforma-gateways/plataforma-gateways.php'); exit;
		break;
		case '_api':
			require_once($_GESTOR['controladores-path'].'api/api.php'); exit;
		break;
	}
}

function gestor_start(){
	gestor_cabecalhos_seguranca();
	gestor_config();
	gestor_sessao_iniciar();
	gestor_incluir_biblioteca('seguranca');
	if(!seguranca_csrf_requisicao_validar()){
		http_response_code(403);
		header('Content-Type: application/json; charset=UTF-8');
		echo json_encode(Array('status' => 'error', 'message' => 'Token CSRF inválido ou ausente.'), JSON_UNESCAPED_UNICODE);
		exit;
	}
	gestor_roteador();
}

// =========================== Inciar Gestor 

gestor_start();

?>
