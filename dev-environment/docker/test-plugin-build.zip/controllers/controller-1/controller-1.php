<?php

namespace Plugin\Controllers;

class Controller1
{
    public function index()
    {
        // Code for the index action
    }

    public function show($id)
    {
        // Code for the show action
    }
}
